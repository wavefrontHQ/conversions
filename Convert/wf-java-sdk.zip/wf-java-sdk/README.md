# wf-java-sdk

## Requirements

Building the API client library requires [Maven](https://maven.apache.org/) to be installed.

## Installation

To install the API client library to your local Maven repository, simply execute:

```shell
mvn install
```

To deploy it to a remote Maven repository instead, configure the settings of the repository and execute:

```shell
mvn deploy
```

Refer to the [official documentation](https://maven.apache.org/plugins/maven-deploy-plugin/usage.html) for more information.

### Maven users

Add this dependency to your project's POM:

```xml
<dependency>
    <groupId>com.wavefront.rest.api.client</groupId>
    <artifactId>wf-java-sdk</artifactId>
    <version>5.0-SNAPSHOT</version>
    <scope>compile</scope>
</dependency>
```

### Gradle users

Add this dependency to your project's build file:

```groovy
compile "com.wavefront.rest.api.client:wf-java-sdk:5.0-SNAPSHOT"
```

### Others

At first generate the JAR by executing:

    mvn package

Then manually install the following JARs:

* target/wf-java-sdk-5.0-SNAPSHOT.jar
* target/lib/*.jar

## Getting Started

Please follow the [installation](#installation) instruction and execute the following Java code:

```java

import com.wavefront.rest.api.*;
import com.wavefront.rest.api.auth.*;
import com.wavefront.rest.api.model.*;
import com.wavefront.rest.api.client.AgentApi;

import java.io.File;
import java.util.*;

public class AgentApiExample {

    public static void main(String[] args) {
        ApiClient defaultClient = Configuration.getDefaultApiClient();
        
        // Configure API key authorization: api_key
        ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
        api_key.setApiKey("YOUR API KEY");
        // Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
        //api_key.setApiKeyPrefix("Token");

        AgentApi apiInstance = new AgentApi();
        String id = "id_example"; // String | 
        try {
            ResponseContainerAgent result = apiInstance.deleteAgent(id);
            System.out.println(result);
        } catch (ApiException e) {
            System.err.println("Exception when calling AgentApi#deleteAgent");
            e.printStackTrace();
        }
    }
}

```

## Documentation for API Endpoints

All URIs are relative to *https://localhost/*

Class | Method | HTTP request | Description
------------ | ------------- | ------------- | -------------
*AgentApi* | [**deleteAgent**](docs/AgentApi.md#deleteAgent) | **DELETE** /api/v2/agent/{id} | Delete a specific agent
*AgentApi* | [**getAgent**](docs/AgentApi.md#getAgent) | **GET** /api/v2/agent/{id} | Get a specific agent
*AgentApi* | [**getAllAgent**](docs/AgentApi.md#getAllAgent) | **GET** /api/v2/agent | Get all agents for a customer
*AgentApi* | [**undeleteAgent**](docs/AgentApi.md#undeleteAgent) | **POST** /api/v2/agent/{id}/undelete | Undelete a specific agent
*AgentApi* | [**updateAgent**](docs/AgentApi.md#updateAgent) | **PUT** /api/v2/agent/{id} | Update the name of a specific agent
*AlertApi* | [**addAlertTag**](docs/AlertApi.md#addAlertTag) | **PUT** /api/v2/alert/{id}/tag/{tagValue} | Add a tag to a specific alert
*AlertApi* | [**createAlert**](docs/AlertApi.md#createAlert) | **POST** /api/v2/alert | Create a specific alert
*AlertApi* | [**deleteAlert**](docs/AlertApi.md#deleteAlert) | **DELETE** /api/v2/alert/{id} | Delete a specific alert
*AlertApi* | [**getAlert**](docs/AlertApi.md#getAlert) | **GET** /api/v2/alert/{id} | Get a specific alert
*AlertApi* | [**getAlertHistory**](docs/AlertApi.md#getAlertHistory) | **GET** /api/v2/alert/{id}/history | Get the version history of a specific alert
*AlertApi* | [**getAlertTags**](docs/AlertApi.md#getAlertTags) | **GET** /api/v2/alert/{id}/tag | Get all tags associated with a specific alert
*AlertApi* | [**getAlertVersion**](docs/AlertApi.md#getAlertVersion) | **GET** /api/v2/alert/{id}/history/{version} | Get a specific historical version of a specific alert
*AlertApi* | [**getAlertsSummary**](docs/AlertApi.md#getAlertsSummary) | **GET** /api/v2/alert/summary | Count alerts of various statuses for a customer
*AlertApi* | [**getAllAlert**](docs/AlertApi.md#getAllAlert) | **GET** /api/v2/alert | Get all alerts for a customer
*AlertApi* | [**removeAlertTag**](docs/AlertApi.md#removeAlertTag) | **DELETE** /api/v2/alert/{id}/tag/{tagValue} | Remove a tag from a specific alert
*AlertApi* | [**setAlertTags**](docs/AlertApi.md#setAlertTags) | **POST** /api/v2/alert/{id}/tag | Set all tags associated with a specific alert
*AlertApi* | [**snoozeAlert**](docs/AlertApi.md#snoozeAlert) | **POST** /api/v2/alert/{id}/snooze | Snooze a specific alert for some number of seconds
*AlertApi* | [**undeleteAlert**](docs/AlertApi.md#undeleteAlert) | **POST** /api/v2/alert/{id}/undelete | Undelete a specific alert
*AlertApi* | [**unsnoozeAlert**](docs/AlertApi.md#unsnoozeAlert) | **POST** /api/v2/alert/{id}/unsnooze | Unsnooze a specific alert
*AlertApi* | [**updateAlert**](docs/AlertApi.md#updateAlert) | **PUT** /api/v2/alert/{id} | Update a specific alert
*CloudIntegrationApi* | [**createCloudIntegration**](docs/CloudIntegrationApi.md#createCloudIntegration) | **POST** /api/v2/cloudintegration | Create a cloud integration
*CloudIntegrationApi* | [**deleteCloudIntegration**](docs/CloudIntegrationApi.md#deleteCloudIntegration) | **DELETE** /api/v2/cloudintegration/{id} | Delete a specific cloud integration
*CloudIntegrationApi* | [**getAllCloudIntegration**](docs/CloudIntegrationApi.md#getAllCloudIntegration) | **GET** /api/v2/cloudintegration | Get all cloud integrations for a customer
*CloudIntegrationApi* | [**getCloudIntegration**](docs/CloudIntegrationApi.md#getCloudIntegration) | **GET** /api/v2/cloudintegration/{id} | Get a specific cloud integration
*CloudIntegrationApi* | [**undeleteCloudIntegration**](docs/CloudIntegrationApi.md#undeleteCloudIntegration) | **POST** /api/v2/cloudintegration/{id}/undelete | Undelete a specific cloud integration
*CloudIntegrationApi* | [**updateCloudIntegration**](docs/CloudIntegrationApi.md#updateCloudIntegration) | **PUT** /api/v2/cloudintegration/{id} | Update a specific cloud integration
*DashboardApi* | [**addDashboardTag**](docs/DashboardApi.md#addDashboardTag) | **PUT** /api/v2/dashboard/{id}/tag/{tagValue} | Add a tag to a specific dashboard
*DashboardApi* | [**createDashboard**](docs/DashboardApi.md#createDashboard) | **POST** /api/v2/dashboard | Create a specific dashboard
*DashboardApi* | [**deleteDashboard**](docs/DashboardApi.md#deleteDashboard) | **DELETE** /api/v2/dashboard/{id} | Delete a specific dashboard
*DashboardApi* | [**getAllDashboard**](docs/DashboardApi.md#getAllDashboard) | **GET** /api/v2/dashboard | Get all dashboards for a customer
*DashboardApi* | [**getDashboard**](docs/DashboardApi.md#getDashboard) | **GET** /api/v2/dashboard/{id} | Get a specific dashboard
*DashboardApi* | [**getDashboardHistory**](docs/DashboardApi.md#getDashboardHistory) | **GET** /api/v2/dashboard/{id}/history | Get the version history of a specific dashboard
*DashboardApi* | [**getDashboardTags**](docs/DashboardApi.md#getDashboardTags) | **GET** /api/v2/dashboard/{id}/tag | Get all tags associated with a specific dashboard
*DashboardApi* | [**getDashboardVersion**](docs/DashboardApi.md#getDashboardVersion) | **GET** /api/v2/dashboard/{id}/history/{version} | Get a specific version of a specific dashboard
*DashboardApi* | [**removeDashboardTag**](docs/DashboardApi.md#removeDashboardTag) | **DELETE** /api/v2/dashboard/{id}/tag/{tagValue} | Remove a tag from a specific dashboard
*DashboardApi* | [**setDashboardTags**](docs/DashboardApi.md#setDashboardTags) | **POST** /api/v2/dashboard/{id}/tag | Set all tags associated with a specific dashboard
*DashboardApi* | [**undeleteDashboard**](docs/DashboardApi.md#undeleteDashboard) | **POST** /api/v2/dashboard/{id}/undelete | Undelete a specific dashboard
*DashboardApi* | [**updateDashboard**](docs/DashboardApi.md#updateDashboard) | **PUT** /api/v2/dashboard/{id} | Update a specific dashboard
*EventApi* | [**addEventTag**](docs/EventApi.md#addEventTag) | **PUT** /api/v2/event/{id}/tag/{tagValue} | Add a tag to a specific event
*EventApi* | [**closeEvent**](docs/EventApi.md#closeEvent) | **POST** /api/v2/event/{id}/close | Close a specific event
*EventApi* | [**createEvent**](docs/EventApi.md#createEvent) | **POST** /api/v2/event | Create a specific event
*EventApi* | [**deleteEvent**](docs/EventApi.md#deleteEvent) | **DELETE** /api/v2/event/{id} | Delete a specific event
*EventApi* | [**getAllEventsWithTimeRange**](docs/EventApi.md#getAllEventsWithTimeRange) | **GET** /api/v2/event | List all the events for a customer within a time range
*EventApi* | [**getEvent**](docs/EventApi.md#getEvent) | **GET** /api/v2/event/{id} | Get a specific event
*EventApi* | [**getEventTags**](docs/EventApi.md#getEventTags) | **GET** /api/v2/event/{id}/tag | Get all tags associated with a specific event
*EventApi* | [**removeEventTag**](docs/EventApi.md#removeEventTag) | **DELETE** /api/v2/event/{id}/tag/{tagValue} | Remove a tag from a specific event
*EventApi* | [**setEventTags**](docs/EventApi.md#setEventTags) | **POST** /api/v2/event/{id}/tag | Set all tags associated with a specific event
*EventApi* | [**updateEvent**](docs/EventApi.md#updateEvent) | **PUT** /api/v2/event/{id} | Update a specific event
*ExternalLinkApi* | [**createExternalLink**](docs/ExternalLinkApi.md#createExternalLink) | **POST** /api/v2/extlink | Create a specific external link
*ExternalLinkApi* | [**deleteExternalLink**](docs/ExternalLinkApi.md#deleteExternalLink) | **DELETE** /api/v2/extlink/{id} | Delete a specific external link
*ExternalLinkApi* | [**getAllExternalLink**](docs/ExternalLinkApi.md#getAllExternalLink) | **GET** /api/v2/extlink | Get all external links for a customer
*ExternalLinkApi* | [**getExternalLink**](docs/ExternalLinkApi.md#getExternalLink) | **GET** /api/v2/extlink/{id} | Get a specific external link
*ExternalLinkApi* | [**updateExternalLink**](docs/ExternalLinkApi.md#updateExternalLink) | **PUT** /api/v2/extlink/{id} | Update a specific external link
*MaintenanceWindowApi* | [**createMaintenanceWindow**](docs/MaintenanceWindowApi.md#createMaintenanceWindow) | **POST** /api/v2/maintenancewindow | Create a maintenance window
*MaintenanceWindowApi* | [**deleteMaintenanceWindow**](docs/MaintenanceWindowApi.md#deleteMaintenanceWindow) | **DELETE** /api/v2/maintenancewindow/{id} | Delete a specific maintenance window
*MaintenanceWindowApi* | [**getAllMaintenanceWindow**](docs/MaintenanceWindowApi.md#getAllMaintenanceWindow) | **GET** /api/v2/maintenancewindow | Get all maintenance windows for a customer
*MaintenanceWindowApi* | [**getMaintenanceWindow**](docs/MaintenanceWindowApi.md#getMaintenanceWindow) | **GET** /api/v2/maintenancewindow/{id} | Get a specific maintenance window
*MaintenanceWindowApi* | [**updateMaintenanceWindow**](docs/MaintenanceWindowApi.md#updateMaintenanceWindow) | **PUT** /api/v2/maintenancewindow/{id} | Update a specific maintenance window
*MessageApi* | [**userGetMessages**](docs/MessageApi.md#userGetMessages) | **GET** /api/v2/message | Gets messages applicable to the current user, i.e. within time range and distribution scope
*MessageApi* | [**userReadMessage**](docs/MessageApi.md#userReadMessage) | **POST** /api/v2/message/{id}/read | Mark a specific message as read
*MetricApi* | [**getMetricDetails**](docs/MetricApi.md#getMetricDetails) | **GET** /api/v2/chart/metric/detail | Get more details on a metric, including reporting sources and approximate last time reported
*QueryApi* | [**queryApi**](docs/QueryApi.md#queryApi) | **GET** /api/v2/chart/api | Perform a charting query against Wavefront servers that returns the appropriate points in the specified time window and granularity
*QueryApi* | [**queryRaw**](docs/QueryApi.md#queryRaw) | **GET** /api/v2/chart/raw | Perform a raw data query against Wavefront servers that returns second granularity points grouped by tags
*SavedSearchApi* | [**createSavedSearch**](docs/SavedSearchApi.md#createSavedSearch) | **POST** /api/v2/savedsearch | Create a saved search
*SavedSearchApi* | [**deleteSavedSearch**](docs/SavedSearchApi.md#deleteSavedSearch) | **DELETE** /api/v2/savedsearch/{id} | Delete a specific saved search
*SavedSearchApi* | [**getAllEntityTypeSavedSearches**](docs/SavedSearchApi.md#getAllEntityTypeSavedSearches) | **GET** /api/v2/savedsearch/type/{entitytype} | Get all saved searches for a specific entity type for a user
*SavedSearchApi* | [**getAllSavedSearches**](docs/SavedSearchApi.md#getAllSavedSearches) | **GET** /api/v2/savedsearch | Get all saved searches for a user
*SavedSearchApi* | [**getSavedSearch**](docs/SavedSearchApi.md#getSavedSearch) | **GET** /api/v2/savedsearch/{id} | Get a specific saved search
*SavedSearchApi* | [**updateSavedSearch**](docs/SavedSearchApi.md#updateSavedSearch) | **PUT** /api/v2/savedsearch/{id} | Update a specific saved search
*SearchApi* | [**searchAgentDeletedEntities**](docs/SearchApi.md#searchAgentDeletedEntities) | **POST** /api/v2/search/agent/deleted | Search over a customer&#39;s deleted agents
*SearchApi* | [**searchAgentDeletedForFacet**](docs/SearchApi.md#searchAgentDeletedForFacet) | **POST** /api/v2/search/agent/deleted/{facet} | Lists the values of a specific facet over the customer&#39;s deleted agents
*SearchApi* | [**searchAgentDeletedForFacets**](docs/SearchApi.md#searchAgentDeletedForFacets) | **POST** /api/v2/search/agent/deleted/facets | Lists the values of one or more facets over the customer&#39;s deleted agents
*SearchApi* | [**searchAgentEntities**](docs/SearchApi.md#searchAgentEntities) | **POST** /api/v2/search/agent | Search over a customer&#39;s non-deleted agents
*SearchApi* | [**searchAgentForFacet**](docs/SearchApi.md#searchAgentForFacet) | **POST** /api/v2/search/agent/{facet} | Lists the values of a specific facet over the customer&#39;s non-deleted agents
*SearchApi* | [**searchAgentForFacets**](docs/SearchApi.md#searchAgentForFacets) | **POST** /api/v2/search/agent/facets | Lists the values of one or more facets over the customer&#39;s non-deleted agents
*SearchApi* | [**searchAlertDeletedEntities**](docs/SearchApi.md#searchAlertDeletedEntities) | **POST** /api/v2/search/alert/deleted | Search over a customer&#39;s deleted alerts
*SearchApi* | [**searchAlertDeletedForFacet**](docs/SearchApi.md#searchAlertDeletedForFacet) | **POST** /api/v2/search/alert/deleted/{facet} | Lists the values of a specific facet over the customer&#39;s deleted alerts
*SearchApi* | [**searchAlertDeletedForFacets**](docs/SearchApi.md#searchAlertDeletedForFacets) | **POST** /api/v2/search/alert/deleted/facets | Lists the values of one or more facets over the customer&#39;s deleted alerts
*SearchApi* | [**searchAlertEntities**](docs/SearchApi.md#searchAlertEntities) | **POST** /api/v2/search/alert | Search over a customer&#39;s non-deleted alerts
*SearchApi* | [**searchAlertForFacet**](docs/SearchApi.md#searchAlertForFacet) | **POST** /api/v2/search/alert/{facet} | Lists the values of a specific facet over the customer&#39;s non-deleted alerts
*SearchApi* | [**searchAlertForFacets**](docs/SearchApi.md#searchAlertForFacets) | **POST** /api/v2/search/alert/facets | Lists the values of one or more facets over the customer&#39;s non-deleted alerts
*SearchApi* | [**searchCloudIntegrationDeletedEntities**](docs/SearchApi.md#searchCloudIntegrationDeletedEntities) | **POST** /api/v2/search/cloudintegration/deleted | Search over a customer&#39;s deleted cloud integrations
*SearchApi* | [**searchCloudIntegrationDeletedForFacet**](docs/SearchApi.md#searchCloudIntegrationDeletedForFacet) | **POST** /api/v2/search/cloudintegration/deleted/{facet} | Lists the values of a specific facet over the customer&#39;s deleted cloud integrations
*SearchApi* | [**searchCloudIntegrationDeletedForFacets**](docs/SearchApi.md#searchCloudIntegrationDeletedForFacets) | **POST** /api/v2/search/cloudintegration/deleted/facets | Lists the values of one or more facets over the customer&#39;s deleted cloud integrations
*SearchApi* | [**searchCloudIntegrationEntities**](docs/SearchApi.md#searchCloudIntegrationEntities) | **POST** /api/v2/search/cloudintegration | Search over a customer&#39;s non-deleted cloud integrations
*SearchApi* | [**searchCloudIntegrationForFacet**](docs/SearchApi.md#searchCloudIntegrationForFacet) | **POST** /api/v2/search/cloudintegration/{facet} | Lists the values of a specific facet over the customer&#39;s non-deleted cloud integrations
*SearchApi* | [**searchCloudIntegrationForFacets**](docs/SearchApi.md#searchCloudIntegrationForFacets) | **POST** /api/v2/search/cloudintegration/facets | Lists the values of one or more facets over the customer&#39;s non-deleted cloud integrations
*SearchApi* | [**searchDashboardDeletedEntities**](docs/SearchApi.md#searchDashboardDeletedEntities) | **POST** /api/v2/search/dashboard/deleted | Search over a customer&#39;s deleted dashboards
*SearchApi* | [**searchDashboardDeletedForFacet**](docs/SearchApi.md#searchDashboardDeletedForFacet) | **POST** /api/v2/search/dashboard/deleted/{facet} | Lists the values of a specific facet over the customer&#39;s deleted dashboards
*SearchApi* | [**searchDashboardDeletedForFacets**](docs/SearchApi.md#searchDashboardDeletedForFacets) | **POST** /api/v2/search/dashboard/deleted/facets | Lists the values of one or more facets over the customer&#39;s deleted dashboards
*SearchApi* | [**searchDashboardEntities**](docs/SearchApi.md#searchDashboardEntities) | **POST** /api/v2/search/dashboard | Search over a customer&#39;s non-deleted dashboards
*SearchApi* | [**searchDashboardForFacet**](docs/SearchApi.md#searchDashboardForFacet) | **POST** /api/v2/search/dashboard/{facet} | Lists the values of a specific facet over the customer&#39;s non-deleted dashboards
*SearchApi* | [**searchDashboardForFacets**](docs/SearchApi.md#searchDashboardForFacets) | **POST** /api/v2/search/dashboard/facets | Lists the values of one or more facets over the customer&#39;s non-deleted dashboards
*SearchApi* | [**searchExternalLinkEntities**](docs/SearchApi.md#searchExternalLinkEntities) | **POST** /api/v2/search/extlink | Search over a customer&#39;s external links
*SearchApi* | [**searchExternalLinksForFacet**](docs/SearchApi.md#searchExternalLinksForFacet) | **POST** /api/v2/search/extlink/{facet} | Lists the values of a specific facet over the customer&#39;s external links
*SearchApi* | [**searchExternalLinksForFacets**](docs/SearchApi.md#searchExternalLinksForFacets) | **POST** /api/v2/search/extlink/facets | Lists the values of one or more facets over the customer&#39;s external links
*SearchApi* | [**searchMaintenanceWindowEntities**](docs/SearchApi.md#searchMaintenanceWindowEntities) | **POST** /api/v2/search/maintenancewindow | Search over a customer&#39;s maintenance windows
*SearchApi* | [**searchMaintenanceWindowForFacet**](docs/SearchApi.md#searchMaintenanceWindowForFacet) | **POST** /api/v2/search/maintenancewindow/{facet} | Lists the values of a specific facet over the customer&#39;s maintenance windows
*SearchApi* | [**searchMaintenanceWindowForFacets**](docs/SearchApi.md#searchMaintenanceWindowForFacets) | **POST** /api/v2/search/maintenancewindow/facets | Lists the values of one or more facets over the customer&#39;s maintenance windows
*SearchApi* | [**searchNotficantForFacets**](docs/SearchApi.md#searchNotficantForFacets) | **POST** /api/v2/search/webhook/facets | Lists the values of one or more facets over the customer&#39;s webhooks
*SearchApi* | [**searchNotificantEntities**](docs/SearchApi.md#searchNotificantEntities) | **POST** /api/v2/search/webhook | Search over a customer&#39;s webhooks
*SearchApi* | [**searchNotificantForFacet**](docs/SearchApi.md#searchNotificantForFacet) | **POST** /api/v2/search/webhook/{facet} | Lists the values of a specific facet over the customer&#39;s webhooks
*SearchApi* | [**searchReportEventEntities**](docs/SearchApi.md#searchReportEventEntities) | **POST** /api/v2/search/event | Search over a customer&#39;s events
*SearchApi* | [**searchReportEventForFacet**](docs/SearchApi.md#searchReportEventForFacet) | **POST** /api/v2/search/event/{facet} | Lists the values of a specific facet over the customer&#39;s events
*SearchApi* | [**searchReportEventForFacets**](docs/SearchApi.md#searchReportEventForFacets) | **POST** /api/v2/search/event/facets | Lists the values of one or more facets over the customer&#39;s events
*SearchApi* | [**searchTaggedSourceEntities**](docs/SearchApi.md#searchTaggedSourceEntities) | **POST** /api/v2/search/source | Search over a customer&#39;s sources
*SearchApi* | [**searchTaggedSourceForFacet**](docs/SearchApi.md#searchTaggedSourceForFacet) | **POST** /api/v2/search/source/{facet} | Lists the values of a specific facet over the customer&#39;s sources
*SearchApi* | [**searchTaggedSourceForFacets**](docs/SearchApi.md#searchTaggedSourceForFacets) | **POST** /api/v2/search/source/facets | Lists the values of one or more facets over the customer&#39;s sources
*SourceApi* | [**addSourceTag**](docs/SourceApi.md#addSourceTag) | **PUT** /api/v2/source/{id}/tag/{tagValue} | Add a tag to a specific source
*SourceApi* | [**createSource**](docs/SourceApi.md#createSource) | **POST** /api/v2/source | Create metadata (description or tags) for a specific source
*SourceApi* | [**deleteSource**](docs/SourceApi.md#deleteSource) | **DELETE** /api/v2/source/{id} | Delete metadata (description and tags) for a specific source
*SourceApi* | [**getAllSource**](docs/SourceApi.md#getAllSource) | **GET** /api/v2/source | Get all sources for a customer
*SourceApi* | [**getSource**](docs/SourceApi.md#getSource) | **GET** /api/v2/source/{id} | Get a specific source for a customer
*SourceApi* | [**getSourceTags**](docs/SourceApi.md#getSourceTags) | **GET** /api/v2/source/{id}/tag | Get all tags associated with a specific source
*SourceApi* | [**removeSourceTag**](docs/SourceApi.md#removeSourceTag) | **DELETE** /api/v2/source/{id}/tag/{tagValue} | Remove a tag from a specific source
*SourceApi* | [**setSourceTags**](docs/SourceApi.md#setSourceTags) | **POST** /api/v2/source/{id}/tag | Set all tags associated with a specific source
*SourceApi* | [**updateSource**](docs/SourceApi.md#updateSource) | **PUT** /api/v2/source/{id} | Update metadata (description or tags) for a specific source
*UserApi* | [**createOrUpdateUser**](docs/UserApi.md#createOrUpdateUser) | **POST** /api/v2/user | Creates or updates a user
*UserApi* | [**deleteUser**](docs/UserApi.md#deleteUser) | **DELETE** /api/v2/user/{id} | Deletes a user identified by id
*UserApi* | [**getAllUser**](docs/UserApi.md#getAllUser) | **GET** /api/v2/user | Get all users
*UserApi* | [**getUser**](docs/UserApi.md#getUser) | **GET** /api/v2/user/{id} | Retrieves a user by identifier (email addr)
*UserApi* | [**grantUserPermission**](docs/UserApi.md#grantUserPermission) | **POST** /api/v2/user/{id}/grant | Grants a specific user permission
*UserApi* | [**revokeUserPermission**](docs/UserApi.md#revokeUserPermission) | **POST** /api/v2/user/{id}/revoke | Revokes a specific user permission
*WebhookApi* | [**createWebhook**](docs/WebhookApi.md#createWebhook) | **POST** /api/v2/webhook | Create a specific webhook
*WebhookApi* | [**deleteWebhook**](docs/WebhookApi.md#deleteWebhook) | **DELETE** /api/v2/webhook/{id} | Delete a specific webhook
*WebhookApi* | [**getAllWebhooks**](docs/WebhookApi.md#getAllWebhooks) | **GET** /api/v2/webhook | Get all webhooks for a customer
*WebhookApi* | [**getWebhook**](docs/WebhookApi.md#getWebhook) | **GET** /api/v2/webhook/{id} | Get a specific webhook
*WebhookApi* | [**updateWebhook**](docs/WebhookApi.md#updateWebhook) | **PUT** /api/v2/webhook/{id} | Update a specific webhook


## Documentation for Models

 - [AWSBaseCredentials](docs/AWSBaseCredentials.md)
 - [Agent](docs/Agent.md)
 - [Alert](docs/Alert.md)
 - [AvroBackedStandardizedDTO](docs/AvroBackedStandardizedDTO.md)
 - [Chart](docs/Chart.md)
 - [ChartSettings](docs/ChartSettings.md)
 - [ChartSourceQuery](docs/ChartSourceQuery.md)
 - [CloudIntegration](docs/CloudIntegration.md)
 - [CloudTrailConfiguration](docs/CloudTrailConfiguration.md)
 - [CloudWatchConfiguration](docs/CloudWatchConfiguration.md)
 - [Dashboard](docs/Dashboard.md)
 - [DashboardParameterValue](docs/DashboardParameterValue.md)
 - [DashboardSection](docs/DashboardSection.md)
 - [DashboardSectionRow](docs/DashboardSectionRow.md)
 - [EC2Configuration](docs/EC2Configuration.md)
 - [Event](docs/Event.md)
 - [EventSearchRequest](docs/EventSearchRequest.md)
 - [EventTimeRange](docs/EventTimeRange.md)
 - [ExternalLink](docs/ExternalLink.md)
 - [FacetResponse](docs/FacetResponse.md)
 - [FacetSearchRequestContainer](docs/FacetSearchRequestContainer.md)
 - [FacetsResponseContainer](docs/FacetsResponseContainer.md)
 - [FacetsSearchRequestContainer](docs/FacetsSearchRequestContainer.md)
 - [HistoryEntry](docs/HistoryEntry.md)
 - [HistoryResponse](docs/HistoryResponse.md)
 - [IteratorEntryStringJsonNode](docs/IteratorEntryStringJsonNode.md)
 - [IteratorJsonNode](docs/IteratorJsonNode.md)
 - [IteratorString](docs/IteratorString.md)
 - [MaintenanceWindow](docs/MaintenanceWindow.md)
 - [Message](docs/Message.md)
 - [MetricDetails](docs/MetricDetails.md)
 - [Number](docs/Number.md)
 - [Paged](docs/Paged.md)
 - [PagedAgent](docs/PagedAgent.md)
 - [PagedAlert](docs/PagedAlert.md)
 - [PagedCloudIntegration](docs/PagedCloudIntegration.md)
 - [PagedDashboard](docs/PagedDashboard.md)
 - [PagedEvent](docs/PagedEvent.md)
 - [PagedExternalLink](docs/PagedExternalLink.md)
 - [PagedMaintenanceWindow](docs/PagedMaintenanceWindow.md)
 - [PagedMessage](docs/PagedMessage.md)
 - [PagedSavedSearch](docs/PagedSavedSearch.md)
 - [PagedSource](docs/PagedSource.md)
 - [PagedWebhook](docs/PagedWebhook.md)
 - [Point](docs/Point.md)
 - [QueryKeyContainer](docs/QueryKeyContainer.md)
 - [QueryResult](docs/QueryResult.md)
 - [ReportEvent](docs/ReportEvent.md)
 - [ResponseContainer](docs/ResponseContainer.md)
 - [ResponseContainerAgent](docs/ResponseContainerAgent.md)
 - [ResponseContainerAlert](docs/ResponseContainerAlert.md)
 - [ResponseContainerCloudIntegration](docs/ResponseContainerCloudIntegration.md)
 - [ResponseContainerDashboard](docs/ResponseContainerDashboard.md)
 - [ResponseContainerEvent](docs/ResponseContainerEvent.md)
 - [ResponseContainerExternalLink](docs/ResponseContainerExternalLink.md)
 - [ResponseContainerFacetResponse](docs/ResponseContainerFacetResponse.md)
 - [ResponseContainerFacetsResponseContainer](docs/ResponseContainerFacetsResponseContainer.md)
 - [ResponseContainerHistoryResponse](docs/ResponseContainerHistoryResponse.md)
 - [ResponseContainerMaintenanceWindow](docs/ResponseContainerMaintenanceWindow.md)
 - [ResponseContainerMapStringInteger](docs/ResponseContainerMapStringInteger.md)
 - [ResponseContainerMessage](docs/ResponseContainerMessage.md)
 - [ResponseContainerPaged](docs/ResponseContainerPaged.md)
 - [ResponseContainerPagedAgent](docs/ResponseContainerPagedAgent.md)
 - [ResponseContainerPagedAlert](docs/ResponseContainerPagedAlert.md)
 - [ResponseContainerPagedCloudIntegration](docs/ResponseContainerPagedCloudIntegration.md)
 - [ResponseContainerPagedDashboard](docs/ResponseContainerPagedDashboard.md)
 - [ResponseContainerPagedEvent](docs/ResponseContainerPagedEvent.md)
 - [ResponseContainerPagedExternalLink](docs/ResponseContainerPagedExternalLink.md)
 - [ResponseContainerPagedMaintenanceWindow](docs/ResponseContainerPagedMaintenanceWindow.md)
 - [ResponseContainerPagedMessage](docs/ResponseContainerPagedMessage.md)
 - [ResponseContainerPagedSavedSearch](docs/ResponseContainerPagedSavedSearch.md)
 - [ResponseContainerPagedSource](docs/ResponseContainerPagedSource.md)
 - [ResponseContainerPagedWebhook](docs/ResponseContainerPagedWebhook.md)
 - [ResponseContainerSavedSearch](docs/ResponseContainerSavedSearch.md)
 - [ResponseContainerSource](docs/ResponseContainerSource.md)
 - [ResponseContainerTagsResponse](docs/ResponseContainerTagsResponse.md)
 - [ResponseContainerWebhook](docs/ResponseContainerWebhook.md)
 - [ResponseStatus](docs/ResponseStatus.md)
 - [SavedSearch](docs/SavedSearch.md)
 - [ScopedDTOConverter](docs/ScopedDTOConverter.md)
 - [SearchQuery](docs/SearchQuery.md)
 - [SortableSearchRequest](docs/SortableSearchRequest.md)
 - [Sorting](docs/Sorting.md)
 - [Source](docs/Source.md)
 - [SourceLabelPair](docs/SourceLabelPair.md)
 - [SourceSearchRequestContainer](docs/SourceSearchRequestContainer.md)
 - [StatsModel](docs/StatsModel.md)
 - [TagsResponse](docs/TagsResponse.md)
 - [Timeseries](docs/Timeseries.md)
 - [TimeseriesStatsContainer](docs/TimeseriesStatsContainer.md)
 - [UserModel](docs/UserModel.md)
 - [UserToCreate](docs/UserToCreate.md)
 - [WFTags](docs/WFTags.md)
 - [Webhook](docs/Webhook.md)


## Documentation for Authorization

Authentication schemes defined for the API:
### api_key

- **Type**: API key
- **API key parameter name**: X-AUTH-TOKEN
- **Location**: HTTP header


## Recommendation

It's recommended to create an instance of `ApiClient` per thread in a multithreaded environment to avoid any potential issue.

## Author



