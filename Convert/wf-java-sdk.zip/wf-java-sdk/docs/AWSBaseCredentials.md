
# AWSBaseCredentials

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**roleArn** | **String** | The Role ARN that the customer has created in AWS IAM to allow access to Wavefront | 
**externalId** | **String** | The external id corresponding to the Role ARN | 



