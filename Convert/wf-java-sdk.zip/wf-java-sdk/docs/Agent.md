
# Agent

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | Agent name (modifiable) |  [optional]
**id** | **String** |  |  [optional]
**version** | **String** |  |  [optional]
**lastCheckInTime** | **Long** | Last time when this agent checked in (in milliseconds since the unix epoch) |  [optional]
**hostname** | **String** | Host name of the machine running the agent |  [optional]
**customerId** | **String** |  |  [optional]
**lastKnownError** | **String** | deprecated |  [optional]
**lastErrorTime** | **Long** | deprecated |  [optional]
**lastErrorEvent** | [**Event**](Event.md) |  |  [optional]
**timeDrift** | **Long** | Time drift of the agent&#39;s clock compared to Wavefront servers |  [optional]
**bytesLeftForBuffer** | **Long** | Number of bytes of space remaining in the persistent disk queue of this agent |  [optional]
**bytesPerMinuteForBuffer** | **Long** | Bytes used per minute by the persistent disk queue of this agent |  [optional]
**localQueueSize** | **Long** | Number of items in the persistent disk queue of this agent |  [optional]
**sshAgent** | **Boolean** | deprecated |  [optional]
**inTrash** | **Boolean** |  |  [optional]
**ephemeral** | **Boolean** | When true, this agent is expected to be ephemeral (possibly hosted on a short-lived container) and will be deleted after a period of inactivity (not checking in) |  [optional]
**deleted** | **Boolean** |  |  [optional]



