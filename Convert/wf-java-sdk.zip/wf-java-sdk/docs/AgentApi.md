# AgentApi

All URIs are relative to *https://localhost/*

Method | HTTP request | Description
------------- | ------------- | -------------
[**deleteAgent**](AgentApi.md#deleteAgent) | **DELETE** /api/v2/agent/{id} | Delete a specific agent
[**getAgent**](AgentApi.md#getAgent) | **GET** /api/v2/agent/{id} | Get a specific agent
[**getAllAgent**](AgentApi.md#getAllAgent) | **GET** /api/v2/agent | Get all agents for a customer
[**undeleteAgent**](AgentApi.md#undeleteAgent) | **POST** /api/v2/agent/{id}/undelete | Undelete a specific agent
[**updateAgent**](AgentApi.md#updateAgent) | **PUT** /api/v2/agent/{id} | Update the name of a specific agent


<a name="deleteAgent"></a>
# **deleteAgent**
> ResponseContainerAgent deleteAgent(id)

Delete a specific agent



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.AgentApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

AgentApi apiInstance = new AgentApi();
String id = "id_example"; // String | 
try {
    ResponseContainerAgent result = apiInstance.deleteAgent(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AgentApi#deleteAgent");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |

### Return type

[**ResponseContainerAgent**](ResponseContainerAgent.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getAgent"></a>
# **getAgent**
> ResponseContainerAgent getAgent(id)

Get a specific agent



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.AgentApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

AgentApi apiInstance = new AgentApi();
String id = "id_example"; // String | 
try {
    ResponseContainerAgent result = apiInstance.getAgent(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AgentApi#getAgent");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |

### Return type

[**ResponseContainerAgent**](ResponseContainerAgent.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getAllAgent"></a>
# **getAllAgent**
> ResponseContainerPagedAgent getAllAgent(offset, limit)

Get all agents for a customer



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.AgentApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

AgentApi apiInstance = new AgentApi();
Integer offset = 0; // Integer | 
Integer limit = 100; // Integer | 
try {
    ResponseContainerPagedAgent result = apiInstance.getAllAgent(offset, limit);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AgentApi#getAllAgent");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **offset** | **Integer**|  | [optional] [default to 0]
 **limit** | **Integer**|  | [optional] [default to 100]

### Return type

[**ResponseContainerPagedAgent**](ResponseContainerPagedAgent.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="undeleteAgent"></a>
# **undeleteAgent**
> ResponseContainerAgent undeleteAgent(id)

Undelete a specific agent



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.AgentApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

AgentApi apiInstance = new AgentApi();
String id = "id_example"; // String | 
try {
    ResponseContainerAgent result = apiInstance.undeleteAgent(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AgentApi#undeleteAgent");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |

### Return type

[**ResponseContainerAgent**](ResponseContainerAgent.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="updateAgent"></a>
# **updateAgent**
> ResponseContainerAgent updateAgent(id, body)

Update the name of a specific agent



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.AgentApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

AgentApi apiInstance = new AgentApi();
String id = "id_example"; // String | 
Agent body = new Agent(); // Agent | Example Body:  <pre>{   \"name\": \"New Name for Agent\" }</pre>
try {
    ResponseContainerAgent result = apiInstance.updateAgent(id, body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AgentApi#updateAgent");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |
 **body** | [**Agent**](Agent.md)| Example Body:  &lt;pre&gt;{   \&quot;name\&quot;: \&quot;New Name for Agent\&quot; }&lt;/pre&gt; | [optional]

### Return type

[**ResponseContainerAgent**](ResponseContainerAgent.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

