
# Alert

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**created** | **Long** | When this alert was created, in epoch millis |  [optional]
**name** | **String** |  | 
**id** | **String** |  |  [optional]
**target** | **String** | The email address or integration endpoint (such as PagerDuty or webhook) to notify when the alert status changes | 
**minutes** | **Integer** | The number of consecutive minutes that a series matching the condition query must evaluate to \&quot;true\&quot; (non-zero value) before the alert fires | 
**tags** | [**WFTags**](WFTags.md) |  |  [optional]
**status** | **List&lt;String&gt;** | Lists the current state of the alert. Can be one or more of: FIRING, SNOOZED, IN_MAINTENANCE, INVALID, NONE, CHECKING, TRASH |  [optional]
**lastProcessedMillis** | **Long** | The time when this alert was last checked, in epoch millis |  [optional]
**processRateMinutes** | **Integer** | The interval between checks for this alert, in minutes.  Defaults to 1 minute |  [optional]
**pointsScannedAtLastQuery** | **Long** | A derived field recording the number of data points scanned when the system last computed this alert&#39;s condition |  [optional]
**lastNotificationMillis** | **Long** | When this alert last caused a notification, in epoch millis |  [optional]
**notificationResendFrequencyMinutes** | **Long** | How often to re-trigger a continually failing alert. If absent or &lt;&#x3D; 0, no retriggering occurs |  [optional]
**createdEpochMillis** | **Long** |  |  [optional]
**updatedEpochMillis** | **Long** |  |  [optional]
**updaterId** | **String** |  |  [optional]
**creatorId** | **String** |  |  [optional]
**inTrash** | **Boolean** |  |  [optional]
**notificants** | **List&lt;String&gt;** | A derived field listing the webhook ids used by this alert |  [optional]
**createUserId** | **String** |  |  [optional]
**condition** | **String** | A Wavefront query that is evaluated at regular intervals (default 1m).  The alert fires and notifications are triggered when a data series matching this query evaluates to a non-zero value for a set number of consecutive minutes | 
**conditionQBEnabled** | **Boolean** | Whether the condition query was created using the Query Builder.  Default false |  [optional]
**conditionQBSerialization** | **String** | The special serialization of the Query Builder that corresponds to the condition query.  Applicable only when conditionQBEnabled is true |  [optional]
**displayExpression** | **String** | A second query whose results are displayed in the alert user interface instead of the condition query. This field is often used to display a version of the condition query with Boolean operators removed so that numerical values are plotted |  [optional]
**displayExpressionQBEnabled** | **Boolean** | Whether the display expression query was created using the Query Builder. Default false |  [optional]
**displayExpressionQBSerialization** | **String** | The special serialization of the Query Builder that corresponds to the display expression query.  Applicable only when displayExpressionQBEnabled is true |  [optional]
**resolveAfterMinutes** | **Integer** | The number of consecutive minutes that a firing series matching the condition query must evaluate to \&quot;false\&quot; (zero value) before the alert resolves.  When unset, this defaults to the same value as \&quot;minutes\&quot; |  [optional]
**snoozed** | **Long** | The until which time this alert is snoozed (not checked), in epoch millis.  A negative value implies the alert is snoozed indefinitely |  [optional]
**event** | [**Event**](Event.md) | The event associated with the firing of the alert. Can be null if the alert has never fired. If the alert is not currently firing, the event holds the last known firing of the alert |  [optional]
**failingHostLabelPairs** | [**List&lt;SourceLabelPair&gt;**](SourceLabelPair.md) | Failing host/metric pairs |  [optional]
**updated** | **Long** | When the alert was last updated, in epoch millis |  [optional]
**severity** | [**SeverityEnum**](#SeverityEnum) | Severity of the alert | 
**queryFailing** | **Boolean** | Whether there was an exception when the alert condition last ran |  [optional]
**lastFailedTime** | **Long** | The time of the last error encountered when running this alert&#39;s condition query, in epoch millis |  [optional]
**lastErrorMessage** | **String** | The last error encountered when running this alert&#39;s condition query |  [optional]
**additionalInformation** | **String** | User-supplied additional explanatory information for this alert.  Useful for linking runbooks, mitigations,, etc |  [optional]
**metricsUsed** | **List&lt;String&gt;** | Number of metrics checked by the alert condition |  [optional]
**hostsUsed** | **List&lt;String&gt;** | Number of hosts checked by the alert condition |  [optional]
**inMaintenanceHostLabelPairs** | [**List&lt;SourceLabelPair&gt;**](SourceLabelPair.md) | Lists the sources that will not be checked for this alert, due to matching a maintenance window |  [optional]
**activeMaintenanceWindows** | **List&lt;String&gt;** | The names of the active maintenance windows that are affecting this alert |  [optional]
**updateUserId** | **String** | The user that last updated this alert |  [optional]
**prefiringHostLabelPairs** | [**List&lt;SourceLabelPair&gt;**](SourceLabelPair.md) | Lists the series that are starting to fail, defined as failing for greater than 50% of the checks in the window determined by the \&quot;minutes\&quot; parameter |  [optional]
**deleted** | **Boolean** |  |  [optional]


<a name="SeverityEnum"></a>
## Enum: SeverityEnum
Name | Value
---- | -----
INFO | &quot;INFO&quot;
SMOKE | &quot;SMOKE&quot;
WARN | &quot;WARN&quot;
SEVERE | &quot;SEVERE&quot;



