# AlertApi

All URIs are relative to *https://localhost/*

Method | HTTP request | Description
------------- | ------------- | -------------
[**addAlertTag**](AlertApi.md#addAlertTag) | **PUT** /api/v2/alert/{id}/tag/{tagValue} | Add a tag to a specific alert
[**createAlert**](AlertApi.md#createAlert) | **POST** /api/v2/alert | Create a specific alert
[**deleteAlert**](AlertApi.md#deleteAlert) | **DELETE** /api/v2/alert/{id} | Delete a specific alert
[**getAlert**](AlertApi.md#getAlert) | **GET** /api/v2/alert/{id} | Get a specific alert
[**getAlertHistory**](AlertApi.md#getAlertHistory) | **GET** /api/v2/alert/{id}/history | Get the version history of a specific alert
[**getAlertTags**](AlertApi.md#getAlertTags) | **GET** /api/v2/alert/{id}/tag | Get all tags associated with a specific alert
[**getAlertVersion**](AlertApi.md#getAlertVersion) | **GET** /api/v2/alert/{id}/history/{version} | Get a specific historical version of a specific alert
[**getAlertsSummary**](AlertApi.md#getAlertsSummary) | **GET** /api/v2/alert/summary | Count alerts of various statuses for a customer
[**getAllAlert**](AlertApi.md#getAllAlert) | **GET** /api/v2/alert | Get all alerts for a customer
[**removeAlertTag**](AlertApi.md#removeAlertTag) | **DELETE** /api/v2/alert/{id}/tag/{tagValue} | Remove a tag from a specific alert
[**setAlertTags**](AlertApi.md#setAlertTags) | **POST** /api/v2/alert/{id}/tag | Set all tags associated with a specific alert
[**snoozeAlert**](AlertApi.md#snoozeAlert) | **POST** /api/v2/alert/{id}/snooze | Snooze a specific alert for some number of seconds
[**undeleteAlert**](AlertApi.md#undeleteAlert) | **POST** /api/v2/alert/{id}/undelete | Undelete a specific alert
[**unsnoozeAlert**](AlertApi.md#unsnoozeAlert) | **POST** /api/v2/alert/{id}/unsnooze | Unsnooze a specific alert
[**updateAlert**](AlertApi.md#updateAlert) | **PUT** /api/v2/alert/{id} | Update a specific alert


<a name="addAlertTag"></a>
# **addAlertTag**
> ResponseContainer addAlertTag(id, tagValue)

Add a tag to a specific alert



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.AlertApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

AlertApi apiInstance = new AlertApi();
String id = "id_example"; // String | 
String tagValue = "tagValue_example"; // String | 
try {
    ResponseContainer result = apiInstance.addAlertTag(id, tagValue);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AlertApi#addAlertTag");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |
 **tagValue** | **String**|  |

### Return type

[**ResponseContainer**](ResponseContainer.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="createAlert"></a>
# **createAlert**
> ResponseContainerAlert createAlert(body)

Create a specific alert



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.AlertApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

AlertApi apiInstance = new AlertApi();
Alert body = new Alert(); // Alert | Example Body:  <pre>{   \"name\": \"Alert Name\",   \"target\": \"user@example.com\",   \"condition\": \"ts() > 1\",   \"displayExpression\": \"ts()\",   \"minutes\": 5,   \"resolveAfterMinutes\": 2,   \"severity\": \"INFO\",   \"additionalInformation\": \"Additional Info\" }</pre>
try {
    ResponseContainerAlert result = apiInstance.createAlert(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AlertApi#createAlert");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Alert**](Alert.md)| Example Body:  &lt;pre&gt;{   \&quot;name\&quot;: \&quot;Alert Name\&quot;,   \&quot;target\&quot;: \&quot;user@example.com\&quot;,   \&quot;condition\&quot;: \&quot;ts() &gt; 1\&quot;,   \&quot;displayExpression\&quot;: \&quot;ts()\&quot;,   \&quot;minutes\&quot;: 5,   \&quot;resolveAfterMinutes\&quot;: 2,   \&quot;severity\&quot;: \&quot;INFO\&quot;,   \&quot;additionalInformation\&quot;: \&quot;Additional Info\&quot; }&lt;/pre&gt; | [optional]

### Return type

[**ResponseContainerAlert**](ResponseContainerAlert.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="deleteAlert"></a>
# **deleteAlert**
> ResponseContainerAlert deleteAlert(id)

Delete a specific alert



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.AlertApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

AlertApi apiInstance = new AlertApi();
String id = "id_example"; // String | 
try {
    ResponseContainerAlert result = apiInstance.deleteAlert(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AlertApi#deleteAlert");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |

### Return type

[**ResponseContainerAlert**](ResponseContainerAlert.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getAlert"></a>
# **getAlert**
> ResponseContainerAlert getAlert(id)

Get a specific alert



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.AlertApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

AlertApi apiInstance = new AlertApi();
String id = "id_example"; // String | 
try {
    ResponseContainerAlert result = apiInstance.getAlert(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AlertApi#getAlert");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |

### Return type

[**ResponseContainerAlert**](ResponseContainerAlert.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getAlertHistory"></a>
# **getAlertHistory**
> ResponseContainerHistoryResponse getAlertHistory(id, offset, limit)

Get the version history of a specific alert



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.AlertApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

AlertApi apiInstance = new AlertApi();
String id = "id_example"; // String | 
Integer offset = 0; // Integer | 
Integer limit = 100; // Integer | 
try {
    ResponseContainerHistoryResponse result = apiInstance.getAlertHistory(id, offset, limit);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AlertApi#getAlertHistory");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |
 **offset** | **Integer**|  | [optional] [default to 0]
 **limit** | **Integer**|  | [optional] [default to 100]

### Return type

[**ResponseContainerHistoryResponse**](ResponseContainerHistoryResponse.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getAlertTags"></a>
# **getAlertTags**
> ResponseContainerTagsResponse getAlertTags(id)

Get all tags associated with a specific alert



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.AlertApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

AlertApi apiInstance = new AlertApi();
String id = "id_example"; // String | 
try {
    ResponseContainerTagsResponse result = apiInstance.getAlertTags(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AlertApi#getAlertTags");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |

### Return type

[**ResponseContainerTagsResponse**](ResponseContainerTagsResponse.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getAlertVersion"></a>
# **getAlertVersion**
> ResponseContainerAlert getAlertVersion(id, version)

Get a specific historical version of a specific alert



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.AlertApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

AlertApi apiInstance = new AlertApi();
String id = "id_example"; // String | 
Long version = 789L; // Long | 
try {
    ResponseContainerAlert result = apiInstance.getAlertVersion(id, version);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AlertApi#getAlertVersion");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |
 **version** | **Long**|  |

### Return type

[**ResponseContainerAlert**](ResponseContainerAlert.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getAlertsSummary"></a>
# **getAlertsSummary**
> ResponseContainerMapStringInteger getAlertsSummary()

Count alerts of various statuses for a customer



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.AlertApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

AlertApi apiInstance = new AlertApi();
try {
    ResponseContainerMapStringInteger result = apiInstance.getAlertsSummary();
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AlertApi#getAlertsSummary");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**ResponseContainerMapStringInteger**](ResponseContainerMapStringInteger.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getAllAlert"></a>
# **getAllAlert**
> ResponseContainerPagedAlert getAllAlert(offset, limit)

Get all alerts for a customer



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.AlertApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

AlertApi apiInstance = new AlertApi();
Integer offset = 0; // Integer | 
Integer limit = 100; // Integer | 
try {
    ResponseContainerPagedAlert result = apiInstance.getAllAlert(offset, limit);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AlertApi#getAllAlert");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **offset** | **Integer**|  | [optional] [default to 0]
 **limit** | **Integer**|  | [optional] [default to 100]

### Return type

[**ResponseContainerPagedAlert**](ResponseContainerPagedAlert.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="removeAlertTag"></a>
# **removeAlertTag**
> ResponseContainer removeAlertTag(id, tagValue)

Remove a tag from a specific alert



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.AlertApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

AlertApi apiInstance = new AlertApi();
String id = "id_example"; // String | 
String tagValue = "tagValue_example"; // String | 
try {
    ResponseContainer result = apiInstance.removeAlertTag(id, tagValue);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AlertApi#removeAlertTag");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |
 **tagValue** | **String**|  |

### Return type

[**ResponseContainer**](ResponseContainer.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="setAlertTags"></a>
# **setAlertTags**
> ResponseContainer setAlertTags(id, body)

Set all tags associated with a specific alert



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.AlertApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

AlertApi apiInstance = new AlertApi();
String id = "id_example"; // String | 
List<String> body = Arrays.asList(new List<String>()); // List<String> | 
try {
    ResponseContainer result = apiInstance.setAlertTags(id, body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AlertApi#setAlertTags");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |
 **body** | **List&lt;String&gt;**|  | [optional]

### Return type

[**ResponseContainer**](ResponseContainer.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="snoozeAlert"></a>
# **snoozeAlert**
> ResponseContainerAlert snoozeAlert(id, seconds)

Snooze a specific alert for some number of seconds



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.AlertApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

AlertApi apiInstance = new AlertApi();
String id = "id_example"; // String | 
Long seconds = 789L; // Long | 
try {
    ResponseContainerAlert result = apiInstance.snoozeAlert(id, seconds);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AlertApi#snoozeAlert");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |
 **seconds** | **Long**|  | [optional]

### Return type

[**ResponseContainerAlert**](ResponseContainerAlert.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="undeleteAlert"></a>
# **undeleteAlert**
> ResponseContainerAlert undeleteAlert(id)

Undelete a specific alert



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.AlertApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

AlertApi apiInstance = new AlertApi();
String id = "id_example"; // String | 
try {
    ResponseContainerAlert result = apiInstance.undeleteAlert(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AlertApi#undeleteAlert");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |

### Return type

[**ResponseContainerAlert**](ResponseContainerAlert.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="unsnoozeAlert"></a>
# **unsnoozeAlert**
> ResponseContainerAlert unsnoozeAlert(id)

Unsnooze a specific alert



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.AlertApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

AlertApi apiInstance = new AlertApi();
String id = "id_example"; // String | 
try {
    ResponseContainerAlert result = apiInstance.unsnoozeAlert(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AlertApi#unsnoozeAlert");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |

### Return type

[**ResponseContainerAlert**](ResponseContainerAlert.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="updateAlert"></a>
# **updateAlert**
> ResponseContainerAlert updateAlert(id, body)

Update a specific alert



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.AlertApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

AlertApi apiInstance = new AlertApi();
String id = "id_example"; // String | 
Alert body = new Alert(); // Alert | Example Body:  <pre>{   \"id\": \"1459375928549\",   \"name\": \"Alert Name\",   \"target\": \"user@example.com\",   \"condition\": \"ts() > 1\",   \"displayExpression\": \"ts()\",   \"minutes\": 5,   \"resolveAfterMinutes\": 2,   \"severity\": \"INFO\",   \"additionalInformation\": \"Additional Info\" }</pre>
try {
    ResponseContainerAlert result = apiInstance.updateAlert(id, body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AlertApi#updateAlert");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |
 **body** | [**Alert**](Alert.md)| Example Body:  &lt;pre&gt;{   \&quot;id\&quot;: \&quot;1459375928549\&quot;,   \&quot;name\&quot;: \&quot;Alert Name\&quot;,   \&quot;target\&quot;: \&quot;user@example.com\&quot;,   \&quot;condition\&quot;: \&quot;ts() &gt; 1\&quot;,   \&quot;displayExpression\&quot;: \&quot;ts()\&quot;,   \&quot;minutes\&quot;: 5,   \&quot;resolveAfterMinutes\&quot;: 2,   \&quot;severity\&quot;: \&quot;INFO\&quot;,   \&quot;additionalInformation\&quot;: \&quot;Additional Info\&quot; }&lt;/pre&gt; | [optional]

### Return type

[**ResponseContainerAlert**](ResponseContainerAlert.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

