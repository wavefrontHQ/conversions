
# AvroBackedStandardizedDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  |  [optional]
**createdEpochMillis** | **Long** |  |  [optional]
**updatedEpochMillis** | **Long** |  |  [optional]
**updaterId** | **String** |  |  [optional]
**creatorId** | **String** |  |  [optional]
**deleted** | **Boolean** |  |  [optional]



