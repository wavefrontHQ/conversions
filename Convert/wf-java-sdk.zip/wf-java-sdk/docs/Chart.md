
# Chart

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | Name of the source | 
**description** | **String** | Description of the chart |  [optional]
**chartSettings** | [**ChartSettings**](ChartSettings.md) | Chart settings |  [optional]
**noDefaultEvents** | **Boolean** | Whether to hide events related to the sources in the charts produced. Default false (i.e. shows events) |  [optional]
**interpolatePoints** | **Boolean** | Whether to interpolate points in the charts produced. Default: true |  [optional]
**summarization** | [**SummarizationEnum**](#SummarizationEnum) | Summarization strategy for the chart.  MEAN is default |  [optional]
**sources** | [**List&lt;ChartSourceQuery&gt;**](ChartSourceQuery.md) | Query expression to plot on the chart | 
**units** | **String** | String to label the units of the chart on the Y-axis |  [optional]
**base** | **Integer** | If the chart has a log-scale Y-axis, the base for the logarithms |  [optional]
**includeObsoleteMetrics** | **Boolean** | Whether to show obsolete metrics.  Default: false |  [optional]


<a name="SummarizationEnum"></a>
## Enum: SummarizationEnum
Name | Value
---- | -----
MEAN | &quot;MEAN&quot;
MEDIAN | &quot;MEDIAN&quot;
MIN | &quot;MIN&quot;
MAX | &quot;MAX&quot;
SUM | &quot;SUM&quot;
COUNT | &quot;COUNT&quot;
LAST | &quot;LAST&quot;
FIRST | &quot;FIRST&quot;



