
# ChartSettings

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | [**TypeEnum**](#TypeEnum) | Chart Type.  &#39;line&#39; refers to the Line Plot, &#39;scatter&#39; to the Point Plot, &#39;stacked-area&#39; to the Stacked Area plot, &#39;table&#39; to the Tabular View, &#39;scatterploy-xy&#39; to Scatter Plot, &#39;markdown-widget&#39; to the Markdown display, and &#39;sparkline&#39; to the Single Stat view | 
**max** | **Double** | Max value of Y-axis.  Set to null or leave blank for auto |  [optional]
**y1Units** | **String** | For plots with multiple Y-axes, units for right-side Y-axis |  [optional]
**min** | **Double** | Min value of Y-axis.  Set to null or leave blank for auto |  [optional]
**y1Max** | **Double** | For plots with multiple Y-axes, max value for right-side Y-axis.  Set null for auto |  [optional]
**y1Min** | **Double** | For plots with multiple Y-axes, min value for right-side Y-axis.  Set null for auto |  [optional]
**windowSize** | **Long** | Width, in minutes, of the time window to use for \&quot;last\&quot; windowing |  [optional]
**y0ScaleSIBy1024** | **Boolean** | Default: false. Whether to scale numerical magnitude labels for left Y-axis by 1024 in the IEC/Binary manner (instead of by 1000 like SI) |  [optional]
**y0UnitAutoscaling** | **Boolean** | Default: false. Whether to automatically adjust magnitude labels and units for the left Y-axis to favor smaller magnitudes and larger units |  [optional]
**y1ScaleSIBy1024** | **Boolean** | Default: false. Whether to scale numerical magnitude labels for right Y-axis by 1024 in the IEC/Binary manner (instead of by 1000 like SI) |  [optional]
**y1UnitAutoscaling** | **Boolean** | Default: false. Whether to automatically adjust magnitude labels and units for the right Y-axis to favor smaller magnitudes and larger units |  [optional]
**expectedDataSpacing** | **Long** | Threshold (in seconds) for time delta between consecutive points in a series above which a dotted line will replace a solid line in line plots.  Default: 60s |  [optional]
**lineType** | [**LineTypeEnum**](#LineTypeEnum) | Plot interpolation type.  linear is default |  [optional]
**groupBySource** | **Boolean** | For the tabular view, whether to group multi metrics into a single row by a common source.  If false, each metric for each source is displayed in its own row.  If true, multiple metrics for the same host will be displayed as different columns in the same row |  [optional]
**stackType** | [**StackTypeEnum**](#StackTypeEnum) | Type of stacked chart (applicable only if chart type is stacked).  zero (default) means stacked from y&#x3D;0.  expand means Normalized from 0 to 1.  wiggle means Minimize weighted changes. silhouette means to Center the Stream |  [optional]
**ymax** | **Double** | For x-y scatterplots, max value for Y-axis.  Set null for auto |  [optional]
**ymin** | **Double** | For x-y scatterplots, min value for Y-axis.  Set null for auto |  [optional]
**xmax** | **Double** | For x-y scatterplots, max value for X-axis.  Set null for auto |  [optional]
**xmin** | **Double** | For x-y scatterplots, min value for X-axis.  Set null for auto |  [optional]
**timeBasedColoring** | **Boolean** | Fox x-y scatterplots, whether to color more recent points as darker than older points. Default: false |  [optional]
**customTags** | **List&lt;String&gt;** | For the tabular view, a list of point tags to display when using the \&quot;custom\&quot; tag display mode |  [optional]
**windowing** | [**WindowingEnum**](#WindowingEnum) | For the tabular view, whether to use the full time window for the query or the last X minutes |  [optional]
**numTags** | **Integer** | For the tabular view, how many point tags to display |  [optional]
**showHosts** | **Boolean** | For the tabular view, whether to display sources.  Default: true |  [optional]
**showLabels** | **Boolean** | For the tabular view, whether to display labels.  Default: true |  [optional]
**showRawValues** | **Boolean** | For the tabular view, whether to display raw values.  Default: false |  [optional]
**sortValuesDescending** | **Boolean** | For the tabular view, whether to display display values in descending order.  Default: false |  [optional]
**tagMode** | [**TagModeEnum**](#TagModeEnum) | For the tabular view, which mode to use to determine which point tags to display |  [optional]
**fixedLegendEnabled** | **Boolean** | Whether to enable a fixed tabular legend adjacent to the chart |  [optional]
**fixedLegendPosition** | [**FixedLegendPositionEnum**](#FixedLegendPositionEnum) | Where the fixed legend should be displayed with respect to the chart |  [optional]
**fixedLegendDisplayStats** | **List&lt;String&gt;** | For a chart with a fixed legend, a list of statistics to display in the legend |  [optional]
**fixedLegendFilterField** | [**FixedLegendFilterFieldEnum**](#FixedLegendFilterFieldEnum) | Statistic to use for determining whether a series is displayed on the fixed legend |  [optional]
**fixedLegendFilterLimit** | **Integer** | Number of series to include in the fixed legend |  [optional]
**fixedLegendFilterSort** | [**FixedLegendFilterSortEnum**](#FixedLegendFilterSortEnum) | Whether to display \&quot;Top\&quot;- or \&quot;Bottom\&quot;-ranked series in the fixed legend |  [optional]
**fixedLegendUseRawStats** | **Boolean** | If true, the legend uses non-summarized stats instead of summarized |  [optional]
**invertDynamicLegendHoverControl** | **Boolean** | Whether to disable the display of the floating legend (but reenable it when the ctrl-key is pressed) |  [optional]
**sparklineDisplayFontSize** | **String** | For the single stat view, the font size of the displayed text, in percent |  [optional]
**sparklineDisplayHorizontalPosition** | [**SparklineDisplayHorizontalPositionEnum**](#SparklineDisplayHorizontalPositionEnum) | For the single stat view, the horizontal position of the displayed text |  [optional]
**sparklineDisplayPostfix** | **String** | For the single stat view, a string to append to the displayed text |  [optional]
**sparklineDisplayPrefix** | **String** | For the single stat view, a string to add before the displayed text |  [optional]
**sparklineDisplayValueType** | [**SparklineDisplayValueTypeEnum**](#SparklineDisplayValueTypeEnum) | For the single stat view, whether to display the name of the query or the value of query |  [optional]
**sparklineFillColor** | **String** | For the single stat view, the color of the background fill. Values should be in\&quot;rgba(&lt;rval&gt;, &lt;gval&gt;, &lt;bval&gt;, &lt;aval&gt;\&quot; format |  [optional]
**sparklineLineColor** | **String** | For the single stat view, the color of the line. Values should be in\&quot;rgba(&lt;rval&gt;, &lt;gval&gt;, &lt;bval&gt;, &lt;aval&gt;\&quot; format |  [optional]
**sparklineSize** | [**SparklineSizeEnum**](#SparklineSizeEnum) | For the single stat view, a misleadingly named property.  This determines whether the sparkline of the statistic is displayed in the chart BACKGROUND, BOTTOM, or NONE |  [optional]
**sparklineValueColorMapApplyTo** | [**SparklineValueColorMapApplyToEnum**](#SparklineValueColorMapApplyToEnum) | For the single stat view, whether to apply dynamic color settings to the displayed TEXT or BACKGROUND |  [optional]
**sparklineValueColorMapColors** | **List&lt;String&gt;** | For the single stat view, a list of colors that differing query values map to.  Must contain one more element than sparklineValueColorMapValuesV2. Values should be in\&quot;rgba(&lt;rval&gt;, &lt;gval&gt;, &lt;bval&gt;, &lt;aval&gt;\&quot; format |  [optional]
**sparklineValueColorMapValuesV2** | **List&lt;Float&gt;** | For the single stat view, a list of boundaries for mapping different query values to colors.  Must contain one less element than sparklineValueColorMapColors |  [optional]
**sparklineValueTextMapText** | **List&lt;String&gt;** | For the single stat view, a list of display text values that different query values map to.  Must contain one more element than sparklineValueTextMapThresholds |  [optional]
**sparklineValueTextMapThresholds** | **List&lt;Float&gt;** | For the single stat view, a list of threshold boundaries for mapping different query values to display text. Must contain one less element than sparklineValueTextMapText |  [optional]
**sparklineDecimalPrecision** | **Integer** | For the single stat view, the decimal precision of the displayed number |  [optional]
**sparklineDisplayColor** | **String** | For the single stat view, the color of the displayed text (when not dynamically determined). Values should be in\&quot;rgba(&lt;rval&gt;, &lt;gval&gt;, &lt;bval&gt;, &lt;aval&gt;\&quot; format |  [optional]
**markdownContent** | **String** | The Markdown content for a Markdown display |  [optional]
**sparklineDisplayVerticalPosition** | **String** | deprecated |  [optional]
**sparklineValueColorMapValues** | **List&lt;Long&gt;** | deprecated |  [optional]
**autoColumnTags** | **Boolean** | deprecated |  [optional]
**columnTags** | **String** | deprecated |  [optional]
**fixedLegendHideLabel** | **Boolean** | deprecated |  [optional]


<a name="TypeEnum"></a>
## Enum: TypeEnum
Name | Value
---- | -----
LINE | &quot;line&quot;
SCATTERPLOT | &quot;scatterplot&quot;
STACKED_AREA | &quot;stacked-area&quot;
TABLE | &quot;table&quot;
SCATTERPLOT_XY | &quot;scatterplot-xy&quot;
MARKDOWN_WIDGET | &quot;markdown-widget&quot;
SPARKLINE | &quot;sparkline&quot;


<a name="LineTypeEnum"></a>
## Enum: LineTypeEnum
Name | Value
---- | -----
LINEAR | &quot;linear&quot;
STEP_BEFORE | &quot;step-before&quot;
STEP_AFTER | &quot;step-after&quot;
BASIS | &quot;basis&quot;
CARDINAL | &quot;cardinal&quot;
MONOTONE | &quot;monotone&quot;


<a name="StackTypeEnum"></a>
## Enum: StackTypeEnum
Name | Value
---- | -----
ZERO | &quot;zero&quot;
EXPAND | &quot;expand&quot;
WIGGLE | &quot;wiggle&quot;
SILHOUETTE | &quot;silhouette&quot;


<a name="WindowingEnum"></a>
## Enum: WindowingEnum
Name | Value
---- | -----
FULL | &quot;full&quot;
LAST | &quot;last&quot;


<a name="TagModeEnum"></a>
## Enum: TagModeEnum
Name | Value
---- | -----
ALL | &quot;all&quot;
TOP | &quot;top&quot;
CUSTOM | &quot;custom&quot;


<a name="FixedLegendPositionEnum"></a>
## Enum: FixedLegendPositionEnum
Name | Value
---- | -----
RIGHT | &quot;RIGHT&quot;
TOP | &quot;TOP&quot;
LEFT | &quot;LEFT&quot;
BOTTOM | &quot;BOTTOM&quot;


<a name="FixedLegendFilterFieldEnum"></a>
## Enum: FixedLegendFilterFieldEnum
Name | Value
---- | -----
CURRENT | &quot;CURRENT&quot;
MEAN | &quot;MEAN&quot;
MEDIAN | &quot;MEDIAN&quot;
SUM | &quot;SUM&quot;
MIN | &quot;MIN&quot;
MAX | &quot;MAX&quot;
COUNT | &quot;COUNT&quot;


<a name="FixedLegendFilterSortEnum"></a>
## Enum: FixedLegendFilterSortEnum
Name | Value
---- | -----
TOP | &quot;TOP&quot;
BOTTOM | &quot;BOTTOM&quot;


<a name="SparklineDisplayHorizontalPositionEnum"></a>
## Enum: SparklineDisplayHorizontalPositionEnum
Name | Value
---- | -----
MIDDLE | &quot;MIDDLE&quot;
LEFT | &quot;LEFT&quot;
RIGHT | &quot;RIGHT&quot;


<a name="SparklineDisplayValueTypeEnum"></a>
## Enum: SparklineDisplayValueTypeEnum
Name | Value
---- | -----
VALUE | &quot;VALUE&quot;
LABEL | &quot;LABEL&quot;


<a name="SparklineSizeEnum"></a>
## Enum: SparklineSizeEnum
Name | Value
---- | -----
BACKGROUND | &quot;BACKGROUND&quot;
BOTTOM | &quot;BOTTOM&quot;
NONE | &quot;NONE&quot;


<a name="SparklineValueColorMapApplyToEnum"></a>
## Enum: SparklineValueColorMapApplyToEnum
Name | Value
---- | -----
TEXT | &quot;TEXT&quot;
BACKGROUND | &quot;BACKGROUND&quot;



