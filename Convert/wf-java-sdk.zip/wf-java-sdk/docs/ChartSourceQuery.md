
# ChartSourceQuery

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sourceDescription** | **String** | A description for the purpose of this source |  [optional]
**secondaryAxis** | **Boolean** | Determines if this source relates to the right hand Y-axis or not |  [optional]
**querybuilderEnabled** | **Boolean** | Whether or not this source line should have the query builder enabled |  [optional]
**querybuilderSerialization** | **String** | Opaque representation of the querybuilder |  [optional]
**scatterPlotSource** | [**ScatterPlotSourceEnum**](#ScatterPlotSourceEnum) | For scatter plots, does this query source the X-axis or the Y-axis |  [optional]
**name** | **String** | Name of the source | 
**query** | **String** | Query expression to plot on the chart | 
**disabled** | **Boolean** | Whether the source is disabled |  [optional]


<a name="ScatterPlotSourceEnum"></a>
## Enum: ScatterPlotSourceEnum
Name | Value
---- | -----
X | &quot;X&quot;
Y | &quot;Y&quot;



