
# CloudIntegration

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | The human-readable name of this integration |  [optional]
**id** | **String** |  |  [optional]
**service** | [**ServiceEnum**](#ServiceEnum) | A value denoting which cloud service this integration integrates with |  [optional]
**additionalTags** | **Map&lt;String, String&gt;** | A list of point tag key-values to add to every point ingested using this integration |  [optional]
**lastReceivedDataPointMs** | **Long** | Time that this integration last received a data point, in epoch millis |  [optional]
**lastMetricCount** | **Long** | Number of metrics / events ingested by this integration the last time it ran |  [optional]
**cloudWatch** | [**CloudWatchConfiguration**](CloudWatchConfiguration.md) | CloudWatch specific configurations. Only applicable when service&#x3D;CLOUDWATCH |  [optional]
**cloudTrail** | [**CloudTrailConfiguration**](CloudTrailConfiguration.md) | CloudTrail specific configurations. Only applicable when service&#x3D;CLOUDTRAIL |  [optional]
**ec2** | [**EC2Configuration**](EC2Configuration.md) | EC2 specific configurations. Only applicable when service&#x3D;EC2 |  [optional]
**lastError** | **String** | Digest of the last error encountered by Wavefront servers when fetching data using this integration |  [optional]
**lastErrorMs** | **Long** | Time, in epoch millis, of the last error encountered by Wavefront servers when fetching data using this integration |  [optional]
**lastProcessorId** | **String** | Opaque id of the last Wavefront integrations service to act on this integration |  [optional]
**lastProcessingTimestamp** | **Long** | Time, in epoch millis, that this integration was last processed |  [optional]
**createdEpochMillis** | **Long** |  |  [optional]
**updatedEpochMillis** | **Long** |  |  [optional]
**updaterId** | **String** |  |  [optional]
**creatorId** | **String** |  |  [optional]
**lastErrorEvent** | [**Event**](Event.md) |  |  [optional]
**inTrash** | **Boolean** |  |  [optional]
**deleted** | **Boolean** |  |  [optional]


<a name="ServiceEnum"></a>
## Enum: ServiceEnum
Name | Value
---- | -----
CLOUDWATCH | &quot;CLOUDWATCH&quot;
CLOUDTRAIL | &quot;CLOUDTRAIL&quot;
EC2 | &quot;EC2&quot;



