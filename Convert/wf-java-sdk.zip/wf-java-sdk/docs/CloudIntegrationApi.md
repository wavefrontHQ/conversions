# CloudIntegrationApi

All URIs are relative to *https://localhost/*

Method | HTTP request | Description
------------- | ------------- | -------------
[**createCloudIntegration**](CloudIntegrationApi.md#createCloudIntegration) | **POST** /api/v2/cloudintegration | Create a cloud integration
[**deleteCloudIntegration**](CloudIntegrationApi.md#deleteCloudIntegration) | **DELETE** /api/v2/cloudintegration/{id} | Delete a specific cloud integration
[**getAllCloudIntegration**](CloudIntegrationApi.md#getAllCloudIntegration) | **GET** /api/v2/cloudintegration | Get all cloud integrations for a customer
[**getCloudIntegration**](CloudIntegrationApi.md#getCloudIntegration) | **GET** /api/v2/cloudintegration/{id} | Get a specific cloud integration
[**undeleteCloudIntegration**](CloudIntegrationApi.md#undeleteCloudIntegration) | **POST** /api/v2/cloudintegration/{id}/undelete | Undelete a specific cloud integration
[**updateCloudIntegration**](CloudIntegrationApi.md#updateCloudIntegration) | **PUT** /api/v2/cloudintegration/{id} | Update a specific cloud integration


<a name="createCloudIntegration"></a>
# **createCloudIntegration**
> ResponseContainerCloudIntegration createCloudIntegration(body)

Create a cloud integration



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.CloudIntegrationApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

CloudIntegrationApi apiInstance = new CloudIntegrationApi();
CloudIntegration body = new CloudIntegration(); // CloudIntegration | Example Body:  <pre>{   \"name\":\"CloudWatch integration\",   \"service\":\"CLOUDWATCH\",   \"cloudWatch\":{     \"baseCredentials\":{       \"roleArn\":\"arn:aws:iam::&lt;accountid&gt;:role/&lt;rolename&gt;\",       \"externalId\":\"wave123\"     },     \"metricFilterRegex\":\"^aws.(sqs|ec2|ebs|elb).*$\"   } }</pre>
try {
    ResponseContainerCloudIntegration result = apiInstance.createCloudIntegration(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling CloudIntegrationApi#createCloudIntegration");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**CloudIntegration**](CloudIntegration.md)| Example Body:  &lt;pre&gt;{   \&quot;name\&quot;:\&quot;CloudWatch integration\&quot;,   \&quot;service\&quot;:\&quot;CLOUDWATCH\&quot;,   \&quot;cloudWatch\&quot;:{     \&quot;baseCredentials\&quot;:{       \&quot;roleArn\&quot;:\&quot;arn:aws:iam::&amp;lt;accountid&amp;gt;:role/&amp;lt;rolename&amp;gt;\&quot;,       \&quot;externalId\&quot;:\&quot;wave123\&quot;     },     \&quot;metricFilterRegex\&quot;:\&quot;^aws.(sqs|ec2|ebs|elb).*$\&quot;   } }&lt;/pre&gt; | [optional]

### Return type

[**ResponseContainerCloudIntegration**](ResponseContainerCloudIntegration.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="deleteCloudIntegration"></a>
# **deleteCloudIntegration**
> ResponseContainerCloudIntegration deleteCloudIntegration(id)

Delete a specific cloud integration



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.CloudIntegrationApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

CloudIntegrationApi apiInstance = new CloudIntegrationApi();
String id = "id_example"; // String | 
try {
    ResponseContainerCloudIntegration result = apiInstance.deleteCloudIntegration(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling CloudIntegrationApi#deleteCloudIntegration");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |

### Return type

[**ResponseContainerCloudIntegration**](ResponseContainerCloudIntegration.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getAllCloudIntegration"></a>
# **getAllCloudIntegration**
> ResponseContainerPagedCloudIntegration getAllCloudIntegration(offset, limit)

Get all cloud integrations for a customer



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.CloudIntegrationApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

CloudIntegrationApi apiInstance = new CloudIntegrationApi();
Integer offset = 0; // Integer | 
Integer limit = 100; // Integer | 
try {
    ResponseContainerPagedCloudIntegration result = apiInstance.getAllCloudIntegration(offset, limit);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling CloudIntegrationApi#getAllCloudIntegration");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **offset** | **Integer**|  | [optional] [default to 0]
 **limit** | **Integer**|  | [optional] [default to 100]

### Return type

[**ResponseContainerPagedCloudIntegration**](ResponseContainerPagedCloudIntegration.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getCloudIntegration"></a>
# **getCloudIntegration**
> ResponseContainerCloudIntegration getCloudIntegration(id)

Get a specific cloud integration



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.CloudIntegrationApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

CloudIntegrationApi apiInstance = new CloudIntegrationApi();
String id = "id_example"; // String | 
try {
    ResponseContainerCloudIntegration result = apiInstance.getCloudIntegration(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling CloudIntegrationApi#getCloudIntegration");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |

### Return type

[**ResponseContainerCloudIntegration**](ResponseContainerCloudIntegration.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="undeleteCloudIntegration"></a>
# **undeleteCloudIntegration**
> ResponseContainerCloudIntegration undeleteCloudIntegration(id)

Undelete a specific cloud integration



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.CloudIntegrationApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

CloudIntegrationApi apiInstance = new CloudIntegrationApi();
String id = "id_example"; // String | 
try {
    ResponseContainerCloudIntegration result = apiInstance.undeleteCloudIntegration(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling CloudIntegrationApi#undeleteCloudIntegration");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |

### Return type

[**ResponseContainerCloudIntegration**](ResponseContainerCloudIntegration.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="updateCloudIntegration"></a>
# **updateCloudIntegration**
> ResponseContainerCloudIntegration updateCloudIntegration(id, body)

Update a specific cloud integration



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.CloudIntegrationApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

CloudIntegrationApi apiInstance = new CloudIntegrationApi();
String id = "id_example"; // String | 
CloudIntegration body = new CloudIntegration(); // CloudIntegration | Example Body:  <pre>{   \"name\":\"CloudWatch integration\",   \"service\":\"CLOUDWATCH\",   \"cloudWatch\":{     \"baseCredentials\":{       \"roleArn\":\"arn:aws:iam::&lt;accountid&gt;:role/&lt;rolename&gt;\",       \"externalId\":\"wave123\"     },     \"metricFilterRegex\":\"^aws.(sqs|ec2|ebs|elb).*$\"   } }</pre>
try {
    ResponseContainerCloudIntegration result = apiInstance.updateCloudIntegration(id, body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling CloudIntegrationApi#updateCloudIntegration");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |
 **body** | [**CloudIntegration**](CloudIntegration.md)| Example Body:  &lt;pre&gt;{   \&quot;name\&quot;:\&quot;CloudWatch integration\&quot;,   \&quot;service\&quot;:\&quot;CLOUDWATCH\&quot;,   \&quot;cloudWatch\&quot;:{     \&quot;baseCredentials\&quot;:{       \&quot;roleArn\&quot;:\&quot;arn:aws:iam::&amp;lt;accountid&amp;gt;:role/&amp;lt;rolename&amp;gt;\&quot;,       \&quot;externalId\&quot;:\&quot;wave123\&quot;     },     \&quot;metricFilterRegex\&quot;:\&quot;^aws.(sqs|ec2|ebs|elb).*$\&quot;   } }&lt;/pre&gt; | [optional]

### Return type

[**ResponseContainerCloudIntegration**](ResponseContainerCloudIntegration.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

