
# CloudTrailConfiguration

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**prefix** | **String** | The common prefix, if any, appended to all CloudTrail log files |  [optional]
**baseCredentials** | [**AWSBaseCredentials**](AWSBaseCredentials.md) |  |  [optional]
**bucketName** | **String** | Name of the S3 bucket where CloudTrail logs are stored | 



