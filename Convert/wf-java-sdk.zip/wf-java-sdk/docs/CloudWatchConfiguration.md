
# CloudWatchConfiguration

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**metricFilterRegex** | **String** | A regular expression that a CloudWatch metric name must match (case-insensitively) in order to be ingested |  [optional]
**baseCredentials** | [**AWSBaseCredentials**](AWSBaseCredentials.md) |  |  [optional]
**instanceSelectionTags** | **Map&lt;String, String&gt;** | A comma-separated white list of AWS instance tag-value pairs (in AWS).  If the instance&#39;s AWS tags match this whitelist, CloudWatch data about this instance is ingested.  Multiple entries are OR&#39;ed |  [optional]
**volumeSelectionTags** | **Map&lt;String, String&gt;** | A comma-separated white list of AWS volume tag-value pairs (in AWS).  If the volume&#39;s AWS tags match this whitelist, CloudWatch data about this volume is ingested.  Multiple entries are OR&#39;ed |  [optional]



