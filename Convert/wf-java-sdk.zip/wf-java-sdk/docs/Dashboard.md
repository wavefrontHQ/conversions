
# Dashboard

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | Name of the dashboard | 
**id** | **String** | Unique identifier, also URL slug, of the dashboard | 
**parameters** | **Map&lt;String, String&gt;** | Deprecated.  An obsolete representation of dashboard parameters |  [optional]
**description** | **String** | Human-readable description of the dashboard |  [optional]
**tags** | [**WFTags**](WFTags.md) | Tags assigned to this dashboard |  [optional]
**customer** | **String** | id of the customer to which this dashboard belongs |  [optional]
**url** | **String** | Unique identifier, also URL slug, of the dashboard | 
**eventFilterType** | [**EventFilterTypeEnum**](#EventFilterTypeEnum) | How charts belonging to this dashboard should display events.  BYCHART is default if unspecified |  [optional]
**sections** | [**List&lt;DashboardSection&gt;**](DashboardSection.md) | Dashboard chart sections | 
**parameterDetails** | [**Map&lt;String, DashboardParameterValue&gt;**](DashboardParameterValue.md) | The current (as of Wavefront 4.0) JSON representation of dashboard parameters.  This is a map from a parameter name to its representation |  [optional]
**displayDescription** | **Boolean** | Whether the dashboard description section is opened by default when the dashboard is shown |  [optional]
**displaySectionTableOfContents** | **Boolean** | Whether the \&quot;pills\&quot; quick-linked the sections of the dashboard are displayed by default when the dashboard is shown |  [optional]
**displayQueryParameters** | **Boolean** | Whether the dashboard parameters section is opened by default when the dashboard is shown |  [optional]
**chartTitleScalar** | **Integer** | Scale (normally 100) of chart title text size |  [optional]
**eventQuery** | **String** | Event query to run on dashboard charts |  [optional]
**chartTitleColor** | **String** | Text color of the chart title text are, in rgba(rvalue,gvalue,bvalue,avalue) |  [optional]
**chartTitleBgColor** | **String** | Background color of the chart title text area, in rgba(rvalue,gvalue,bvalue,avalue) |  [optional]
**viewsLastDay** | **Integer** |  |  [optional]
**viewsLastWeek** | **Integer** |  |  [optional]
**viewsLastMonth** | **Integer** |  |  [optional]
**createdEpochMillis** | **Long** |  |  [optional]
**updatedEpochMillis** | **Long** |  |  [optional]
**updaterId** | **String** |  |  [optional]
**creatorId** | **String** |  |  [optional]
**deleted** | **Boolean** |  |  [optional]
**systemOwned** | **Boolean** | Whether this dashboard is system-owned and not writeable |  [optional]
**numCharts** | **Integer** |  |  [optional]
**numFavorites** | **Integer** |  |  [optional]
**favorite** | **Boolean** |  |  [optional]


<a name="EventFilterTypeEnum"></a>
## Enum: EventFilterTypeEnum
Name | Value
---- | -----
BYCHART | &quot;BYCHART&quot;
AUTOMATIC | &quot;AUTOMATIC&quot;
ALL | &quot;ALL&quot;
NONE | &quot;NONE&quot;
BYDASHBOARD | &quot;BYDASHBOARD&quot;
BYCHARTANDDASHBOARD | &quot;BYCHARTANDDASHBOARD&quot;



