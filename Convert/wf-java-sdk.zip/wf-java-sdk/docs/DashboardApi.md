# DashboardApi

All URIs are relative to *https://localhost/*

Method | HTTP request | Description
------------- | ------------- | -------------
[**addDashboardTag**](DashboardApi.md#addDashboardTag) | **PUT** /api/v2/dashboard/{id}/tag/{tagValue} | Add a tag to a specific dashboard
[**createDashboard**](DashboardApi.md#createDashboard) | **POST** /api/v2/dashboard | Create a specific dashboard
[**deleteDashboard**](DashboardApi.md#deleteDashboard) | **DELETE** /api/v2/dashboard/{id} | Delete a specific dashboard
[**getAllDashboard**](DashboardApi.md#getAllDashboard) | **GET** /api/v2/dashboard | Get all dashboards for a customer
[**getDashboard**](DashboardApi.md#getDashboard) | **GET** /api/v2/dashboard/{id} | Get a specific dashboard
[**getDashboardHistory**](DashboardApi.md#getDashboardHistory) | **GET** /api/v2/dashboard/{id}/history | Get the version history of a specific dashboard
[**getDashboardTags**](DashboardApi.md#getDashboardTags) | **GET** /api/v2/dashboard/{id}/tag | Get all tags associated with a specific dashboard
[**getDashboardVersion**](DashboardApi.md#getDashboardVersion) | **GET** /api/v2/dashboard/{id}/history/{version} | Get a specific version of a specific dashboard
[**removeDashboardTag**](DashboardApi.md#removeDashboardTag) | **DELETE** /api/v2/dashboard/{id}/tag/{tagValue} | Remove a tag from a specific dashboard
[**setDashboardTags**](DashboardApi.md#setDashboardTags) | **POST** /api/v2/dashboard/{id}/tag | Set all tags associated with a specific dashboard
[**undeleteDashboard**](DashboardApi.md#undeleteDashboard) | **POST** /api/v2/dashboard/{id}/undelete | Undelete a specific dashboard
[**updateDashboard**](DashboardApi.md#updateDashboard) | **PUT** /api/v2/dashboard/{id} | Update a specific dashboard


<a name="addDashboardTag"></a>
# **addDashboardTag**
> ResponseContainer addDashboardTag(id, tagValue)

Add a tag to a specific dashboard



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.DashboardApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

DashboardApi apiInstance = new DashboardApi();
String id = "id_example"; // String | 
String tagValue = "tagValue_example"; // String | 
try {
    ResponseContainer result = apiInstance.addDashboardTag(id, tagValue);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DashboardApi#addDashboardTag");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |
 **tagValue** | **String**|  |

### Return type

[**ResponseContainer**](ResponseContainer.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="createDashboard"></a>
# **createDashboard**
> ResponseContainerDashboard createDashboard(body)

Create a specific dashboard



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.DashboardApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

DashboardApi apiInstance = new DashboardApi();
Dashboard body = new Dashboard(); // Dashboard | Example Body:  <pre>{   \"name\": \"Dashboard API example\",   \"id\": \"api-example\",   \"url\": \"api-example\",   \"description\": \"Dashboard Description\",   \"sections\": [     {       \"name\": \"Section 1\",       \"rows\": [         {           \"charts\": [             {               \"name\": \"Chart 1\",               \"description\": \"description1\",               \"sources\": [                 {                   \"name\": \"Source1\",                   \"query\": \"ts()\"                 }               ]             }           ]         }       ]     }   ] }</pre>
try {
    ResponseContainerDashboard result = apiInstance.createDashboard(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DashboardApi#createDashboard");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Dashboard**](Dashboard.md)| Example Body:  &lt;pre&gt;{   \&quot;name\&quot;: \&quot;Dashboard API example\&quot;,   \&quot;id\&quot;: \&quot;api-example\&quot;,   \&quot;url\&quot;: \&quot;api-example\&quot;,   \&quot;description\&quot;: \&quot;Dashboard Description\&quot;,   \&quot;sections\&quot;: [     {       \&quot;name\&quot;: \&quot;Section 1\&quot;,       \&quot;rows\&quot;: [         {           \&quot;charts\&quot;: [             {               \&quot;name\&quot;: \&quot;Chart 1\&quot;,               \&quot;description\&quot;: \&quot;description1\&quot;,               \&quot;sources\&quot;: [                 {                   \&quot;name\&quot;: \&quot;Source1\&quot;,                   \&quot;query\&quot;: \&quot;ts()\&quot;                 }               ]             }           ]         }       ]     }   ] }&lt;/pre&gt; | [optional]

### Return type

[**ResponseContainerDashboard**](ResponseContainerDashboard.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="deleteDashboard"></a>
# **deleteDashboard**
> ResponseContainerDashboard deleteDashboard(id)

Delete a specific dashboard



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.DashboardApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

DashboardApi apiInstance = new DashboardApi();
String id = "id_example"; // String | 
try {
    ResponseContainerDashboard result = apiInstance.deleteDashboard(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DashboardApi#deleteDashboard");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |

### Return type

[**ResponseContainerDashboard**](ResponseContainerDashboard.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getAllDashboard"></a>
# **getAllDashboard**
> ResponseContainerPagedDashboard getAllDashboard(offset, limit)

Get all dashboards for a customer



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.DashboardApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

DashboardApi apiInstance = new DashboardApi();
Integer offset = 0; // Integer | 
Integer limit = 100; // Integer | 
try {
    ResponseContainerPagedDashboard result = apiInstance.getAllDashboard(offset, limit);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DashboardApi#getAllDashboard");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **offset** | **Integer**|  | [optional] [default to 0]
 **limit** | **Integer**|  | [optional] [default to 100]

### Return type

[**ResponseContainerPagedDashboard**](ResponseContainerPagedDashboard.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getDashboard"></a>
# **getDashboard**
> ResponseContainerDashboard getDashboard(id)

Get a specific dashboard



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.DashboardApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

DashboardApi apiInstance = new DashboardApi();
String id = "id_example"; // String | 
try {
    ResponseContainerDashboard result = apiInstance.getDashboard(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DashboardApi#getDashboard");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |

### Return type

[**ResponseContainerDashboard**](ResponseContainerDashboard.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getDashboardHistory"></a>
# **getDashboardHistory**
> ResponseContainerHistoryResponse getDashboardHistory(id, offset, limit)

Get the version history of a specific dashboard



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.DashboardApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

DashboardApi apiInstance = new DashboardApi();
String id = "id_example"; // String | 
Integer offset = 0; // Integer | 
Integer limit = 100; // Integer | 
try {
    ResponseContainerHistoryResponse result = apiInstance.getDashboardHistory(id, offset, limit);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DashboardApi#getDashboardHistory");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |
 **offset** | **Integer**|  | [optional] [default to 0]
 **limit** | **Integer**|  | [optional] [default to 100]

### Return type

[**ResponseContainerHistoryResponse**](ResponseContainerHistoryResponse.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getDashboardTags"></a>
# **getDashboardTags**
> ResponseContainerTagsResponse getDashboardTags(id)

Get all tags associated with a specific dashboard



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.DashboardApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

DashboardApi apiInstance = new DashboardApi();
String id = "id_example"; // String | 
try {
    ResponseContainerTagsResponse result = apiInstance.getDashboardTags(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DashboardApi#getDashboardTags");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |

### Return type

[**ResponseContainerTagsResponse**](ResponseContainerTagsResponse.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getDashboardVersion"></a>
# **getDashboardVersion**
> ResponseContainerDashboard getDashboardVersion(id, version)

Get a specific version of a specific dashboard



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.DashboardApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

DashboardApi apiInstance = new DashboardApi();
String id = "id_example"; // String | 
Long version = 789L; // Long | 
try {
    ResponseContainerDashboard result = apiInstance.getDashboardVersion(id, version);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DashboardApi#getDashboardVersion");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |
 **version** | **Long**|  |

### Return type

[**ResponseContainerDashboard**](ResponseContainerDashboard.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="removeDashboardTag"></a>
# **removeDashboardTag**
> ResponseContainer removeDashboardTag(id, tagValue)

Remove a tag from a specific dashboard



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.DashboardApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

DashboardApi apiInstance = new DashboardApi();
String id = "id_example"; // String | 
String tagValue = "tagValue_example"; // String | 
try {
    ResponseContainer result = apiInstance.removeDashboardTag(id, tagValue);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DashboardApi#removeDashboardTag");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |
 **tagValue** | **String**|  |

### Return type

[**ResponseContainer**](ResponseContainer.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="setDashboardTags"></a>
# **setDashboardTags**
> ResponseContainer setDashboardTags(id, body)

Set all tags associated with a specific dashboard



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.DashboardApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

DashboardApi apiInstance = new DashboardApi();
String id = "id_example"; // String | 
List<String> body = Arrays.asList(new List<String>()); // List<String> | 
try {
    ResponseContainer result = apiInstance.setDashboardTags(id, body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DashboardApi#setDashboardTags");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |
 **body** | **List&lt;String&gt;**|  | [optional]

### Return type

[**ResponseContainer**](ResponseContainer.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="undeleteDashboard"></a>
# **undeleteDashboard**
> ResponseContainerDashboard undeleteDashboard(id)

Undelete a specific dashboard



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.DashboardApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

DashboardApi apiInstance = new DashboardApi();
String id = "id_example"; // String | 
try {
    ResponseContainerDashboard result = apiInstance.undeleteDashboard(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DashboardApi#undeleteDashboard");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |

### Return type

[**ResponseContainerDashboard**](ResponseContainerDashboard.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="updateDashboard"></a>
# **updateDashboard**
> ResponseContainerDashboard updateDashboard(id, body)

Update a specific dashboard



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.DashboardApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

DashboardApi apiInstance = new DashboardApi();
String id = "id_example"; // String | 
Dashboard body = new Dashboard(); // Dashboard | Example Body:  <pre>{   \"name\": \"Dashboard API example\",   \"id\": \"api-example\",   \"url\": \"api-example\",   \"description\": \"Dashboard Description\",   \"sections\": [     {       \"name\": \"Section 1\",       \"rows\": [         {           \"charts\": [             {               \"name\": \"Chart 1\",               \"description\": \"description1\",               \"sources\": [                 {                   \"name\": \"Source1\",                   \"query\": \"ts()\"                 }               ]             }           ]         }       ]     }   ] }</pre>
try {
    ResponseContainerDashboard result = apiInstance.updateDashboard(id, body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DashboardApi#updateDashboard");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |
 **body** | [**Dashboard**](Dashboard.md)| Example Body:  &lt;pre&gt;{   \&quot;name\&quot;: \&quot;Dashboard API example\&quot;,   \&quot;id\&quot;: \&quot;api-example\&quot;,   \&quot;url\&quot;: \&quot;api-example\&quot;,   \&quot;description\&quot;: \&quot;Dashboard Description\&quot;,   \&quot;sections\&quot;: [     {       \&quot;name\&quot;: \&quot;Section 1\&quot;,       \&quot;rows\&quot;: [         {           \&quot;charts\&quot;: [             {               \&quot;name\&quot;: \&quot;Chart 1\&quot;,               \&quot;description\&quot;: \&quot;description1\&quot;,               \&quot;sources\&quot;: [                 {                   \&quot;name\&quot;: \&quot;Source1\&quot;,                   \&quot;query\&quot;: \&quot;ts()\&quot;                 }               ]             }           ]         }       ]     }   ] }&lt;/pre&gt; | [optional]

### Return type

[**ResponseContainerDashboard**](ResponseContainerDashboard.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

