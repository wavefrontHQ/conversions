
# DashboardParameterValue

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**defaultValue** | **String** |  |  [optional]
**label** | **String** |  |  [optional]
**description** | **String** |  |  [optional]
**parameterType** | [**ParameterTypeEnum**](#ParameterTypeEnum) |  |  [optional]
**valuesToReadableStrings** | **Map&lt;String, String&gt;** |  |  [optional]
**dynamicFieldType** | [**DynamicFieldTypeEnum**](#DynamicFieldTypeEnum) |  |  [optional]
**queryValue** | **String** |  |  [optional]
**hideFromView** | **Boolean** |  |  [optional]
**tagKey** | **String** |  |  [optional]
**multivalue** | **Boolean** |  |  [optional]
**allowAll** | **Boolean** |  |  [optional]


<a name="ParameterTypeEnum"></a>
## Enum: ParameterTypeEnum
Name | Value
---- | -----
SIMPLE | &quot;SIMPLE&quot;
LIST | &quot;LIST&quot;
DYNAMIC | &quot;DYNAMIC&quot;


<a name="DynamicFieldTypeEnum"></a>
## Enum: DynamicFieldTypeEnum
Name | Value
---- | -----
SOURCE | &quot;SOURCE&quot;
SOURCE_TAG | &quot;SOURCE_TAG&quot;
METRIC_NAME | &quot;METRIC_NAME&quot;
TAG_KEY | &quot;TAG_KEY&quot;
MATCHING_SOURCE_TAG | &quot;MATCHING_SOURCE_TAG&quot;



