
# DashboardSection

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | Name of this section | 
**rows** | [**List&lt;DashboardSectionRow&gt;**](DashboardSectionRow.md) | Rows of this section | 



