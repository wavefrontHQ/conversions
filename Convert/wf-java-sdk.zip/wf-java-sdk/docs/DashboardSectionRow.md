
# DashboardSectionRow

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**charts** | [**List&lt;Chart&gt;**](Chart.md) | Charts in this section row | 
**heightFactor** | **Integer** | Scalar for the height of this row. 100 is normal and default. 50 is half height |  [optional]



