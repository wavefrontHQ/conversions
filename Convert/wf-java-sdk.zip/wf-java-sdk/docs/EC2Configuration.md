
# EC2Configuration

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**baseCredentials** | [**AWSBaseCredentials**](AWSBaseCredentials.md) |  |  [optional]
**hostNameTags** | **List&lt;String&gt;** | A list of AWS instance tags that, when found, will be used as the \&quot;source\&quot; name in a series.  Default: [\&quot;hostname\&quot;, \&quot;host\&quot;, \&quot;name\&quot;].  If no tag in this list is found, the series source is set to the instance id. |  [optional]



