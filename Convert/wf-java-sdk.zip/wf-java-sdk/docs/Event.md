
# Event

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**startTime** | **Long** | Start time of the event, in epoch millis.  If the JSON value is missing or set to 0, startTime will be set to the current time | 
**endTime** | **Long** | End time of the event, in epoch millis.  Set to startTime + 1 for an instantaneous event | 
**name** | **String** | The name of the event.  If &#39;annotations.prettyName&#39; is present, &#39;name&#39; will be equivalent to that value | 
**annotations** | **Map&lt;String, String&gt;** | A string-&gt;string map of additional annotations on the event | 
**id** | **String** |  |  [optional]
**table** | **String** | The customer to which the event belongs |  [optional]
**tags** | **List&lt;String&gt;** | A list of event tags |  [optional]
**createdEpochMillis** | **Long** |  |  [optional]
**updatedEpochMillis** | **Long** |  |  [optional]
**updaterId** | **String** |  |  [optional]
**creatorId** | **String** |  |  [optional]
**createdAt** | **Long** |  |  [optional]
**updatedAt** | **Long** |  |  [optional]
**hosts** | **List&lt;String&gt;** | A list of sources/hosts affected by the event | 
**summarizedEvents** | **Long** | In some event queries, multiple events that occur nearly simultaneously are summarized under a single event.  This value specifies the number of events summarized under this one | 
**isUserEvent** | **Boolean** | Whether this event was created by a user, versus the system.  Default: system |  [optional]
**isEphemeral** | **Boolean** | Whether the event ends immediately after it begins |  [optional]
**canDelete** | **Boolean** |  |  [optional]
**canClose** | **Boolean** |  |  [optional]
**creatorType** | [**List&lt;CreatorTypeEnum&gt;**](#List&lt;CreatorTypeEnum&gt;) |  |  [optional]
**runningState** | [**RunningStateEnum**](#RunningStateEnum) |  |  [optional]


<a name="List<CreatorTypeEnum>"></a>
## Enum: List&lt;CreatorTypeEnum&gt;
Name | Value
---- | -----
USER | &quot;USER&quot;
ALERT | &quot;ALERT&quot;
SYSTEM | &quot;SYSTEM&quot;


<a name="RunningStateEnum"></a>
## Enum: RunningStateEnum
Name | Value
---- | -----
ONGOING | &quot;ONGOING&quot;
PENDING | &quot;PENDING&quot;
ENDED | &quot;ENDED&quot;



