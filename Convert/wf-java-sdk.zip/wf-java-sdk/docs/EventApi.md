# EventApi

All URIs are relative to *https://localhost/*

Method | HTTP request | Description
------------- | ------------- | -------------
[**addEventTag**](EventApi.md#addEventTag) | **PUT** /api/v2/event/{id}/tag/{tagValue} | Add a tag to a specific event
[**closeEvent**](EventApi.md#closeEvent) | **POST** /api/v2/event/{id}/close | Close a specific event
[**createEvent**](EventApi.md#createEvent) | **POST** /api/v2/event | Create a specific event
[**deleteEvent**](EventApi.md#deleteEvent) | **DELETE** /api/v2/event/{id} | Delete a specific event
[**getAllEventsWithTimeRange**](EventApi.md#getAllEventsWithTimeRange) | **GET** /api/v2/event | List all the events for a customer within a time range
[**getEvent**](EventApi.md#getEvent) | **GET** /api/v2/event/{id} | Get a specific event
[**getEventTags**](EventApi.md#getEventTags) | **GET** /api/v2/event/{id}/tag | Get all tags associated with a specific event
[**removeEventTag**](EventApi.md#removeEventTag) | **DELETE** /api/v2/event/{id}/tag/{tagValue} | Remove a tag from a specific event
[**setEventTags**](EventApi.md#setEventTags) | **POST** /api/v2/event/{id}/tag | Set all tags associated with a specific event
[**updateEvent**](EventApi.md#updateEvent) | **PUT** /api/v2/event/{id} | Update a specific event


<a name="addEventTag"></a>
# **addEventTag**
> ResponseContainer addEventTag(id, tagValue)

Add a tag to a specific event



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.EventApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

EventApi apiInstance = new EventApi();
String id = "id_example"; // String | 
String tagValue = "tagValue_example"; // String | 
try {
    ResponseContainer result = apiInstance.addEventTag(id, tagValue);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling EventApi#addEventTag");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |
 **tagValue** | **String**|  |

### Return type

[**ResponseContainer**](ResponseContainer.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="closeEvent"></a>
# **closeEvent**
> ResponseContainerEvent closeEvent(id)

Close a specific event



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.EventApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

EventApi apiInstance = new EventApi();
String id = "id_example"; // String | 
try {
    ResponseContainerEvent result = apiInstance.closeEvent(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling EventApi#closeEvent");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |

### Return type

[**ResponseContainerEvent**](ResponseContainerEvent.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="createEvent"></a>
# **createEvent**
> ResponseContainerEvent createEvent(body)

Create a specific event



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.EventApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

EventApi apiInstance = new EventApi();
Event body = new Event(); // Event | Example Body:  <pre>{   \"name\": \"Event API Example\",   \"annotations\": {     \"severity\": \"info\",     \"type\": \"event type\",     \"details\": \"description\"   },   \"startTime\": 0 }</pre>
try {
    ResponseContainerEvent result = apiInstance.createEvent(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling EventApi#createEvent");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Event**](Event.md)| Example Body:  &lt;pre&gt;{   \&quot;name\&quot;: \&quot;Event API Example\&quot;,   \&quot;annotations\&quot;: {     \&quot;severity\&quot;: \&quot;info\&quot;,     \&quot;type\&quot;: \&quot;event type\&quot;,     \&quot;details\&quot;: \&quot;description\&quot;   },   \&quot;startTime\&quot;: 0 }&lt;/pre&gt; | [optional]

### Return type

[**ResponseContainerEvent**](ResponseContainerEvent.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="deleteEvent"></a>
# **deleteEvent**
> ResponseContainerEvent deleteEvent(id)

Delete a specific event



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.EventApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

EventApi apiInstance = new EventApi();
String id = "id_example"; // String | 
try {
    ResponseContainerEvent result = apiInstance.deleteEvent(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling EventApi#deleteEvent");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |

### Return type

[**ResponseContainerEvent**](ResponseContainerEvent.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getAllEventsWithTimeRange"></a>
# **getAllEventsWithTimeRange**
> ResponseContainerPagedEvent getAllEventsWithTimeRange(earliestStartTimeEpochMillis, latestStartTimeEpochMillis, cursor, limit)

List all the events for a customer within a time range



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.EventApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

EventApi apiInstance = new EventApi();
Long earliestStartTimeEpochMillis = 789L; // Long | 
Long latestStartTimeEpochMillis = 789L; // Long | 
String cursor = "cursor_example"; // String | 
Integer limit = 100; // Integer | 
try {
    ResponseContainerPagedEvent result = apiInstance.getAllEventsWithTimeRange(earliestStartTimeEpochMillis, latestStartTimeEpochMillis, cursor, limit);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling EventApi#getAllEventsWithTimeRange");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **earliestStartTimeEpochMillis** | **Long**|  | [optional]
 **latestStartTimeEpochMillis** | **Long**|  | [optional]
 **cursor** | **String**|  | [optional]
 **limit** | **Integer**|  | [optional] [default to 100]

### Return type

[**ResponseContainerPagedEvent**](ResponseContainerPagedEvent.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getEvent"></a>
# **getEvent**
> ResponseContainerEvent getEvent(id)

Get a specific event



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.EventApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

EventApi apiInstance = new EventApi();
String id = "id_example"; // String | 
try {
    ResponseContainerEvent result = apiInstance.getEvent(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling EventApi#getEvent");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |

### Return type

[**ResponseContainerEvent**](ResponseContainerEvent.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getEventTags"></a>
# **getEventTags**
> ResponseContainerTagsResponse getEventTags(id)

Get all tags associated with a specific event



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.EventApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

EventApi apiInstance = new EventApi();
String id = "id_example"; // String | 
try {
    ResponseContainerTagsResponse result = apiInstance.getEventTags(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling EventApi#getEventTags");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |

### Return type

[**ResponseContainerTagsResponse**](ResponseContainerTagsResponse.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="removeEventTag"></a>
# **removeEventTag**
> ResponseContainer removeEventTag(id, tagValue)

Remove a tag from a specific event



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.EventApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

EventApi apiInstance = new EventApi();
String id = "id_example"; // String | 
String tagValue = "tagValue_example"; // String | 
try {
    ResponseContainer result = apiInstance.removeEventTag(id, tagValue);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling EventApi#removeEventTag");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |
 **tagValue** | **String**|  |

### Return type

[**ResponseContainer**](ResponseContainer.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="setEventTags"></a>
# **setEventTags**
> ResponseContainer setEventTags(id, body)

Set all tags associated with a specific event



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.EventApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

EventApi apiInstance = new EventApi();
String id = "id_example"; // String | 
List<String> body = Arrays.asList(new List<String>()); // List<String> | 
try {
    ResponseContainer result = apiInstance.setEventTags(id, body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling EventApi#setEventTags");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |
 **body** | **List&lt;String&gt;**|  | [optional]

### Return type

[**ResponseContainer**](ResponseContainer.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="updateEvent"></a>
# **updateEvent**
> ResponseContainerEvent updateEvent(id, body)

Update a specific event



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.EventApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

EventApi apiInstance = new EventApi();
String id = "id_example"; // String | 
Event body = new Event(); // Event | Example Body:  <pre>{   \"name\": \"Event API Example\",   \"annotations\": {     \"severity\": \"info\",     \"type\": \"event type\",     \"details\": \"description\"   },   \"startTime\": 0 }</pre>
try {
    ResponseContainerEvent result = apiInstance.updateEvent(id, body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling EventApi#updateEvent");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |
 **body** | [**Event**](Event.md)| Example Body:  &lt;pre&gt;{   \&quot;name\&quot;: \&quot;Event API Example\&quot;,   \&quot;annotations\&quot;: {     \&quot;severity\&quot;: \&quot;info\&quot;,     \&quot;type\&quot;: \&quot;event type\&quot;,     \&quot;details\&quot;: \&quot;description\&quot;   },   \&quot;startTime\&quot;: 0 }&lt;/pre&gt; | [optional]

### Return type

[**ResponseContainerEvent**](ResponseContainerEvent.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

