
# EventTimeRange

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**earliestStartTimeEpochMillis** | **Long** | Start of search time window, in milliseconds since the Unix Epoch.  Events whose start time occurs after this value will be returned.  If no value is supplied, defaults to 2 hours prior the present time. |  [optional]
**latestStartTimeEpochMillis** | **Long** | End of the search time window, in milliseconds since the Unix Epoch.  Events whose start time occurs before this value will be returned.   If no value is supplied, defaults to now. |  [optional]



