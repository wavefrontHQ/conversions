
# ExternalLink

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | Name of the external link.  Will be displayed in context (right-click) menus on charts | 
**id** | **String** |  |  [optional]
**description** | **String** | Human-readable description for this external link | 
**createdEpochMillis** | **Long** |  |  [optional]
**updatedEpochMillis** | **Long** |  |  [optional]
**updaterId** | **String** |  |  [optional]
**creatorId** | **String** |  |  [optional]
**template** | **String** | The mustache template for this link.  This template must expand to a full URL, including scheme, origin, etc | 
**metricFilterRegex** | **String** | Controls whether a link displayed in the context menu of a highlighted series.  If present, the metric name of the highlighted series must match this regular expression in order for the link to be displayed |  [optional]
**sourceFilterRegex** | **String** | Controls whether a link displayed in the context menu of a highlighted series.  If present, the source name of the highlighted series must match this regular expression in order for the link to be displayed |  [optional]
**pointTagFilterRegexes** | **Map&lt;String, String&gt;** | Controls whether a link displayed in the context menu of a highlighted series.  This is a map from string to regular expression. The highlighted series must contain point tags whose keys are present in the keys of this map and whose values match the regular expressions associated with those keys in order for the link to be displayed |  [optional]



