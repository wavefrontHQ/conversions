# ExternalLinkApi

All URIs are relative to *https://localhost/*

Method | HTTP request | Description
------------- | ------------- | -------------
[**createExternalLink**](ExternalLinkApi.md#createExternalLink) | **POST** /api/v2/extlink | Create a specific external link
[**deleteExternalLink**](ExternalLinkApi.md#deleteExternalLink) | **DELETE** /api/v2/extlink/{id} | Delete a specific external link
[**getAllExternalLink**](ExternalLinkApi.md#getAllExternalLink) | **GET** /api/v2/extlink | Get all external links for a customer
[**getExternalLink**](ExternalLinkApi.md#getExternalLink) | **GET** /api/v2/extlink/{id} | Get a specific external link
[**updateExternalLink**](ExternalLinkApi.md#updateExternalLink) | **PUT** /api/v2/extlink/{id} | Update a specific external link


<a name="createExternalLink"></a>
# **createExternalLink**
> ResponseContainerExternalLink createExternalLink(body)

Create a specific external link



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.ExternalLinkApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

ExternalLinkApi apiInstance = new ExternalLinkApi();
ExternalLink body = new ExternalLink(); // ExternalLink | Example Body:  <pre>{   \"name\": \"External Link API Example\",   \"template\": \"https://example.com/{{source}}\",   \"description\": \"External Link Description\" }</pre>
try {
    ResponseContainerExternalLink result = apiInstance.createExternalLink(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ExternalLinkApi#createExternalLink");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**ExternalLink**](ExternalLink.md)| Example Body:  &lt;pre&gt;{   \&quot;name\&quot;: \&quot;External Link API Example\&quot;,   \&quot;template\&quot;: \&quot;https://example.com/{{source}}\&quot;,   \&quot;description\&quot;: \&quot;External Link Description\&quot; }&lt;/pre&gt; | [optional]

### Return type

[**ResponseContainerExternalLink**](ResponseContainerExternalLink.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="deleteExternalLink"></a>
# **deleteExternalLink**
> ResponseContainerExternalLink deleteExternalLink(id)

Delete a specific external link



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.ExternalLinkApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

ExternalLinkApi apiInstance = new ExternalLinkApi();
String id = "id_example"; // String | 
try {
    ResponseContainerExternalLink result = apiInstance.deleteExternalLink(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ExternalLinkApi#deleteExternalLink");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |

### Return type

[**ResponseContainerExternalLink**](ResponseContainerExternalLink.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="getAllExternalLink"></a>
# **getAllExternalLink**
> ResponseContainerPagedExternalLink getAllExternalLink(offset, limit)

Get all external links for a customer



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.ExternalLinkApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

ExternalLinkApi apiInstance = new ExternalLinkApi();
Integer offset = 0; // Integer | 
Integer limit = 100; // Integer | 
try {
    ResponseContainerPagedExternalLink result = apiInstance.getAllExternalLink(offset, limit);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ExternalLinkApi#getAllExternalLink");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **offset** | **Integer**|  | [optional] [default to 0]
 **limit** | **Integer**|  | [optional] [default to 100]

### Return type

[**ResponseContainerPagedExternalLink**](ResponseContainerPagedExternalLink.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getExternalLink"></a>
# **getExternalLink**
> ResponseContainerExternalLink getExternalLink(id)

Get a specific external link



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.ExternalLinkApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

ExternalLinkApi apiInstance = new ExternalLinkApi();
String id = "id_example"; // String | 
try {
    ResponseContainerExternalLink result = apiInstance.getExternalLink(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ExternalLinkApi#getExternalLink");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |

### Return type

[**ResponseContainerExternalLink**](ResponseContainerExternalLink.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="updateExternalLink"></a>
# **updateExternalLink**
> ResponseContainerExternalLink updateExternalLink(id, body)

Update a specific external link



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.ExternalLinkApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

ExternalLinkApi apiInstance = new ExternalLinkApi();
String id = "id_example"; // String | 
ExternalLink body = new ExternalLink(); // ExternalLink | Example Body:  <pre>{   \"name\": \"External Link API Example\",   \"template\": \"https://example.com/{{source}}\",   \"description\": \"External Link Description\" }</pre>
try {
    ResponseContainerExternalLink result = apiInstance.updateExternalLink(id, body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ExternalLinkApi#updateExternalLink");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |
 **body** | [**ExternalLink**](ExternalLink.md)| Example Body:  &lt;pre&gt;{   \&quot;name\&quot;: \&quot;External Link API Example\&quot;,   \&quot;template\&quot;: \&quot;https://example.com/{{source}}\&quot;,   \&quot;description\&quot;: \&quot;External Link Description\&quot; }&lt;/pre&gt; | [optional]

### Return type

[**ResponseContainerExternalLink**](ResponseContainerExternalLink.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

