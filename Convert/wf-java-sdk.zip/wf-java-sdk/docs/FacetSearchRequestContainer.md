
# FacetSearchRequestContainer

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**limit** | **Integer** | The number of results to return.  Default: 100 |  [optional]
**offset** | **Integer** | The number of results to skip before returning values.  Default: 0 |  [optional]
**query** | [**List&lt;SearchQuery&gt;**](SearchQuery.md) | A list of queries by which to limit the search results.  Entities that match ALL queries in the list are returned |  [optional]
**facetQuery** | **String** | A string against which facet results are compared.  If the facet result CONTAINs, STARTSWITH, or is an EXACT match for this value, as specified by facetQueryMatchingMethod, then it is returned. |  [optional]
**facetQueryMatchingMethod** | [**FacetQueryMatchingMethodEnum**](#FacetQueryMatchingMethodEnum) | The matching method used to filter when &#39;facetQuery&#39; is used. Defaults to CONTAINS. |  [optional]


<a name="FacetQueryMatchingMethodEnum"></a>
## Enum: FacetQueryMatchingMethodEnum
Name | Value
---- | -----
CONTAINS | &quot;CONTAINS&quot;
STARTSWITH | &quot;STARTSWITH&quot;
EXACT | &quot;EXACT&quot;
TAGPATH | &quot;TAGPATH&quot;



