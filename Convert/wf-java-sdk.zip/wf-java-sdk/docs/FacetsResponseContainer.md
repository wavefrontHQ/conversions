
# FacetsResponseContainer

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**limit** | **Long** | The requested limit |  [optional]
**facets** | [**Map&lt;String, List&lt;String&gt;&gt;**](List.md) | The requested facets, returned in a map whose key is the facet property and whose value is a list of facet values |  [optional]



