
# FacetsSearchRequestContainer

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**facets** | **List&lt;String&gt;** | A list of facets (property keys) to return values from found in entities matching &#39;query&#39;.  Examples are &#39;tags&#39;, &#39;creatorId&#39;, etc | 
**facetQuery** | **String** | A string against which facet results are compared.  If the facet result either CONTAINs, STARTSWITH, or is an EXACT match for this value, as specified by facetQueryMatchingMethod, then it is returned |  [optional]
**facetQueryMatchingMethod** | [**FacetQueryMatchingMethodEnum**](#FacetQueryMatchingMethodEnum) | The matching method used to filter when &#39;facetQuery&#39; is used. Defaults to CONTAINS. |  [optional]
**query** | [**List&lt;SearchQuery&gt;**](SearchQuery.md) | A list of queries by which to limit the search results.  Entities that match ALL queries in this list constitute a set of &#39;entity search results&#39;.  All facets listed in the &#39;facets&#39; search parameter of all entities within &#39;entity search results&#39; are scanned to produce the search results (of facet values). |  [optional]
**limit** | **Integer** | The number of results to return.  Default 100 |  [optional]


<a name="FacetQueryMatchingMethodEnum"></a>
## Enum: FacetQueryMatchingMethodEnum
Name | Value
---- | -----
CONTAINS | &quot;CONTAINS&quot;
STARTSWITH | &quot;STARTSWITH&quot;
EXACT | &quot;EXACT&quot;
TAGPATH | &quot;TAGPATH&quot;



