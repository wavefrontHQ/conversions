
# HistoryEntry

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  |  [optional]
**inTrash** | **Boolean** |  |  [optional]
**version** | **Long** |  |  [optional]
**updateUser** | **String** |  |  [optional]
**updateTime** | **Long** |  |  [optional]
**changeDescription** | **List&lt;String&gt;** |  |  [optional]



