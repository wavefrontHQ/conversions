
# IteratorEntryStringJsonNode

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



