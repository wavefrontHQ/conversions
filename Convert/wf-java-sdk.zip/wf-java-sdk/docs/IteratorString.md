
# IteratorString

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



