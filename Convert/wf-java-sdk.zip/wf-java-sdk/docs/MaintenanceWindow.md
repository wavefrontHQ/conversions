
# MaintenanceWindow

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**reason** | **String** | The purpose of this maintenance window | 
**id** | **String** |  |  [optional]
**createdEpochMillis** | **Long** |  |  [optional]
**updatedEpochMillis** | **Long** |  |  [optional]
**updaterId** | **String** |  |  [optional]
**creatorId** | **String** |  |  [optional]
**customerId** | **String** |  |  [optional]
**relevantHostTags** | **List&lt;String&gt;** | List of source/host tags whose matching sources/hosts will be put into maintenance because of this maintenance window |  [optional]
**eventName** | **String** | The name of an event associated with the creation/update of this maintenance window |  [optional]
**title** | **String** | Title of this maintenance window |  [optional]
**startTimeInSeconds** | **Long** | The time in epoch seconds when this maintenance window will start | 
**endTimeInSeconds** | **Long** | The time in epoch seconds when this maintenance window will end | 
**relevantCustomerTags** | **List&lt;String&gt;** | List of alert tags whose matching alerts will be put into maintenance because of this maintenance window | 
**relevantHostNames** | **List&lt;String&gt;** | List of source/host names that will be put into maintenance because of this maintenance window |  [optional]
**relevantHostTagsAnded** | **Boolean** | Whether to AND source/host tags listed in relevantHostTags. If true, a source/host must contain all tags in order for the maintenance window to apply.  If false, the tags are OR&#39;ed, and a source/host must contain one of the tags. Default: false |  [optional]
**hostTagGroupHostNamesGroupAnded** | **Boolean** | If true, a source/host must be in &#39;relevantHostNames&#39; and have tags matching the specification formed by &#39;relevantHostTags&#39; and &#39;relevantHostTagsAnded&#39; in order for this maintenance window to apply. If false, a source/host must either be in &#39;relevantHostNames&#39; or match &#39;relevantHostTags&#39; and &#39;relevantHostTagsAnded&#39;. Default: false |  [optional]
**runningState** | [**RunningStateEnum**](#RunningStateEnum) |  |  [optional]


<a name="RunningStateEnum"></a>
## Enum: RunningStateEnum
Name | Value
---- | -----
ONGOING | &quot;ONGOING&quot;
PENDING | &quot;PENDING&quot;
ENDED | &quot;ENDED&quot;



