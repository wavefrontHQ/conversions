# MaintenanceWindowApi

All URIs are relative to *https://localhost/*

Method | HTTP request | Description
------------- | ------------- | -------------
[**createMaintenanceWindow**](MaintenanceWindowApi.md#createMaintenanceWindow) | **POST** /api/v2/maintenancewindow | Create a maintenance window
[**deleteMaintenanceWindow**](MaintenanceWindowApi.md#deleteMaintenanceWindow) | **DELETE** /api/v2/maintenancewindow/{id} | Delete a specific maintenance window
[**getAllMaintenanceWindow**](MaintenanceWindowApi.md#getAllMaintenanceWindow) | **GET** /api/v2/maintenancewindow | Get all maintenance windows for a customer
[**getMaintenanceWindow**](MaintenanceWindowApi.md#getMaintenanceWindow) | **GET** /api/v2/maintenancewindow/{id} | Get a specific maintenance window
[**updateMaintenanceWindow**](MaintenanceWindowApi.md#updateMaintenanceWindow) | **PUT** /api/v2/maintenancewindow/{id} | Update a specific maintenance window


<a name="createMaintenanceWindow"></a>
# **createMaintenanceWindow**
> ResponseContainerMaintenanceWindow createMaintenanceWindow(body)

Create a maintenance window



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.MaintenanceWindowApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

MaintenanceWindowApi apiInstance = new MaintenanceWindowApi();
MaintenanceWindow body = new MaintenanceWindow(); // MaintenanceWindow | Example Body:  <pre>{   \"reason\": \"MW Reason\",   \"title\": \"MW Title\",   \"startTimeInSeconds\": 1483228800,   \"endTimeInSeconds\": 1483232400,   \"relevantCustomerTags\": [     \"alertId1\"   ],   \"relevantHostTags\": [     \"sourceTag1\"   ] }</pre>
try {
    ResponseContainerMaintenanceWindow result = apiInstance.createMaintenanceWindow(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling MaintenanceWindowApi#createMaintenanceWindow");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**MaintenanceWindow**](MaintenanceWindow.md)| Example Body:  &lt;pre&gt;{   \&quot;reason\&quot;: \&quot;MW Reason\&quot;,   \&quot;title\&quot;: \&quot;MW Title\&quot;,   \&quot;startTimeInSeconds\&quot;: 1483228800,   \&quot;endTimeInSeconds\&quot;: 1483232400,   \&quot;relevantCustomerTags\&quot;: [     \&quot;alertId1\&quot;   ],   \&quot;relevantHostTags\&quot;: [     \&quot;sourceTag1\&quot;   ] }&lt;/pre&gt; | [optional]

### Return type

[**ResponseContainerMaintenanceWindow**](ResponseContainerMaintenanceWindow.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="deleteMaintenanceWindow"></a>
# **deleteMaintenanceWindow**
> ResponseContainerMaintenanceWindow deleteMaintenanceWindow(id)

Delete a specific maintenance window



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.MaintenanceWindowApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

MaintenanceWindowApi apiInstance = new MaintenanceWindowApi();
String id = "id_example"; // String | 
try {
    ResponseContainerMaintenanceWindow result = apiInstance.deleteMaintenanceWindow(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling MaintenanceWindowApi#deleteMaintenanceWindow");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |

### Return type

[**ResponseContainerMaintenanceWindow**](ResponseContainerMaintenanceWindow.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getAllMaintenanceWindow"></a>
# **getAllMaintenanceWindow**
> ResponseContainerPagedMaintenanceWindow getAllMaintenanceWindow(offset, limit)

Get all maintenance windows for a customer



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.MaintenanceWindowApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

MaintenanceWindowApi apiInstance = new MaintenanceWindowApi();
Integer offset = 0; // Integer | 
Integer limit = 100; // Integer | 
try {
    ResponseContainerPagedMaintenanceWindow result = apiInstance.getAllMaintenanceWindow(offset, limit);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling MaintenanceWindowApi#getAllMaintenanceWindow");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **offset** | **Integer**|  | [optional] [default to 0]
 **limit** | **Integer**|  | [optional] [default to 100]

### Return type

[**ResponseContainerPagedMaintenanceWindow**](ResponseContainerPagedMaintenanceWindow.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getMaintenanceWindow"></a>
# **getMaintenanceWindow**
> ResponseContainerMaintenanceWindow getMaintenanceWindow(id)

Get a specific maintenance window



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.MaintenanceWindowApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

MaintenanceWindowApi apiInstance = new MaintenanceWindowApi();
String id = "id_example"; // String | 
try {
    ResponseContainerMaintenanceWindow result = apiInstance.getMaintenanceWindow(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling MaintenanceWindowApi#getMaintenanceWindow");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |

### Return type

[**ResponseContainerMaintenanceWindow**](ResponseContainerMaintenanceWindow.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="updateMaintenanceWindow"></a>
# **updateMaintenanceWindow**
> ResponseContainerMaintenanceWindow updateMaintenanceWindow(id, body)

Update a specific maintenance window



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.MaintenanceWindowApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

MaintenanceWindowApi apiInstance = new MaintenanceWindowApi();
String id = "id_example"; // String | 
MaintenanceWindow body = new MaintenanceWindow(); // MaintenanceWindow | Example Body:  <pre>{   \"reason\": \"MW Reason\",   \"title\": \"MW Title\",   \"startTimeInSeconds\": 1483228800,   \"endTimeInSeconds\": 1483232400,   \"relevantCustomerTags\": [     \"alertId1\"   ],   \"relevantHostTags\": [     \"sourceTag1\"   ] }</pre>
try {
    ResponseContainerMaintenanceWindow result = apiInstance.updateMaintenanceWindow(id, body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling MaintenanceWindowApi#updateMaintenanceWindow");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |
 **body** | [**MaintenanceWindow**](MaintenanceWindow.md)| Example Body:  &lt;pre&gt;{   \&quot;reason\&quot;: \&quot;MW Reason\&quot;,   \&quot;title\&quot;: \&quot;MW Title\&quot;,   \&quot;startTimeInSeconds\&quot;: 1483228800,   \&quot;endTimeInSeconds\&quot;: 1483232400,   \&quot;relevantCustomerTags\&quot;: [     \&quot;alertId1\&quot;   ],   \&quot;relevantHostTags\&quot;: [     \&quot;sourceTag1\&quot;   ] }&lt;/pre&gt; | [optional]

### Return type

[**ResponseContainerMaintenanceWindow**](ResponseContainerMaintenanceWindow.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

