
# Message

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**source** | **String** | Message source.  System messages will com from &#39;system@wavefront.com&#39; | 
**scope** | [**ScopeEnum**](#ScopeEnum) | The audience scope that this message should reach | 
**attributes** | **Map&lt;String, String&gt;** | A string-&gt;string map of additional properties associated with this message |  [optional]
**id** | **String** |  |  [optional]
**target** | **String** | For scope&#x3D;CUSTOMER or scope&#x3D;USER, the individual customer or user id |  [optional]
**content** | **String** | Message content | 
**severity** | [**SeverityEnum**](#SeverityEnum) | Message severity | 
**title** | **String** | Title of this message | 
**startEpochMillis** | **Long** | When this message will begin to be displayed, in epoch millis | 
**endEpochMillis** | **Long** | When this message will stop being displayed, in epoch millis | 
**display** | [**DisplayEnum**](#DisplayEnum) | The form of display for this message | 
**read** | **Boolean** | A derived field for whether the current user has read this message |  [optional]


<a name="ScopeEnum"></a>
## Enum: ScopeEnum
Name | Value
---- | -----
CLUSTER | &quot;CLUSTER&quot;
CUSTOMER | &quot;CUSTOMER&quot;
USER | &quot;USER&quot;


<a name="SeverityEnum"></a>
## Enum: SeverityEnum
Name | Value
---- | -----
MARKETING | &quot;MARKETING&quot;
INFO | &quot;INFO&quot;
WARN | &quot;WARN&quot;
SEVERE | &quot;SEVERE&quot;


<a name="DisplayEnum"></a>
## Enum: DisplayEnum
Name | Value
---- | -----
BANNER | &quot;BANNER&quot;
TOASTER | &quot;TOASTER&quot;



