# MessageApi

All URIs are relative to *https://localhost/*

Method | HTTP request | Description
------------- | ------------- | -------------
[**userGetMessages**](MessageApi.md#userGetMessages) | **GET** /api/v2/message | Gets messages applicable to the current user, i.e. within time range and distribution scope
[**userReadMessage**](MessageApi.md#userReadMessage) | **POST** /api/v2/message/{id}/read | Mark a specific message as read


<a name="userGetMessages"></a>
# **userGetMessages**
> ResponseContainerPagedMessage userGetMessages(offset, limit, unreadOnly)

Gets messages applicable to the current user, i.e. within time range and distribution scope



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.MessageApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

MessageApi apiInstance = new MessageApi();
Integer offset = 0; // Integer | 
Integer limit = 100; // Integer | 
Boolean unreadOnly = true; // Boolean | 
try {
    ResponseContainerPagedMessage result = apiInstance.userGetMessages(offset, limit, unreadOnly);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling MessageApi#userGetMessages");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **offset** | **Integer**|  | [optional] [default to 0]
 **limit** | **Integer**|  | [optional] [default to 100]
 **unreadOnly** | **Boolean**|  | [optional] [default to true]

### Return type

[**ResponseContainerPagedMessage**](ResponseContainerPagedMessage.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="userReadMessage"></a>
# **userReadMessage**
> ResponseContainerMessage userReadMessage(id)

Mark a specific message as read



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.MessageApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

MessageApi apiInstance = new MessageApi();
String id = "id_example"; // String | 
try {
    ResponseContainerMessage result = apiInstance.userReadMessage(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling MessageApi#userReadMessage");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |

### Return type

[**ResponseContainerMessage**](ResponseContainerMessage.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

