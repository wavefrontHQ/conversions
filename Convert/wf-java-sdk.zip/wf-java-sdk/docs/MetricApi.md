# MetricApi

All URIs are relative to *https://localhost/*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getMetricDetails**](MetricApi.md#getMetricDetails) | **GET** /api/v2/chart/metric/detail | Get more details on a metric, including reporting sources and approximate last time reported


<a name="getMetricDetails"></a>
# **getMetricDetails**
> List&lt;MetricDetails&gt; getMetricDetails(m, c, h)

Get more details on a metric, including reporting sources and approximate last time reported



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.MetricApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

MetricApi apiInstance = new MetricApi();
String m = "m_example"; // String | Metric name
String c = "c_example"; // String | cursor value to continue if the number of results exceeds 1000
List<String> h = Arrays.asList("h_example"); // List<String> | glob pattern for sources to include in the query result
try {
    List<MetricDetails> result = apiInstance.getMetricDetails(m, c, h);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling MetricApi#getMetricDetails");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **m** | **String**| Metric name |
 **c** | **String**| cursor value to continue if the number of results exceeds 1000 | [optional]
 **h** | [**List&lt;String&gt;**](String.md)| glob pattern for sources to include in the query result | [optional]

### Return type

[**List&lt;MetricDetails&gt;**](MetricDetails.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/x-javascript, application/javascript

