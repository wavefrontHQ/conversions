
# MetricDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**host** | **String** | The source reporting this metric |  [optional]
**lastUpdate** | **Long** | Approximate time of last reporting, in milliseconds since the Unix epoch |  [optional]
**tags** | **Map&lt;String, String&gt;** | A key-value map of the point tags associated with this source |  [optional]



