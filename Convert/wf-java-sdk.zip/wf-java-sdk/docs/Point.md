
# Point

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **Double** |  | 
**timestamp** | **Long** | The timestamp of the point in milliseconds | 



