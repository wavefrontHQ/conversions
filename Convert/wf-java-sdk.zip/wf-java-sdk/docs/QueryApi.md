# QueryApi

All URIs are relative to *https://localhost/*

Method | HTTP request | Description
------------- | ------------- | -------------
[**queryApi**](QueryApi.md#queryApi) | **GET** /api/v2/chart/api | Perform a charting query against Wavefront servers that returns the appropriate points in the specified time window and granularity
[**queryRaw**](QueryApi.md#queryRaw) | **GET** /api/v2/chart/raw | Perform a raw data query against Wavefront servers that returns second granularity points grouped by tags


<a name="queryApi"></a>
# **queryApi**
> QueryResult queryApi(q, s, g, n, e, p, i, autoEvents, summarization, listMode, strict, includeObsoleteMetrics, sorted)

Perform a charting query against Wavefront servers that returns the appropriate points in the specified time window and granularity

Long time spans and small granularities can take a long time to calculate

### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.QueryApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

QueryApi apiInstance = new QueryApi();
String q = "q_example"; // String | the query expression to execute
String s = "s_example"; // String | the start time of the query window in epoch milliseconds
String g = "g_example"; // String | the granularity of the points returned
String n = "n_example"; // String | name used to identify the query
String e = "e_example"; // String | the end time of the query window in epoch milliseconds (null to use now)
String p = "p_example"; // String | the maximum number of points to return
Boolean i = true; // Boolean | whether series with only points that are outside of the query window will be returned (defaults to true)
Boolean autoEvents = true; // Boolean | whether events for sources included in the query will be automatically returned by the query
String summarization = "summarization_example"; // String | summarization strategy to use when bucketing points together
Boolean listMode = true; // Boolean | retrieve events more optimally displayed for a list
Boolean strict = true; // Boolean | do not return points outside the query window [s;e), defaults to false
Boolean includeObsoleteMetrics = true; // Boolean | include metrics that have not been reporting recently, defaults to false
Boolean sorted = false; // Boolean | sorts the output so that returned series are in order, defaults to false
try {
    QueryResult result = apiInstance.queryApi(q, s, g, n, e, p, i, autoEvents, summarization, listMode, strict, includeObsoleteMetrics, sorted);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling QueryApi#queryApi");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **q** | **String**| the query expression to execute |
 **s** | **String**| the start time of the query window in epoch milliseconds |
 **g** | **String**| the granularity of the points returned | [enum: d, h, m, s]
 **n** | **String**| name used to identify the query | [optional]
 **e** | **String**| the end time of the query window in epoch milliseconds (null to use now) | [optional]
 **p** | **String**| the maximum number of points to return | [optional]
 **i** | **Boolean**| whether series with only points that are outside of the query window will be returned (defaults to true) | [optional]
 **autoEvents** | **Boolean**| whether events for sources included in the query will be automatically returned by the query | [optional]
 **summarization** | **String**| summarization strategy to use when bucketing points together | [optional] [enum: MEAN, MEDIAN, MIN, MAX, SUM, COUNT, LAST, FIRST]
 **listMode** | **Boolean**| retrieve events more optimally displayed for a list | [optional]
 **strict** | **Boolean**| do not return points outside the query window [s;e), defaults to false | [optional]
 **includeObsoleteMetrics** | **Boolean**| include metrics that have not been reporting recently, defaults to false | [optional]
 **sorted** | **Boolean**| sorts the output so that returned series are in order, defaults to false | [optional] [default to false]

### Return type

[**QueryResult**](QueryResult.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/x-javascript; charset=UTF-8, application/javascript; charset=UTF-8

<a name="queryRaw"></a>
# **queryRaw**
> List&lt;Timeseries&gt; queryRaw(metric, host, source, startTime, endTime)

Perform a raw data query against Wavefront servers that returns second granularity points grouped by tags

An API to check if ingested points are as expected.  Points ingested within a single second are averaged when returned.

### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.QueryApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

QueryApi apiInstance = new QueryApi();
String metric = "metric_example"; // String | metric to query ingested points for (cannot contain wildcards)
String host = "host_example"; // String | host to query ingested points for (cannot contain wildcards). host or source is equivalent, only one should be used.
String source = "source_example"; // String | source to query ingested points for (cannot contain wildcards). host or source is equivalent, only one should be used.
Long startTime = 789L; // Long | start time in epoch milliseconds (cannot be more than a day in the past) null to use an hour before endTime
Long endTime = 789L; // Long | end time in epoch milliseconds (cannot be more than a day in the past) null to use now
try {
    List<Timeseries> result = apiInstance.queryRaw(metric, host, source, startTime, endTime);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling QueryApi#queryRaw");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **metric** | **String**| metric to query ingested points for (cannot contain wildcards) |
 **host** | **String**| host to query ingested points for (cannot contain wildcards). host or source is equivalent, only one should be used. | [optional]
 **source** | **String**| source to query ingested points for (cannot contain wildcards). host or source is equivalent, only one should be used. | [optional]
 **startTime** | **Long**| start time in epoch milliseconds (cannot be more than a day in the past) null to use an hour before endTime | [optional]
 **endTime** | **Long**| end time in epoch milliseconds (cannot be more than a day in the past) null to use now | [optional]

### Return type

[**List&lt;Timeseries&gt;**](Timeseries.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

