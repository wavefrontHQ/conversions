
# QueryKeyContainer

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  |  [optional]
**metric** | **String** |  |  [optional]
**host** | **String** |  |  [optional]
**tags** | **Map&lt;String, String&gt;** |  |  [optional]
**hostTag** | **String** |  |  [optional]



