
# QueryResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**query** | **String** | The query string used to obtain this result |  [optional]
**name** | **String** | The name of this query |  [optional]
**skip** | **Integer** | Unused/deprecated |  [optional]
**stats** | [**StatsModel**](StatsModel.md) | Statistics about the result data |  [optional]
**warnings** | **String** | The warnings incurred by this query |  [optional]
**metricsUsed** | **List&lt;String&gt;** |  |  [optional]
**hostsUsed** | **List&lt;String&gt;** |  |  [optional]
**hostTagsUsed** | **List&lt;String&gt;** |  |  [optional]
**granularity** | **Long** |  |  [optional]
**numCompilationTasks** | **Integer** |  |  [optional]
**queryKeys** | [**List&lt;QueryKeyContainer&gt;**](QueryKeyContainer.md) |  |  [optional]
**rawPointsStats** | [**List&lt;TimeseriesStatsContainer&gt;**](TimeseriesStatsContainer.md) |  |  [optional]
**summarizedPointsStats** | [**List&lt;TimeseriesStatsContainer&gt;**](TimeseriesStatsContainer.md) |  |  [optional]
**timeseries** | [**List&lt;Timeseries&gt;**](Timeseries.md) | The time series data for this query |  [optional]
**events** | [**List&lt;ReportEvent&gt;**](ReportEvent.md) | The events occurring during this time span |  [optional]



