
# ReportEvent

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | Name of the event | 
**startTime** | **Long** | Start time in milliseconds for the event | 
**endTime** | **Long** | End time in milliseconds for the event. If missing, the event is ongoing |  [optional]
**annotations** | **Map&lt;String, String&gt;** | Annotations for the event. Searchable during queries |  [optional]
**hosts** | **List&lt;String&gt;** | Hosts associated for the event |  [optional]
**summarizedEvents** | **Long** |  |  [optional]
**tags** | **List&lt;String&gt;** |  |  [optional]
**isUserEvent** | **Boolean** |  |  [optional]
**isEphemeral** | **Boolean** |  |  [optional]
**table** | **String** | The customer that owns the event |  [optional]
**creatorId** | **String** |  |  [optional]
**updaterId** | **String** |  |  [optional]
**createdAt** | **Long** |  |  [optional]
**updatedAt** | **Long** |  |  [optional]



