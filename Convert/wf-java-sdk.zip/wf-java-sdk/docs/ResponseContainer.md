
# ResponseContainer

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | [**ResponseStatus**](ResponseStatus.md) |  | 
**response** | **Object** | The response, if the request is successful |  [optional]



