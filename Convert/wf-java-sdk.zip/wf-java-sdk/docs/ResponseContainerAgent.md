
# ResponseContainerAgent

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | [**ResponseStatus**](ResponseStatus.md) |  | 
**response** | [**Agent**](Agent.md) | The response, if the request is successful |  [optional]



