
# ResponseContainerAlert

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | [**ResponseStatus**](ResponseStatus.md) |  | 
**response** | [**Alert**](Alert.md) | The response, if the request is successful |  [optional]



