
# ResponseContainerEvent

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | [**ResponseStatus**](ResponseStatus.md) |  | 
**response** | [**Event**](Event.md) | The response, if the request is successful |  [optional]



