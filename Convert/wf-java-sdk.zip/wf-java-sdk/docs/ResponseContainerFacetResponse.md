
# ResponseContainerFacetResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | [**ResponseStatus**](ResponseStatus.md) |  | 
**response** | [**FacetResponse**](FacetResponse.md) | The response, if the request is successful |  [optional]



