
# ResponseContainerHistoryResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | [**ResponseStatus**](ResponseStatus.md) |  | 
**response** | [**HistoryResponse**](HistoryResponse.md) | The response, if the request is successful |  [optional]



