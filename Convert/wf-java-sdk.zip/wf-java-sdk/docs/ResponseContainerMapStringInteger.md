
# ResponseContainerMapStringInteger

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | [**ResponseStatus**](ResponseStatus.md) |  | 
**response** | **Map&lt;String, Integer&gt;** | The response, if the request is successful |  [optional]



