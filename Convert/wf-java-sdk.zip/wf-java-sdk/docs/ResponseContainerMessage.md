
# ResponseContainerMessage

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | [**ResponseStatus**](ResponseStatus.md) |  | 
**response** | [**Message**](Message.md) | The response, if the request is successful |  [optional]



