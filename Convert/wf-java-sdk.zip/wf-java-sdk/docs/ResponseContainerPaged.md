
# ResponseContainerPaged

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | [**ResponseStatus**](ResponseStatus.md) |  | 
**response** | [**Paged**](Paged.md) | The response, if the request is successful |  [optional]



