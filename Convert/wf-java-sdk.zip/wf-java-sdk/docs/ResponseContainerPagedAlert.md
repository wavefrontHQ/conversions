
# ResponseContainerPagedAlert

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | [**ResponseStatus**](ResponseStatus.md) |  | 
**response** | [**PagedAlert**](PagedAlert.md) | The response, if the request is successful |  [optional]



