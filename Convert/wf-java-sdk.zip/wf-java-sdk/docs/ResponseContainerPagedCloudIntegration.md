
# ResponseContainerPagedCloudIntegration

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | [**ResponseStatus**](ResponseStatus.md) |  | 
**response** | [**PagedCloudIntegration**](PagedCloudIntegration.md) | The response, if the request is successful |  [optional]



