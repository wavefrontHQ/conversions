
# ResponseContainerPagedExternalLink

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | [**ResponseStatus**](ResponseStatus.md) |  | 
**response** | [**PagedExternalLink**](PagedExternalLink.md) | The response, if the request is successful |  [optional]



