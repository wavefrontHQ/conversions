
# ResponseContainerPagedMaintenanceWindow

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | [**ResponseStatus**](ResponseStatus.md) |  | 
**response** | [**PagedMaintenanceWindow**](PagedMaintenanceWindow.md) | The response, if the request is successful |  [optional]



