
# ResponseContainerPagedMessage

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | [**ResponseStatus**](ResponseStatus.md) |  | 
**response** | [**PagedMessage**](PagedMessage.md) | The response, if the request is successful |  [optional]



