
# ResponseContainerPagedSource

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | [**ResponseStatus**](ResponseStatus.md) |  | 
**response** | [**PagedSource**](PagedSource.md) | The response, if the request is successful |  [optional]



