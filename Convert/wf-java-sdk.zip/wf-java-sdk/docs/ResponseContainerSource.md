
# ResponseContainerSource

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | [**ResponseStatus**](ResponseStatus.md) |  | 
**response** | [**Source**](Source.md) | The response, if the request is successful |  [optional]



