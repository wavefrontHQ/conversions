
# ResponseContainerWebhook

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | [**ResponseStatus**](ResponseStatus.md) |  | 
**response** | [**Webhook**](Webhook.md) | The response, if the request is successful |  [optional]



