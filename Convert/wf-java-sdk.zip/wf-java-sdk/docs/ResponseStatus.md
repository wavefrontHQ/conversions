
# ResponseStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**result** | [**ResultEnum**](#ResultEnum) |  | 
**message** | **String** | Descriptive message of the status of this response |  [optional]
**code** | **Long** | HTTP Response code corresponding to this response | 


<a name="ResultEnum"></a>
## Enum: ResultEnum
Name | Value
---- | -----
OK | &quot;OK&quot;
ERROR | &quot;ERROR&quot;



