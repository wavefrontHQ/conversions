
# SavedSearch

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  |  [optional]
**query** | **Map&lt;String, String&gt;** | The map corresponding to the search query.  The key is the name of the query, and the value is a JSON representation of the query | 
**createdEpochMillis** | **Long** |  |  [optional]
**updatedEpochMillis** | **Long** |  |  [optional]
**updaterId** | **String** |  |  [optional]
**creatorId** | **String** |  |  [optional]
**userId** | **String** | The user for whom this search is saved | 
**entityType** | [**EntityTypeEnum**](#EntityTypeEnum) | The Wavefront entity type over which to search | 


<a name="EntityTypeEnum"></a>
## Enum: EntityTypeEnum
Name | Value
---- | -----
DASHBOARD | &quot;DASHBOARD&quot;
ALERT | &quot;ALERT&quot;
MAINTENANCE_WINDOW | &quot;MAINTENANCE_WINDOW&quot;
NOTIFICANT | &quot;NOTIFICANT&quot;
EVENT | &quot;EVENT&quot;
SOURCE | &quot;SOURCE&quot;
EXTERNAL_LINK | &quot;EXTERNAL_LINK&quot;
AGENT | &quot;AGENT&quot;
CLOUD_INTEGRATION | &quot;CLOUD_INTEGRATION&quot;



