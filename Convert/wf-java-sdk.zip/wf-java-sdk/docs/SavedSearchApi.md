# SavedSearchApi

All URIs are relative to *https://localhost/*

Method | HTTP request | Description
------------- | ------------- | -------------
[**createSavedSearch**](SavedSearchApi.md#createSavedSearch) | **POST** /api/v2/savedsearch | Create a saved search
[**deleteSavedSearch**](SavedSearchApi.md#deleteSavedSearch) | **DELETE** /api/v2/savedsearch/{id} | Delete a specific saved search
[**getAllEntityTypeSavedSearches**](SavedSearchApi.md#getAllEntityTypeSavedSearches) | **GET** /api/v2/savedsearch/type/{entitytype} | Get all saved searches for a specific entity type for a user
[**getAllSavedSearches**](SavedSearchApi.md#getAllSavedSearches) | **GET** /api/v2/savedsearch | Get all saved searches for a user
[**getSavedSearch**](SavedSearchApi.md#getSavedSearch) | **GET** /api/v2/savedsearch/{id} | Get a specific saved search
[**updateSavedSearch**](SavedSearchApi.md#updateSavedSearch) | **PUT** /api/v2/savedsearch/{id} | Update a specific saved search


<a name="createSavedSearch"></a>
# **createSavedSearch**
> ResponseContainerSavedSearch createSavedSearch(body)

Create a saved search



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.SavedSearchApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SavedSearchApi apiInstance = new SavedSearchApi();
SavedSearch body = new SavedSearch(); // SavedSearch | Example Body:  <pre>{   \"query\": {     \"foo\": \"{\\\"searchTerms\\\":[{\\\"type\\\":\\\"freetext\\\",\\\"value\\\":\\\"foo\\\"}]}\"   },   \"entityType\": \"DASHBOARD\" }</pre>
try {
    ResponseContainerSavedSearch result = apiInstance.createSavedSearch(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SavedSearchApi#createSavedSearch");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**SavedSearch**](SavedSearch.md)| Example Body:  &lt;pre&gt;{   \&quot;query\&quot;: {     \&quot;foo\&quot;: \&quot;{\\\&quot;searchTerms\\\&quot;:[{\\\&quot;type\\\&quot;:\\\&quot;freetext\\\&quot;,\\\&quot;value\\\&quot;:\\\&quot;foo\\\&quot;}]}\&quot;   },   \&quot;entityType\&quot;: \&quot;DASHBOARD\&quot; }&lt;/pre&gt; | [optional]

### Return type

[**ResponseContainerSavedSearch**](ResponseContainerSavedSearch.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="deleteSavedSearch"></a>
# **deleteSavedSearch**
> ResponseContainerSavedSearch deleteSavedSearch(id)

Delete a specific saved search



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.SavedSearchApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SavedSearchApi apiInstance = new SavedSearchApi();
String id = "id_example"; // String | 
try {
    ResponseContainerSavedSearch result = apiInstance.deleteSavedSearch(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SavedSearchApi#deleteSavedSearch");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |

### Return type

[**ResponseContainerSavedSearch**](ResponseContainerSavedSearch.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getAllEntityTypeSavedSearches"></a>
# **getAllEntityTypeSavedSearches**
> ResponseContainerPagedSavedSearch getAllEntityTypeSavedSearches(entitytype, offset, limit)

Get all saved searches for a specific entity type for a user



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.SavedSearchApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SavedSearchApi apiInstance = new SavedSearchApi();
String entitytype = "entitytype_example"; // String | 
Integer offset = 0; // Integer | 
Integer limit = 100; // Integer | 
try {
    ResponseContainerPagedSavedSearch result = apiInstance.getAllEntityTypeSavedSearches(entitytype, offset, limit);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SavedSearchApi#getAllEntityTypeSavedSearches");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **entitytype** | **String**|  | [enum: DASHBOARD, ALERT, MAINTENANCE_WINDOW, NOTIFICANT, EVENT, SOURCE, EXTERNAL_LINK, AGENT, CLOUD_INTEGRATION]
 **offset** | **Integer**|  | [optional] [default to 0]
 **limit** | **Integer**|  | [optional] [default to 100]

### Return type

[**ResponseContainerPagedSavedSearch**](ResponseContainerPagedSavedSearch.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getAllSavedSearches"></a>
# **getAllSavedSearches**
> ResponseContainerPagedSavedSearch getAllSavedSearches(offset, limit)

Get all saved searches for a user



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.SavedSearchApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SavedSearchApi apiInstance = new SavedSearchApi();
Integer offset = 0; // Integer | 
Integer limit = 100; // Integer | 
try {
    ResponseContainerPagedSavedSearch result = apiInstance.getAllSavedSearches(offset, limit);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SavedSearchApi#getAllSavedSearches");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **offset** | **Integer**|  | [optional] [default to 0]
 **limit** | **Integer**|  | [optional] [default to 100]

### Return type

[**ResponseContainerPagedSavedSearch**](ResponseContainerPagedSavedSearch.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getSavedSearch"></a>
# **getSavedSearch**
> ResponseContainerSavedSearch getSavedSearch(id)

Get a specific saved search



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.SavedSearchApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SavedSearchApi apiInstance = new SavedSearchApi();
String id = "id_example"; // String | 
try {
    ResponseContainerSavedSearch result = apiInstance.getSavedSearch(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SavedSearchApi#getSavedSearch");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |

### Return type

[**ResponseContainerSavedSearch**](ResponseContainerSavedSearch.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="updateSavedSearch"></a>
# **updateSavedSearch**
> ResponseContainerSavedSearch updateSavedSearch(id, body)

Update a specific saved search



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.SavedSearchApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SavedSearchApi apiInstance = new SavedSearchApi();
String id = "id_example"; // String | 
SavedSearch body = new SavedSearch(); // SavedSearch | Example Body:  <pre>{   \"query\": {     \"foo\": \"{\\\"searchTerms\\\":[{\\\"type\\\":\\\"freetext\\\",\\\"value\\\":\\\"foo\\\"}]}\"   },   \"entityType\": \"DASHBOARD\" }</pre>
try {
    ResponseContainerSavedSearch result = apiInstance.updateSavedSearch(id, body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SavedSearchApi#updateSavedSearch");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |
 **body** | [**SavedSearch**](SavedSearch.md)| Example Body:  &lt;pre&gt;{   \&quot;query\&quot;: {     \&quot;foo\&quot;: \&quot;{\\\&quot;searchTerms\\\&quot;:[{\\\&quot;type\\\&quot;:\\\&quot;freetext\\\&quot;,\\\&quot;value\\\&quot;:\\\&quot;foo\\\&quot;}]}\&quot;   },   \&quot;entityType\&quot;: \&quot;DASHBOARD\&quot; }&lt;/pre&gt; | [optional]

### Return type

[**ResponseContainerSavedSearch**](ResponseContainerSavedSearch.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

