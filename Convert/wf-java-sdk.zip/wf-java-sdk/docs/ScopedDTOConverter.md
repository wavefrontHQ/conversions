
# ScopedDTOConverter

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



