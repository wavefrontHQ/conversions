# SearchApi

All URIs are relative to *https://localhost/*

Method | HTTP request | Description
------------- | ------------- | -------------
[**searchAgentDeletedEntities**](SearchApi.md#searchAgentDeletedEntities) | **POST** /api/v2/search/agent/deleted | Search over a customer&#39;s deleted agents
[**searchAgentDeletedForFacet**](SearchApi.md#searchAgentDeletedForFacet) | **POST** /api/v2/search/agent/deleted/{facet} | Lists the values of a specific facet over the customer&#39;s deleted agents
[**searchAgentDeletedForFacets**](SearchApi.md#searchAgentDeletedForFacets) | **POST** /api/v2/search/agent/deleted/facets | Lists the values of one or more facets over the customer&#39;s deleted agents
[**searchAgentEntities**](SearchApi.md#searchAgentEntities) | **POST** /api/v2/search/agent | Search over a customer&#39;s non-deleted agents
[**searchAgentForFacet**](SearchApi.md#searchAgentForFacet) | **POST** /api/v2/search/agent/{facet} | Lists the values of a specific facet over the customer&#39;s non-deleted agents
[**searchAgentForFacets**](SearchApi.md#searchAgentForFacets) | **POST** /api/v2/search/agent/facets | Lists the values of one or more facets over the customer&#39;s non-deleted agents
[**searchAlertDeletedEntities**](SearchApi.md#searchAlertDeletedEntities) | **POST** /api/v2/search/alert/deleted | Search over a customer&#39;s deleted alerts
[**searchAlertDeletedForFacet**](SearchApi.md#searchAlertDeletedForFacet) | **POST** /api/v2/search/alert/deleted/{facet} | Lists the values of a specific facet over the customer&#39;s deleted alerts
[**searchAlertDeletedForFacets**](SearchApi.md#searchAlertDeletedForFacets) | **POST** /api/v2/search/alert/deleted/facets | Lists the values of one or more facets over the customer&#39;s deleted alerts
[**searchAlertEntities**](SearchApi.md#searchAlertEntities) | **POST** /api/v2/search/alert | Search over a customer&#39;s non-deleted alerts
[**searchAlertForFacet**](SearchApi.md#searchAlertForFacet) | **POST** /api/v2/search/alert/{facet} | Lists the values of a specific facet over the customer&#39;s non-deleted alerts
[**searchAlertForFacets**](SearchApi.md#searchAlertForFacets) | **POST** /api/v2/search/alert/facets | Lists the values of one or more facets over the customer&#39;s non-deleted alerts
[**searchCloudIntegrationDeletedEntities**](SearchApi.md#searchCloudIntegrationDeletedEntities) | **POST** /api/v2/search/cloudintegration/deleted | Search over a customer&#39;s deleted cloud integrations
[**searchCloudIntegrationDeletedForFacet**](SearchApi.md#searchCloudIntegrationDeletedForFacet) | **POST** /api/v2/search/cloudintegration/deleted/{facet} | Lists the values of a specific facet over the customer&#39;s deleted cloud integrations
[**searchCloudIntegrationDeletedForFacets**](SearchApi.md#searchCloudIntegrationDeletedForFacets) | **POST** /api/v2/search/cloudintegration/deleted/facets | Lists the values of one or more facets over the customer&#39;s deleted cloud integrations
[**searchCloudIntegrationEntities**](SearchApi.md#searchCloudIntegrationEntities) | **POST** /api/v2/search/cloudintegration | Search over a customer&#39;s non-deleted cloud integrations
[**searchCloudIntegrationForFacet**](SearchApi.md#searchCloudIntegrationForFacet) | **POST** /api/v2/search/cloudintegration/{facet} | Lists the values of a specific facet over the customer&#39;s non-deleted cloud integrations
[**searchCloudIntegrationForFacets**](SearchApi.md#searchCloudIntegrationForFacets) | **POST** /api/v2/search/cloudintegration/facets | Lists the values of one or more facets over the customer&#39;s non-deleted cloud integrations
[**searchDashboardDeletedEntities**](SearchApi.md#searchDashboardDeletedEntities) | **POST** /api/v2/search/dashboard/deleted | Search over a customer&#39;s deleted dashboards
[**searchDashboardDeletedForFacet**](SearchApi.md#searchDashboardDeletedForFacet) | **POST** /api/v2/search/dashboard/deleted/{facet} | Lists the values of a specific facet over the customer&#39;s deleted dashboards
[**searchDashboardDeletedForFacets**](SearchApi.md#searchDashboardDeletedForFacets) | **POST** /api/v2/search/dashboard/deleted/facets | Lists the values of one or more facets over the customer&#39;s deleted dashboards
[**searchDashboardEntities**](SearchApi.md#searchDashboardEntities) | **POST** /api/v2/search/dashboard | Search over a customer&#39;s non-deleted dashboards
[**searchDashboardForFacet**](SearchApi.md#searchDashboardForFacet) | **POST** /api/v2/search/dashboard/{facet} | Lists the values of a specific facet over the customer&#39;s non-deleted dashboards
[**searchDashboardForFacets**](SearchApi.md#searchDashboardForFacets) | **POST** /api/v2/search/dashboard/facets | Lists the values of one or more facets over the customer&#39;s non-deleted dashboards
[**searchExternalLinkEntities**](SearchApi.md#searchExternalLinkEntities) | **POST** /api/v2/search/extlink | Search over a customer&#39;s external links
[**searchExternalLinksForFacet**](SearchApi.md#searchExternalLinksForFacet) | **POST** /api/v2/search/extlink/{facet} | Lists the values of a specific facet over the customer&#39;s external links
[**searchExternalLinksForFacets**](SearchApi.md#searchExternalLinksForFacets) | **POST** /api/v2/search/extlink/facets | Lists the values of one or more facets over the customer&#39;s external links
[**searchMaintenanceWindowEntities**](SearchApi.md#searchMaintenanceWindowEntities) | **POST** /api/v2/search/maintenancewindow | Search over a customer&#39;s maintenance windows
[**searchMaintenanceWindowForFacet**](SearchApi.md#searchMaintenanceWindowForFacet) | **POST** /api/v2/search/maintenancewindow/{facet} | Lists the values of a specific facet over the customer&#39;s maintenance windows
[**searchMaintenanceWindowForFacets**](SearchApi.md#searchMaintenanceWindowForFacets) | **POST** /api/v2/search/maintenancewindow/facets | Lists the values of one or more facets over the customer&#39;s maintenance windows
[**searchNotficantForFacets**](SearchApi.md#searchNotficantForFacets) | **POST** /api/v2/search/webhook/facets | Lists the values of one or more facets over the customer&#39;s webhooks
[**searchNotificantEntities**](SearchApi.md#searchNotificantEntities) | **POST** /api/v2/search/webhook | Search over a customer&#39;s webhooks
[**searchNotificantForFacet**](SearchApi.md#searchNotificantForFacet) | **POST** /api/v2/search/webhook/{facet} | Lists the values of a specific facet over the customer&#39;s webhooks
[**searchReportEventEntities**](SearchApi.md#searchReportEventEntities) | **POST** /api/v2/search/event | Search over a customer&#39;s events
[**searchReportEventForFacet**](SearchApi.md#searchReportEventForFacet) | **POST** /api/v2/search/event/{facet} | Lists the values of a specific facet over the customer&#39;s events
[**searchReportEventForFacets**](SearchApi.md#searchReportEventForFacets) | **POST** /api/v2/search/event/facets | Lists the values of one or more facets over the customer&#39;s events
[**searchTaggedSourceEntities**](SearchApi.md#searchTaggedSourceEntities) | **POST** /api/v2/search/source | Search over a customer&#39;s sources
[**searchTaggedSourceForFacet**](SearchApi.md#searchTaggedSourceForFacet) | **POST** /api/v2/search/source/{facet} | Lists the values of a specific facet over the customer&#39;s sources
[**searchTaggedSourceForFacets**](SearchApi.md#searchTaggedSourceForFacets) | **POST** /api/v2/search/source/facets | Lists the values of one or more facets over the customer&#39;s sources


<a name="searchAgentDeletedEntities"></a>
# **searchAgentDeletedEntities**
> ResponseContainerPagedAgent searchAgentDeletedEntities(body)

Search over a customer&#39;s deleted agents



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.SearchApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SearchApi apiInstance = new SearchApi();
SortableSearchRequest body = new SortableSearchRequest(); // SortableSearchRequest | 
try {
    ResponseContainerPagedAgent result = apiInstance.searchAgentDeletedEntities(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SearchApi#searchAgentDeletedEntities");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**SortableSearchRequest**](SortableSearchRequest.md)|  | [optional]

### Return type

[**ResponseContainerPagedAgent**](ResponseContainerPagedAgent.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="searchAgentDeletedForFacet"></a>
# **searchAgentDeletedForFacet**
> ResponseContainerFacetResponse searchAgentDeletedForFacet(facet, body)

Lists the values of a specific facet over the customer&#39;s deleted agents



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.SearchApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SearchApi apiInstance = new SearchApi();
String facet = "facet_example"; // String | 
FacetSearchRequestContainer body = new FacetSearchRequestContainer(); // FacetSearchRequestContainer | 
try {
    ResponseContainerFacetResponse result = apiInstance.searchAgentDeletedForFacet(facet, body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SearchApi#searchAgentDeletedForFacet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **facet** | **String**|  |
 **body** | [**FacetSearchRequestContainer**](FacetSearchRequestContainer.md)|  | [optional]

### Return type

[**ResponseContainerFacetResponse**](ResponseContainerFacetResponse.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="searchAgentDeletedForFacets"></a>
# **searchAgentDeletedForFacets**
> ResponseContainerFacetsResponseContainer searchAgentDeletedForFacets(body)

Lists the values of one or more facets over the customer&#39;s deleted agents



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.SearchApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SearchApi apiInstance = new SearchApi();
FacetsSearchRequestContainer body = new FacetsSearchRequestContainer(); // FacetsSearchRequestContainer | 
try {
    ResponseContainerFacetsResponseContainer result = apiInstance.searchAgentDeletedForFacets(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SearchApi#searchAgentDeletedForFacets");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**FacetsSearchRequestContainer**](FacetsSearchRequestContainer.md)|  | [optional]

### Return type

[**ResponseContainerFacetsResponseContainer**](ResponseContainerFacetsResponseContainer.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="searchAgentEntities"></a>
# **searchAgentEntities**
> ResponseContainerPagedAgent searchAgentEntities(body)

Search over a customer&#39;s non-deleted agents



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.SearchApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SearchApi apiInstance = new SearchApi();
SortableSearchRequest body = new SortableSearchRequest(); // SortableSearchRequest | 
try {
    ResponseContainerPagedAgent result = apiInstance.searchAgentEntities(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SearchApi#searchAgentEntities");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**SortableSearchRequest**](SortableSearchRequest.md)|  | [optional]

### Return type

[**ResponseContainerPagedAgent**](ResponseContainerPagedAgent.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="searchAgentForFacet"></a>
# **searchAgentForFacet**
> ResponseContainerFacetResponse searchAgentForFacet(facet, body)

Lists the values of a specific facet over the customer&#39;s non-deleted agents



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.SearchApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SearchApi apiInstance = new SearchApi();
String facet = "facet_example"; // String | 
FacetSearchRequestContainer body = new FacetSearchRequestContainer(); // FacetSearchRequestContainer | 
try {
    ResponseContainerFacetResponse result = apiInstance.searchAgentForFacet(facet, body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SearchApi#searchAgentForFacet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **facet** | **String**|  |
 **body** | [**FacetSearchRequestContainer**](FacetSearchRequestContainer.md)|  | [optional]

### Return type

[**ResponseContainerFacetResponse**](ResponseContainerFacetResponse.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="searchAgentForFacets"></a>
# **searchAgentForFacets**
> ResponseContainerFacetsResponseContainer searchAgentForFacets(body)

Lists the values of one or more facets over the customer&#39;s non-deleted agents



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.SearchApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SearchApi apiInstance = new SearchApi();
FacetsSearchRequestContainer body = new FacetsSearchRequestContainer(); // FacetsSearchRequestContainer | 
try {
    ResponseContainerFacetsResponseContainer result = apiInstance.searchAgentForFacets(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SearchApi#searchAgentForFacets");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**FacetsSearchRequestContainer**](FacetsSearchRequestContainer.md)|  | [optional]

### Return type

[**ResponseContainerFacetsResponseContainer**](ResponseContainerFacetsResponseContainer.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="searchAlertDeletedEntities"></a>
# **searchAlertDeletedEntities**
> ResponseContainerPagedAlert searchAlertDeletedEntities(body)

Search over a customer&#39;s deleted alerts



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.SearchApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SearchApi apiInstance = new SearchApi();
SortableSearchRequest body = new SortableSearchRequest(); // SortableSearchRequest | 
try {
    ResponseContainerPagedAlert result = apiInstance.searchAlertDeletedEntities(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SearchApi#searchAlertDeletedEntities");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**SortableSearchRequest**](SortableSearchRequest.md)|  | [optional]

### Return type

[**ResponseContainerPagedAlert**](ResponseContainerPagedAlert.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="searchAlertDeletedForFacet"></a>
# **searchAlertDeletedForFacet**
> ResponseContainerFacetResponse searchAlertDeletedForFacet(facet, body)

Lists the values of a specific facet over the customer&#39;s deleted alerts



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.SearchApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SearchApi apiInstance = new SearchApi();
String facet = "facet_example"; // String | 
FacetSearchRequestContainer body = new FacetSearchRequestContainer(); // FacetSearchRequestContainer | 
try {
    ResponseContainerFacetResponse result = apiInstance.searchAlertDeletedForFacet(facet, body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SearchApi#searchAlertDeletedForFacet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **facet** | **String**|  |
 **body** | [**FacetSearchRequestContainer**](FacetSearchRequestContainer.md)|  | [optional]

### Return type

[**ResponseContainerFacetResponse**](ResponseContainerFacetResponse.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="searchAlertDeletedForFacets"></a>
# **searchAlertDeletedForFacets**
> ResponseContainerFacetsResponseContainer searchAlertDeletedForFacets(body)

Lists the values of one or more facets over the customer&#39;s deleted alerts



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.SearchApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SearchApi apiInstance = new SearchApi();
FacetsSearchRequestContainer body = new FacetsSearchRequestContainer(); // FacetsSearchRequestContainer | 
try {
    ResponseContainerFacetsResponseContainer result = apiInstance.searchAlertDeletedForFacets(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SearchApi#searchAlertDeletedForFacets");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**FacetsSearchRequestContainer**](FacetsSearchRequestContainer.md)|  | [optional]

### Return type

[**ResponseContainerFacetsResponseContainer**](ResponseContainerFacetsResponseContainer.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="searchAlertEntities"></a>
# **searchAlertEntities**
> ResponseContainerPaged searchAlertEntities(body)

Search over a customer&#39;s non-deleted alerts



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.SearchApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SearchApi apiInstance = new SearchApi();
SortableSearchRequest body = new SortableSearchRequest(); // SortableSearchRequest | 
try {
    ResponseContainerPaged result = apiInstance.searchAlertEntities(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SearchApi#searchAlertEntities");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**SortableSearchRequest**](SortableSearchRequest.md)|  | [optional]

### Return type

[**ResponseContainerPaged**](ResponseContainerPaged.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="searchAlertForFacet"></a>
# **searchAlertForFacet**
> ResponseContainerFacetResponse searchAlertForFacet(facet, body)

Lists the values of a specific facet over the customer&#39;s non-deleted alerts



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.SearchApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SearchApi apiInstance = new SearchApi();
String facet = "facet_example"; // String | 
FacetSearchRequestContainer body = new FacetSearchRequestContainer(); // FacetSearchRequestContainer | 
try {
    ResponseContainerFacetResponse result = apiInstance.searchAlertForFacet(facet, body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SearchApi#searchAlertForFacet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **facet** | **String**|  |
 **body** | [**FacetSearchRequestContainer**](FacetSearchRequestContainer.md)|  | [optional]

### Return type

[**ResponseContainerFacetResponse**](ResponseContainerFacetResponse.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="searchAlertForFacets"></a>
# **searchAlertForFacets**
> ResponseContainerFacetsResponseContainer searchAlertForFacets(body)

Lists the values of one or more facets over the customer&#39;s non-deleted alerts



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.SearchApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SearchApi apiInstance = new SearchApi();
FacetsSearchRequestContainer body = new FacetsSearchRequestContainer(); // FacetsSearchRequestContainer | 
try {
    ResponseContainerFacetsResponseContainer result = apiInstance.searchAlertForFacets(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SearchApi#searchAlertForFacets");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**FacetsSearchRequestContainer**](FacetsSearchRequestContainer.md)|  | [optional]

### Return type

[**ResponseContainerFacetsResponseContainer**](ResponseContainerFacetsResponseContainer.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="searchCloudIntegrationDeletedEntities"></a>
# **searchCloudIntegrationDeletedEntities**
> ResponseContainerPagedCloudIntegration searchCloudIntegrationDeletedEntities(body)

Search over a customer&#39;s deleted cloud integrations



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.SearchApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SearchApi apiInstance = new SearchApi();
SortableSearchRequest body = new SortableSearchRequest(); // SortableSearchRequest | 
try {
    ResponseContainerPagedCloudIntegration result = apiInstance.searchCloudIntegrationDeletedEntities(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SearchApi#searchCloudIntegrationDeletedEntities");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**SortableSearchRequest**](SortableSearchRequest.md)|  | [optional]

### Return type

[**ResponseContainerPagedCloudIntegration**](ResponseContainerPagedCloudIntegration.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="searchCloudIntegrationDeletedForFacet"></a>
# **searchCloudIntegrationDeletedForFacet**
> ResponseContainerFacetResponse searchCloudIntegrationDeletedForFacet(facet, body)

Lists the values of a specific facet over the customer&#39;s deleted cloud integrations



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.SearchApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SearchApi apiInstance = new SearchApi();
String facet = "facet_example"; // String | 
FacetSearchRequestContainer body = new FacetSearchRequestContainer(); // FacetSearchRequestContainer | 
try {
    ResponseContainerFacetResponse result = apiInstance.searchCloudIntegrationDeletedForFacet(facet, body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SearchApi#searchCloudIntegrationDeletedForFacet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **facet** | **String**|  |
 **body** | [**FacetSearchRequestContainer**](FacetSearchRequestContainer.md)|  | [optional]

### Return type

[**ResponseContainerFacetResponse**](ResponseContainerFacetResponse.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="searchCloudIntegrationDeletedForFacets"></a>
# **searchCloudIntegrationDeletedForFacets**
> ResponseContainerFacetsResponseContainer searchCloudIntegrationDeletedForFacets(body)

Lists the values of one or more facets over the customer&#39;s deleted cloud integrations



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.SearchApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SearchApi apiInstance = new SearchApi();
FacetsSearchRequestContainer body = new FacetsSearchRequestContainer(); // FacetsSearchRequestContainer | 
try {
    ResponseContainerFacetsResponseContainer result = apiInstance.searchCloudIntegrationDeletedForFacets(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SearchApi#searchCloudIntegrationDeletedForFacets");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**FacetsSearchRequestContainer**](FacetsSearchRequestContainer.md)|  | [optional]

### Return type

[**ResponseContainerFacetsResponseContainer**](ResponseContainerFacetsResponseContainer.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="searchCloudIntegrationEntities"></a>
# **searchCloudIntegrationEntities**
> ResponseContainerPagedCloudIntegration searchCloudIntegrationEntities(body)

Search over a customer&#39;s non-deleted cloud integrations



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.SearchApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SearchApi apiInstance = new SearchApi();
SortableSearchRequest body = new SortableSearchRequest(); // SortableSearchRequest | 
try {
    ResponseContainerPagedCloudIntegration result = apiInstance.searchCloudIntegrationEntities(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SearchApi#searchCloudIntegrationEntities");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**SortableSearchRequest**](SortableSearchRequest.md)|  | [optional]

### Return type

[**ResponseContainerPagedCloudIntegration**](ResponseContainerPagedCloudIntegration.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="searchCloudIntegrationForFacet"></a>
# **searchCloudIntegrationForFacet**
> ResponseContainerFacetResponse searchCloudIntegrationForFacet(facet, body)

Lists the values of a specific facet over the customer&#39;s non-deleted cloud integrations



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.SearchApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SearchApi apiInstance = new SearchApi();
String facet = "facet_example"; // String | 
FacetSearchRequestContainer body = new FacetSearchRequestContainer(); // FacetSearchRequestContainer | 
try {
    ResponseContainerFacetResponse result = apiInstance.searchCloudIntegrationForFacet(facet, body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SearchApi#searchCloudIntegrationForFacet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **facet** | **String**|  |
 **body** | [**FacetSearchRequestContainer**](FacetSearchRequestContainer.md)|  | [optional]

### Return type

[**ResponseContainerFacetResponse**](ResponseContainerFacetResponse.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="searchCloudIntegrationForFacets"></a>
# **searchCloudIntegrationForFacets**
> ResponseContainerFacetsResponseContainer searchCloudIntegrationForFacets(body)

Lists the values of one or more facets over the customer&#39;s non-deleted cloud integrations



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.SearchApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SearchApi apiInstance = new SearchApi();
FacetsSearchRequestContainer body = new FacetsSearchRequestContainer(); // FacetsSearchRequestContainer | 
try {
    ResponseContainerFacetsResponseContainer result = apiInstance.searchCloudIntegrationForFacets(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SearchApi#searchCloudIntegrationForFacets");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**FacetsSearchRequestContainer**](FacetsSearchRequestContainer.md)|  | [optional]

### Return type

[**ResponseContainerFacetsResponseContainer**](ResponseContainerFacetsResponseContainer.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="searchDashboardDeletedEntities"></a>
# **searchDashboardDeletedEntities**
> ResponseContainerPagedDashboard searchDashboardDeletedEntities(body)

Search over a customer&#39;s deleted dashboards



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.SearchApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SearchApi apiInstance = new SearchApi();
SortableSearchRequest body = new SortableSearchRequest(); // SortableSearchRequest | 
try {
    ResponseContainerPagedDashboard result = apiInstance.searchDashboardDeletedEntities(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SearchApi#searchDashboardDeletedEntities");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**SortableSearchRequest**](SortableSearchRequest.md)|  | [optional]

### Return type

[**ResponseContainerPagedDashboard**](ResponseContainerPagedDashboard.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="searchDashboardDeletedForFacet"></a>
# **searchDashboardDeletedForFacet**
> ResponseContainerFacetResponse searchDashboardDeletedForFacet(facet, body)

Lists the values of a specific facet over the customer&#39;s deleted dashboards



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.SearchApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SearchApi apiInstance = new SearchApi();
String facet = "facet_example"; // String | 
FacetSearchRequestContainer body = new FacetSearchRequestContainer(); // FacetSearchRequestContainer | 
try {
    ResponseContainerFacetResponse result = apiInstance.searchDashboardDeletedForFacet(facet, body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SearchApi#searchDashboardDeletedForFacet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **facet** | **String**|  |
 **body** | [**FacetSearchRequestContainer**](FacetSearchRequestContainer.md)|  | [optional]

### Return type

[**ResponseContainerFacetResponse**](ResponseContainerFacetResponse.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="searchDashboardDeletedForFacets"></a>
# **searchDashboardDeletedForFacets**
> ResponseContainerFacetsResponseContainer searchDashboardDeletedForFacets(body)

Lists the values of one or more facets over the customer&#39;s deleted dashboards



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.SearchApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SearchApi apiInstance = new SearchApi();
FacetsSearchRequestContainer body = new FacetsSearchRequestContainer(); // FacetsSearchRequestContainer | 
try {
    ResponseContainerFacetsResponseContainer result = apiInstance.searchDashboardDeletedForFacets(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SearchApi#searchDashboardDeletedForFacets");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**FacetsSearchRequestContainer**](FacetsSearchRequestContainer.md)|  | [optional]

### Return type

[**ResponseContainerFacetsResponseContainer**](ResponseContainerFacetsResponseContainer.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="searchDashboardEntities"></a>
# **searchDashboardEntities**
> ResponseContainerPagedDashboard searchDashboardEntities(body)

Search over a customer&#39;s non-deleted dashboards



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.SearchApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SearchApi apiInstance = new SearchApi();
SortableSearchRequest body = new SortableSearchRequest(); // SortableSearchRequest | 
try {
    ResponseContainerPagedDashboard result = apiInstance.searchDashboardEntities(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SearchApi#searchDashboardEntities");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**SortableSearchRequest**](SortableSearchRequest.md)|  | [optional]

### Return type

[**ResponseContainerPagedDashboard**](ResponseContainerPagedDashboard.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="searchDashboardForFacet"></a>
# **searchDashboardForFacet**
> ResponseContainerFacetResponse searchDashboardForFacet(facet, body)

Lists the values of a specific facet over the customer&#39;s non-deleted dashboards



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.SearchApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SearchApi apiInstance = new SearchApi();
String facet = "facet_example"; // String | 
FacetSearchRequestContainer body = new FacetSearchRequestContainer(); // FacetSearchRequestContainer | 
try {
    ResponseContainerFacetResponse result = apiInstance.searchDashboardForFacet(facet, body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SearchApi#searchDashboardForFacet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **facet** | **String**|  |
 **body** | [**FacetSearchRequestContainer**](FacetSearchRequestContainer.md)|  | [optional]

### Return type

[**ResponseContainerFacetResponse**](ResponseContainerFacetResponse.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="searchDashboardForFacets"></a>
# **searchDashboardForFacets**
> ResponseContainerFacetsResponseContainer searchDashboardForFacets(body)

Lists the values of one or more facets over the customer&#39;s non-deleted dashboards



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.SearchApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SearchApi apiInstance = new SearchApi();
FacetsSearchRequestContainer body = new FacetsSearchRequestContainer(); // FacetsSearchRequestContainer | 
try {
    ResponseContainerFacetsResponseContainer result = apiInstance.searchDashboardForFacets(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SearchApi#searchDashboardForFacets");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**FacetsSearchRequestContainer**](FacetsSearchRequestContainer.md)|  | [optional]

### Return type

[**ResponseContainerFacetsResponseContainer**](ResponseContainerFacetsResponseContainer.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="searchExternalLinkEntities"></a>
# **searchExternalLinkEntities**
> ResponseContainerPagedExternalLink searchExternalLinkEntities(body)

Search over a customer&#39;s external links



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.SearchApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SearchApi apiInstance = new SearchApi();
SortableSearchRequest body = new SortableSearchRequest(); // SortableSearchRequest | 
try {
    ResponseContainerPagedExternalLink result = apiInstance.searchExternalLinkEntities(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SearchApi#searchExternalLinkEntities");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**SortableSearchRequest**](SortableSearchRequest.md)|  | [optional]

### Return type

[**ResponseContainerPagedExternalLink**](ResponseContainerPagedExternalLink.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="searchExternalLinksForFacet"></a>
# **searchExternalLinksForFacet**
> ResponseContainerFacetResponse searchExternalLinksForFacet(facet, body)

Lists the values of a specific facet over the customer&#39;s external links



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.SearchApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SearchApi apiInstance = new SearchApi();
String facet = "facet_example"; // String | 
FacetSearchRequestContainer body = new FacetSearchRequestContainer(); // FacetSearchRequestContainer | 
try {
    ResponseContainerFacetResponse result = apiInstance.searchExternalLinksForFacet(facet, body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SearchApi#searchExternalLinksForFacet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **facet** | **String**|  |
 **body** | [**FacetSearchRequestContainer**](FacetSearchRequestContainer.md)|  | [optional]

### Return type

[**ResponseContainerFacetResponse**](ResponseContainerFacetResponse.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="searchExternalLinksForFacets"></a>
# **searchExternalLinksForFacets**
> ResponseContainerFacetsResponseContainer searchExternalLinksForFacets(body)

Lists the values of one or more facets over the customer&#39;s external links



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.SearchApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SearchApi apiInstance = new SearchApi();
FacetsSearchRequestContainer body = new FacetsSearchRequestContainer(); // FacetsSearchRequestContainer | 
try {
    ResponseContainerFacetsResponseContainer result = apiInstance.searchExternalLinksForFacets(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SearchApi#searchExternalLinksForFacets");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**FacetsSearchRequestContainer**](FacetsSearchRequestContainer.md)|  | [optional]

### Return type

[**ResponseContainerFacetsResponseContainer**](ResponseContainerFacetsResponseContainer.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="searchMaintenanceWindowEntities"></a>
# **searchMaintenanceWindowEntities**
> ResponseContainerPagedMaintenanceWindow searchMaintenanceWindowEntities(body)

Search over a customer&#39;s maintenance windows



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.SearchApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SearchApi apiInstance = new SearchApi();
SortableSearchRequest body = new SortableSearchRequest(); // SortableSearchRequest | 
try {
    ResponseContainerPagedMaintenanceWindow result = apiInstance.searchMaintenanceWindowEntities(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SearchApi#searchMaintenanceWindowEntities");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**SortableSearchRequest**](SortableSearchRequest.md)|  | [optional]

### Return type

[**ResponseContainerPagedMaintenanceWindow**](ResponseContainerPagedMaintenanceWindow.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="searchMaintenanceWindowForFacet"></a>
# **searchMaintenanceWindowForFacet**
> ResponseContainerFacetResponse searchMaintenanceWindowForFacet(facet, body)

Lists the values of a specific facet over the customer&#39;s maintenance windows



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.SearchApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SearchApi apiInstance = new SearchApi();
String facet = "facet_example"; // String | 
FacetSearchRequestContainer body = new FacetSearchRequestContainer(); // FacetSearchRequestContainer | 
try {
    ResponseContainerFacetResponse result = apiInstance.searchMaintenanceWindowForFacet(facet, body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SearchApi#searchMaintenanceWindowForFacet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **facet** | **String**|  |
 **body** | [**FacetSearchRequestContainer**](FacetSearchRequestContainer.md)|  | [optional]

### Return type

[**ResponseContainerFacetResponse**](ResponseContainerFacetResponse.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="searchMaintenanceWindowForFacets"></a>
# **searchMaintenanceWindowForFacets**
> ResponseContainerFacetsResponseContainer searchMaintenanceWindowForFacets(body)

Lists the values of one or more facets over the customer&#39;s maintenance windows



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.SearchApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SearchApi apiInstance = new SearchApi();
FacetsSearchRequestContainer body = new FacetsSearchRequestContainer(); // FacetsSearchRequestContainer | 
try {
    ResponseContainerFacetsResponseContainer result = apiInstance.searchMaintenanceWindowForFacets(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SearchApi#searchMaintenanceWindowForFacets");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**FacetsSearchRequestContainer**](FacetsSearchRequestContainer.md)|  | [optional]

### Return type

[**ResponseContainerFacetsResponseContainer**](ResponseContainerFacetsResponseContainer.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="searchNotficantForFacets"></a>
# **searchNotficantForFacets**
> ResponseContainerFacetsResponseContainer searchNotficantForFacets(body)

Lists the values of one or more facets over the customer&#39;s webhooks



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.SearchApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SearchApi apiInstance = new SearchApi();
FacetsSearchRequestContainer body = new FacetsSearchRequestContainer(); // FacetsSearchRequestContainer | 
try {
    ResponseContainerFacetsResponseContainer result = apiInstance.searchNotficantForFacets(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SearchApi#searchNotficantForFacets");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**FacetsSearchRequestContainer**](FacetsSearchRequestContainer.md)|  | [optional]

### Return type

[**ResponseContainerFacetsResponseContainer**](ResponseContainerFacetsResponseContainer.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="searchNotificantEntities"></a>
# **searchNotificantEntities**
> ResponseContainerPagedWebhook searchNotificantEntities(body)

Search over a customer&#39;s webhooks



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.SearchApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SearchApi apiInstance = new SearchApi();
SortableSearchRequest body = new SortableSearchRequest(); // SortableSearchRequest | 
try {
    ResponseContainerPagedWebhook result = apiInstance.searchNotificantEntities(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SearchApi#searchNotificantEntities");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**SortableSearchRequest**](SortableSearchRequest.md)|  | [optional]

### Return type

[**ResponseContainerPagedWebhook**](ResponseContainerPagedWebhook.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="searchNotificantForFacet"></a>
# **searchNotificantForFacet**
> ResponseContainerFacetResponse searchNotificantForFacet(facet, body)

Lists the values of a specific facet over the customer&#39;s webhooks



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.SearchApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SearchApi apiInstance = new SearchApi();
String facet = "facet_example"; // String | 
FacetSearchRequestContainer body = new FacetSearchRequestContainer(); // FacetSearchRequestContainer | 
try {
    ResponseContainerFacetResponse result = apiInstance.searchNotificantForFacet(facet, body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SearchApi#searchNotificantForFacet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **facet** | **String**|  |
 **body** | [**FacetSearchRequestContainer**](FacetSearchRequestContainer.md)|  | [optional]

### Return type

[**ResponseContainerFacetResponse**](ResponseContainerFacetResponse.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="searchReportEventEntities"></a>
# **searchReportEventEntities**
> ResponseContainerPagedEvent searchReportEventEntities(body)

Search over a customer&#39;s events



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.SearchApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SearchApi apiInstance = new SearchApi();
EventSearchRequest body = new EventSearchRequest(); // EventSearchRequest | 
try {
    ResponseContainerPagedEvent result = apiInstance.searchReportEventEntities(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SearchApi#searchReportEventEntities");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**EventSearchRequest**](EventSearchRequest.md)|  | [optional]

### Return type

[**ResponseContainerPagedEvent**](ResponseContainerPagedEvent.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="searchReportEventForFacet"></a>
# **searchReportEventForFacet**
> ResponseContainerFacetResponse searchReportEventForFacet(facet, body)

Lists the values of a specific facet over the customer&#39;s events



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.SearchApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SearchApi apiInstance = new SearchApi();
String facet = "facet_example"; // String | 
FacetSearchRequestContainer body = new FacetSearchRequestContainer(); // FacetSearchRequestContainer | 
try {
    ResponseContainerFacetResponse result = apiInstance.searchReportEventForFacet(facet, body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SearchApi#searchReportEventForFacet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **facet** | **String**|  |
 **body** | [**FacetSearchRequestContainer**](FacetSearchRequestContainer.md)|  | [optional]

### Return type

[**ResponseContainerFacetResponse**](ResponseContainerFacetResponse.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="searchReportEventForFacets"></a>
# **searchReportEventForFacets**
> ResponseContainerFacetsResponseContainer searchReportEventForFacets(body)

Lists the values of one or more facets over the customer&#39;s events



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.SearchApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SearchApi apiInstance = new SearchApi();
FacetsSearchRequestContainer body = new FacetsSearchRequestContainer(); // FacetsSearchRequestContainer | 
try {
    ResponseContainerFacetsResponseContainer result = apiInstance.searchReportEventForFacets(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SearchApi#searchReportEventForFacets");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**FacetsSearchRequestContainer**](FacetsSearchRequestContainer.md)|  | [optional]

### Return type

[**ResponseContainerFacetsResponseContainer**](ResponseContainerFacetsResponseContainer.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="searchTaggedSourceEntities"></a>
# **searchTaggedSourceEntities**
> ResponseContainerPagedSource searchTaggedSourceEntities(body)

Search over a customer&#39;s sources



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.SearchApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SearchApi apiInstance = new SearchApi();
SourceSearchRequestContainer body = new SourceSearchRequestContainer(); // SourceSearchRequestContainer | 
try {
    ResponseContainerPagedSource result = apiInstance.searchTaggedSourceEntities(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SearchApi#searchTaggedSourceEntities");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**SourceSearchRequestContainer**](SourceSearchRequestContainer.md)|  | [optional]

### Return type

[**ResponseContainerPagedSource**](ResponseContainerPagedSource.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="searchTaggedSourceForFacet"></a>
# **searchTaggedSourceForFacet**
> ResponseContainerFacetResponse searchTaggedSourceForFacet(facet, body)

Lists the values of a specific facet over the customer&#39;s sources



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.SearchApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SearchApi apiInstance = new SearchApi();
String facet = "facet_example"; // String | 
FacetSearchRequestContainer body = new FacetSearchRequestContainer(); // FacetSearchRequestContainer | 
try {
    ResponseContainerFacetResponse result = apiInstance.searchTaggedSourceForFacet(facet, body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SearchApi#searchTaggedSourceForFacet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **facet** | **String**|  |
 **body** | [**FacetSearchRequestContainer**](FacetSearchRequestContainer.md)|  | [optional]

### Return type

[**ResponseContainerFacetResponse**](ResponseContainerFacetResponse.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="searchTaggedSourceForFacets"></a>
# **searchTaggedSourceForFacets**
> ResponseContainerFacetsResponseContainer searchTaggedSourceForFacets(body)

Lists the values of one or more facets over the customer&#39;s sources



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.SearchApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SearchApi apiInstance = new SearchApi();
FacetsSearchRequestContainer body = new FacetsSearchRequestContainer(); // FacetsSearchRequestContainer | 
try {
    ResponseContainerFacetsResponseContainer result = apiInstance.searchTaggedSourceForFacets(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SearchApi#searchTaggedSourceForFacets");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**FacetsSearchRequestContainer**](FacetsSearchRequestContainer.md)|  | [optional]

### Return type

[**ResponseContainerFacetsResponseContainer**](ResponseContainerFacetsResponseContainer.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

