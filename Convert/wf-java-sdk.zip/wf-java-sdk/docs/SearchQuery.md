
# SearchQuery

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**key** | **String** | The entity facet (key) by which to search.  Valid keys are any property keys returned by the JSON representation of the entity.  Examples are &#39;creatorId&#39;, &#39;name&#39;, etc.  The following special key keywords are also valid:  &#39;tags&#39; performs a search on entity tags, &#39;tagpath&#39; performs a hierarchical search on tags, with  periods (.) as path level separators.  &#39;freetext&#39; performs a free text search across many fields of the entity | 
**value** | **String** | The entity facet value for which to search | 
**matchingMethod** | [**MatchingMethodEnum**](#MatchingMethodEnum) | The method by which search matching is performed.  Default: CONTAINS |  [optional]


<a name="MatchingMethodEnum"></a>
## Enum: MatchingMethodEnum
Name | Value
---- | -----
CONTAINS | &quot;CONTAINS&quot;
STARTSWITH | &quot;STARTSWITH&quot;
EXACT | &quot;EXACT&quot;
TAGPATH | &quot;TAGPATH&quot;



