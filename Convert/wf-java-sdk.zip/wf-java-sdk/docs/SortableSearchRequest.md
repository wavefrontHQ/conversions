
# SortableSearchRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**limit** | **Integer** | The number of results to return.  Default: 100 |  [optional]
**offset** | **Integer** | The number of results to skip before returning values.  Default: 0 |  [optional]
**query** | [**List&lt;SearchQuery&gt;**](SearchQuery.md) | A list of queries by which to limit the search results.  Entities that match ALL queries in the list are returned |  [optional]
**sort** | [**Sorting**](Sorting.md) | How to sort the items in the response |  [optional]



