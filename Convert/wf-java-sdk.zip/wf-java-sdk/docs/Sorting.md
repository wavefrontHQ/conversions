
# Sorting

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**field** | **String** | The facet by which to sort | 
**ascending** | **Boolean** | Whether to sort ascending.  If undefined, sorting is not guaranteed | 



