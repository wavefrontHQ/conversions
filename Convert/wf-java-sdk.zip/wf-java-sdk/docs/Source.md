
# Source

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**hidden** | **Boolean** | A derived field denoting whether this source has been hidden (e.g. excluding it from query autocomplete among other things) |  [optional]
**id** | **String** | id of this source, must be exactly equivalent to &#39;sourceName&#39; | 
**description** | **String** | Description of this source |  [optional]
**tags** | **Map&lt;String, Boolean&gt;** | A Map (String -&gt; boolean) Representing the source tags associated with this source.  To create a tag, set it as a KEY in this map, with associated value equal to true |  [optional]
**sourceName** | **String** | The name of the source, usually set by ingested telemetry | 
**createdEpochMillis** | **Long** |  |  [optional]
**updatedEpochMillis** | **Long** |  |  [optional]
**updaterId** | **String** |  |  [optional]
**creatorId** | **String** |  |  [optional]



