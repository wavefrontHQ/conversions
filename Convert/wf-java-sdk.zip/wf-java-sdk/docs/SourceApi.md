# SourceApi

All URIs are relative to *https://localhost/*

Method | HTTP request | Description
------------- | ------------- | -------------
[**addSourceTag**](SourceApi.md#addSourceTag) | **PUT** /api/v2/source/{id}/tag/{tagValue} | Add a tag to a specific source
[**createSource**](SourceApi.md#createSource) | **POST** /api/v2/source | Create metadata (description or tags) for a specific source
[**deleteSource**](SourceApi.md#deleteSource) | **DELETE** /api/v2/source/{id} | Delete metadata (description and tags) for a specific source
[**getAllSource**](SourceApi.md#getAllSource) | **GET** /api/v2/source | Get all sources for a customer
[**getSource**](SourceApi.md#getSource) | **GET** /api/v2/source/{id} | Get a specific source for a customer
[**getSourceTags**](SourceApi.md#getSourceTags) | **GET** /api/v2/source/{id}/tag | Get all tags associated with a specific source
[**removeSourceTag**](SourceApi.md#removeSourceTag) | **DELETE** /api/v2/source/{id}/tag/{tagValue} | Remove a tag from a specific source
[**setSourceTags**](SourceApi.md#setSourceTags) | **POST** /api/v2/source/{id}/tag | Set all tags associated with a specific source
[**updateSource**](SourceApi.md#updateSource) | **PUT** /api/v2/source/{id} | Update metadata (description or tags) for a specific source


<a name="addSourceTag"></a>
# **addSourceTag**
> ResponseContainer addSourceTag(id, tagValue)

Add a tag to a specific source



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.SourceApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SourceApi apiInstance = new SourceApi();
String id = "id_example"; // String | 
String tagValue = "tagValue_example"; // String | 
try {
    ResponseContainer result = apiInstance.addSourceTag(id, tagValue);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SourceApi#addSourceTag");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |
 **tagValue** | **String**|  |

### Return type

[**ResponseContainer**](ResponseContainer.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="createSource"></a>
# **createSource**
> ResponseContainerSource createSource(body)

Create metadata (description or tags) for a specific source



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.SourceApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SourceApi apiInstance = new SourceApi();
Source body = new Source(); // Source | Example Body:  <pre>{     \"sourceName\": \"source.name\",     \"tags\": {\"sourceTag1\": true},     \"description\": \"Source Description\" }</pre>
try {
    ResponseContainerSource result = apiInstance.createSource(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SourceApi#createSource");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Source**](Source.md)| Example Body:  &lt;pre&gt;{     \&quot;sourceName\&quot;: \&quot;source.name\&quot;,     \&quot;tags\&quot;: {\&quot;sourceTag1\&quot;: true},     \&quot;description\&quot;: \&quot;Source Description\&quot; }&lt;/pre&gt; | [optional]

### Return type

[**ResponseContainerSource**](ResponseContainerSource.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="deleteSource"></a>
# **deleteSource**
> ResponseContainerSource deleteSource(id)

Delete metadata (description and tags) for a specific source



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.SourceApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SourceApi apiInstance = new SourceApi();
String id = "id_example"; // String | 
try {
    ResponseContainerSource result = apiInstance.deleteSource(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SourceApi#deleteSource");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |

### Return type

[**ResponseContainerSource**](ResponseContainerSource.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getAllSource"></a>
# **getAllSource**
> ResponseContainerPagedSource getAllSource(cursor, limit)

Get all sources for a customer



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.SourceApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SourceApi apiInstance = new SourceApi();
String cursor = "cursor_example"; // String | 
Integer limit = 100; // Integer | 
try {
    ResponseContainerPagedSource result = apiInstance.getAllSource(cursor, limit);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SourceApi#getAllSource");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cursor** | **String**|  | [optional]
 **limit** | **Integer**|  | [optional] [default to 100]

### Return type

[**ResponseContainerPagedSource**](ResponseContainerPagedSource.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getSource"></a>
# **getSource**
> ResponseContainerSource getSource(id)

Get a specific source for a customer



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.SourceApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SourceApi apiInstance = new SourceApi();
String id = "id_example"; // String | 
try {
    ResponseContainerSource result = apiInstance.getSource(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SourceApi#getSource");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |

### Return type

[**ResponseContainerSource**](ResponseContainerSource.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getSourceTags"></a>
# **getSourceTags**
> ResponseContainerTagsResponse getSourceTags(id)

Get all tags associated with a specific source



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.SourceApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SourceApi apiInstance = new SourceApi();
String id = "id_example"; // String | 
try {
    ResponseContainerTagsResponse result = apiInstance.getSourceTags(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SourceApi#getSourceTags");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |

### Return type

[**ResponseContainerTagsResponse**](ResponseContainerTagsResponse.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="removeSourceTag"></a>
# **removeSourceTag**
> ResponseContainer removeSourceTag(id, tagValue)

Remove a tag from a specific source



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.SourceApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SourceApi apiInstance = new SourceApi();
String id = "id_example"; // String | 
String tagValue = "tagValue_example"; // String | 
try {
    ResponseContainer result = apiInstance.removeSourceTag(id, tagValue);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SourceApi#removeSourceTag");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |
 **tagValue** | **String**|  |

### Return type

[**ResponseContainer**](ResponseContainer.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="setSourceTags"></a>
# **setSourceTags**
> ResponseContainer setSourceTags(id, body)

Set all tags associated with a specific source



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.SourceApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SourceApi apiInstance = new SourceApi();
String id = "id_example"; // String | 
List<String> body = Arrays.asList(new List<String>()); // List<String> | 
try {
    ResponseContainer result = apiInstance.setSourceTags(id, body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SourceApi#setSourceTags");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |
 **body** | **List&lt;String&gt;**|  | [optional]

### Return type

[**ResponseContainer**](ResponseContainer.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="updateSource"></a>
# **updateSource**
> ResponseContainerSource updateSource(id, body)

Update metadata (description or tags) for a specific source



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.SourceApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SourceApi apiInstance = new SourceApi();
String id = "id_example"; // String | 
Source body = new Source(); // Source | Example Body:  <pre>{     \"sourceName\": \"source.name\",     \"tags\": {\"sourceTag1\": true},     \"description\": \"Source Description\" }</pre>
try {
    ResponseContainerSource result = apiInstance.updateSource(id, body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SourceApi#updateSource");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |
 **body** | [**Source**](Source.md)| Example Body:  &lt;pre&gt;{     \&quot;sourceName\&quot;: \&quot;source.name\&quot;,     \&quot;tags\&quot;: {\&quot;sourceTag1\&quot;: true},     \&quot;description\&quot;: \&quot;Source Description\&quot; }&lt;/pre&gt; | [optional]

### Return type

[**ResponseContainerSource**](ResponseContainerSource.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

