
# SourceLabelPair

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**host** | **String** | Source (or host).  \&quot;Source\&quot; and \&quot;host\&quot; are synonyms in current versions of wavefront, but the host terminology is deprecated |  [optional]
**label** | **String** |  |  [optional]
**tags** | **Map&lt;String, String&gt;** |  |  [optional]
**observed** | **Integer** |  |  [optional]
**firing** | **Integer** |  |  [optional]



