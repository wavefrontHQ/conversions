
# SourceSearchRequestContainer

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cursor** | **String** | The id (exclusive) from which search results resume returning.  Users should supply an entity &#39;id&#39; to this property.  Its main purpose is to resume where a previous search left off because of the &#39;limit&#39; parameter.  If a user supplies the last id in a set of results to cursor, while keeping the query the same, the system will return the next page of results |  [optional]
**limit** | **Integer** |  |  [optional]
**query** | [**List&lt;SearchQuery&gt;**](SearchQuery.md) | A list of queries by which to limit the search results |  [optional]
**sortSourcesAscending** | **Boolean** | Whether to sort source results ascending lexigraphically by id/sourceName.  Default: true |  [optional]



