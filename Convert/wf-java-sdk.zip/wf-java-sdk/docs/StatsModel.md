
# StatsModel

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**keys** | **Long** |  |  [optional]
**points** | **Long** |  |  [optional]
**summaries** | **Long** |  |  [optional]
**summarizedPoints** | **Long** |  |  [optional]
**summarizedSummaries** | **Long** |  |  [optional]
**queries** | **Long** |  |  [optional]
**bufferKeys** | **Long** |  |  [optional]
**compactedKeys** | **Long** |  |  [optional]
**skippedCompactedKeys** | **Long** |  |  [optional]
**compactedPoints** | **Long** |  |  [optional]
**cachedCompactedPoints** | **Long** |  |  [optional]
**latency** | **Long** |  |  [optional]
**s3Keys** | **Long** |  |  [optional]
**cpuNs** | **Long** |  |  [optional]
**metricsUsed** | **Long** |  |  [optional]
**hostsUsed** | **Long** |  |  [optional]
**queryTasks** | **Integer** |  |  [optional]
**missingS3Keys** | **Long** |  |  [optional]



