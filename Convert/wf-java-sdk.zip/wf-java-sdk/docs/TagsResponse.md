
# TagsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | **List&lt;String&gt;** | List of requested items |  [optional]
**offset** | **Integer** |  |  [optional]
**limit** | **Integer** |  |  [optional]
**cursor** | **String** | The id at which the current (limited) search can be continued to obtain more matching items |  [optional]
**totalItems** | **Integer** | An estimate (lower-bound) of the total number of items available for return.  May not be a tight estimate for facet queries |  [optional]
**moreItems** | **Boolean** | Whether more items are available for return by increment offset or cursor |  [optional]
**sort** | [**Sorting**](Sorting.md) | How returned items have been sorted |  [optional]



