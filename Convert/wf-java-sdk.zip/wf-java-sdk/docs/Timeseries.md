
# Timeseries

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tags** | **Map&lt;String, String&gt;** | Associated tags of the time series |  [optional]
**points** | [**List&lt;Point&gt;**](Point.md) |  | 



