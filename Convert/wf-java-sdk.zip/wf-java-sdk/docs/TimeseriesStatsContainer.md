
# TimeseriesStatsContainer

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**queryKey** | [**QueryKeyContainer**](QueryKeyContainer.md) |  |  [optional]
**sum** | **Double** |  |  [optional]
**count** | **Long** |  |  [optional]
**lastValue** | **Double** |  |  [optional]
**mean** | **Double** |  |  [optional]
**max** | **Double** |  |  [optional]
**min** | **Double** |  |  [optional]
**median** | **Double** |  |  [optional]



