
# UserModel

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**identifier** | **String** | The unique identifier of this user, which must be their valid email address |  [optional]
**customer** | **String** | The id of the customer to which this user belongs |  [optional]
**groups** | **List&lt;String&gt;** | The permissions granted to this user |  [optional]



