
# UserToCreate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**emailAddress** | **String** | The (unique) identifier of the user to create.  Must be a valid email address | 
**groups** | **List&lt;String&gt;** | List of permission groups to grant to this user.  Please note that &#39;host_tag_management&#39; is the equivalent of the &#39;Source Tag Management&#39; permission.  Possible values are browse, agent_management, alerts_management, dashboard_management, embedded_charts, events_management, external_links_management, host_tag_management, metrics_management, user_management | 



