
# WFTags

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**customerTags** | **List&lt;String&gt;** | Customer-wide tags.  Can be on various wavefront entities such alerts or dashboards. |  [optional]
**userTags** | [**Map&lt;String, List&lt;String&gt;&gt;**](List.md) | Deprecated.  Used to store user-specific tags, such as \&quot;favorite\&quot; |  [optional]



