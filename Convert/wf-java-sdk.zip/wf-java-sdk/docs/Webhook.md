
# Webhook

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**contentType** | [**ContentTypeEnum**](#ContentTypeEnum) | The value of the Content-Type header of the webhook POST request. |  [optional]
**id** | **String** |  |  [optional]
**description** | **String** | Webhook description | 
**createdEpochMillis** | **Long** |  |  [optional]
**updatedEpochMillis** | **Long** |  |  [optional]
**updaterId** | **String** |  |  [optional]
**creatorId** | **String** |  |  [optional]
**customerId** | **String** |  |  [optional]
**title** | **String** | Webhook Title | 
**template** | **String** | A mustache template that will form the body of the POST request sent as the web hook. | 
**triggers** | [**List&lt;TriggersEnum&gt;**](#List&lt;TriggersEnum&gt;) | A list of occurrences on which this webhook will be fired.  Valid values are ALERT_OPENED, ALERT_UPDATED, ALERT_RESOLVED, ALERT_MAINTENANCE, ALERT_SNOOZED | 
**recipient** | **String** | The URL to which this webhook will be delivered | 
**customHttpHeaders** | **Map&lt;String, String&gt;** | A string-&gt;string map specifying the custom HTTP header key / value pairs that will be sent in the requests of this web hook |  [optional]


<a name="ContentTypeEnum"></a>
## Enum: ContentTypeEnum
Name | Value
---- | -----
APPLICATION_JSON | &quot;application/json&quot;
TEXT_HTML | &quot;text/html&quot;
TEXT_PLAIN | &quot;text/plain&quot;
APPLICATION_X_WWW_FORM_URLENCODED | &quot;application/x-www-form-urlencoded&quot;


<a name="List<TriggersEnum>"></a>
## Enum: List&lt;TriggersEnum&gt;
Name | Value
---- | -----
OPENED | &quot;ALERT_OPENED&quot;
UPDATED | &quot;ALERT_UPDATED&quot;
RESOLVED | &quot;ALERT_RESOLVED&quot;
MAINTENANCE | &quot;ALERT_MAINTENANCE&quot;
SNOOZED | &quot;ALERT_SNOOZED&quot;
INVALID | &quot;ALERT_INVALID&quot;
NO_LONGER_INVALID | &quot;ALERT_NO_LONGER_INVALID&quot;
TESTING | &quot;ALERT_TESTING&quot;
RETRIGGERED | &quot;ALERT_RETRIGGERED&quot;



