# WebhookApi

All URIs are relative to *https://localhost/*

Method | HTTP request | Description
------------- | ------------- | -------------
[**createWebhook**](WebhookApi.md#createWebhook) | **POST** /api/v2/webhook | Create a specific webhook
[**deleteWebhook**](WebhookApi.md#deleteWebhook) | **DELETE** /api/v2/webhook/{id} | Delete a specific webhook
[**getAllWebhooks**](WebhookApi.md#getAllWebhooks) | **GET** /api/v2/webhook | Get all webhooks for a customer
[**getWebhook**](WebhookApi.md#getWebhook) | **GET** /api/v2/webhook/{id} | Get a specific webhook
[**updateWebhook**](WebhookApi.md#updateWebhook) | **PUT** /api/v2/webhook/{id} | Update a specific webhook


<a name="createWebhook"></a>
# **createWebhook**
> ResponseContainerWebhook createWebhook(body)

Create a specific webhook



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.WebhookApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

WebhookApi apiInstance = new WebhookApi();
Webhook body = new Webhook(); // Webhook | Example Body:  <pre>{   \"description\": \"WebHook Description\",   \"template\": \"POST Body -- Mustache syntax\",   \"title\": \"WebHook Title\",   \"triggers\": [     \"ALERT_OPENED\"   ],   \"recipient\": \"http://example.com\",   \"customHttpHeaders\": {},   \"contentType\": \"text/plain\" }</pre>
try {
    ResponseContainerWebhook result = apiInstance.createWebhook(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling WebhookApi#createWebhook");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Webhook**](Webhook.md)| Example Body:  &lt;pre&gt;{   \&quot;description\&quot;: \&quot;WebHook Description\&quot;,   \&quot;template\&quot;: \&quot;POST Body -- Mustache syntax\&quot;,   \&quot;title\&quot;: \&quot;WebHook Title\&quot;,   \&quot;triggers\&quot;: [     \&quot;ALERT_OPENED\&quot;   ],   \&quot;recipient\&quot;: \&quot;http://example.com\&quot;,   \&quot;customHttpHeaders\&quot;: {},   \&quot;contentType\&quot;: \&quot;text/plain\&quot; }&lt;/pre&gt; | [optional]

### Return type

[**ResponseContainerWebhook**](ResponseContainerWebhook.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="deleteWebhook"></a>
# **deleteWebhook**
> ResponseContainerWebhook deleteWebhook(id)

Delete a specific webhook



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.WebhookApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

WebhookApi apiInstance = new WebhookApi();
String id = "id_example"; // String | 
try {
    ResponseContainerWebhook result = apiInstance.deleteWebhook(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling WebhookApi#deleteWebhook");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |

### Return type

[**ResponseContainerWebhook**](ResponseContainerWebhook.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getAllWebhooks"></a>
# **getAllWebhooks**
> ResponseContainerPagedWebhook getAllWebhooks(offset, limit)

Get all webhooks for a customer



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.WebhookApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

WebhookApi apiInstance = new WebhookApi();
Integer offset = 0; // Integer | 
Integer limit = 100; // Integer | 
try {
    ResponseContainerPagedWebhook result = apiInstance.getAllWebhooks(offset, limit);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling WebhookApi#getAllWebhooks");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **offset** | **Integer**|  | [optional] [default to 0]
 **limit** | **Integer**|  | [optional] [default to 100]

### Return type

[**ResponseContainerPagedWebhook**](ResponseContainerPagedWebhook.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getWebhook"></a>
# **getWebhook**
> ResponseContainerWebhook getWebhook(id)

Get a specific webhook



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.WebhookApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

WebhookApi apiInstance = new WebhookApi();
String id = "id_example"; // String | 
try {
    ResponseContainerWebhook result = apiInstance.getWebhook(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling WebhookApi#getWebhook");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |

### Return type

[**ResponseContainerWebhook**](ResponseContainerWebhook.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="updateWebhook"></a>
# **updateWebhook**
> ResponseContainerWebhook updateWebhook(id, body)

Update a specific webhook



### Example
```java
// Import classes:
//import com.wavefront.rest.api.ApiClient;
//import com.wavefront.rest.api.ApiException;
//import com.wavefront.rest.api.Configuration;
//import com.wavefront.rest.api.auth.*;
//import com.wavefront.rest.api.client.WebhookApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

WebhookApi apiInstance = new WebhookApi();
String id = "id_example"; // String | 
Webhook body = new Webhook(); // Webhook | Example Body:  <pre>{   \"description\": \"WebHook Description\",   \"template\": \"POST Body -- Mustache syntax\",   \"title\": \"WebHook Title\",   \"triggers\": [     \"ALERT_OPENED\"   ],   \"recipient\": \"http://example.com\",   \"customHttpHeaders\": {},   \"contentType\": \"text/plain\" }</pre>
try {
    ResponseContainerWebhook result = apiInstance.updateWebhook(id, body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling WebhookApi#updateWebhook");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**|  |
 **body** | [**Webhook**](Webhook.md)| Example Body:  &lt;pre&gt;{   \&quot;description\&quot;: \&quot;WebHook Description\&quot;,   \&quot;template\&quot;: \&quot;POST Body -- Mustache syntax\&quot;,   \&quot;title\&quot;: \&quot;WebHook Title\&quot;,   \&quot;triggers\&quot;: [     \&quot;ALERT_OPENED\&quot;   ],   \&quot;recipient\&quot;: \&quot;http://example.com\&quot;,   \&quot;customHttpHeaders\&quot;: {},   \&quot;contentType\&quot;: \&quot;text/plain\&quot; }&lt;/pre&gt; | [optional]

### Return type

[**ResponseContainerWebhook**](ResponseContainerWebhook.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

